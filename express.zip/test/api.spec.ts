'use strict'
process.env.NODE_ENV = 'test'

import 'mocha'
import { should } from 'chai'
import { getAPIHandler, ServerConfig, getServerConfig } from '../server/API-handler/api'

const rimraf = require('rimraf')

const nock = require('nock')

should()

let _expressLogger

const request = require('supertest')

let app
let server

let config: ServerConfig = {
    assetsPath: './',
    integration: {
        servers: [
            { name: 'sso', url: 'https://ssotest.amdocs.corp.com:8190/auth' },
            { name: 'paymentGateway', url: 'http://fakegateway:8001/paymentGateway' },
            { name: 'help', url: 'http://fakehelpserver:8001/help' }
        ],
        sso: {
            tenantConfiguration: [
                { tenantName: 'tenant1', realm: 'csr-override-realm' }
            ]
        }
    },
    tenantConfiguration: [
        {
            tenantName: 'testtenant',
            sso: {
                guestConfig: {
                    clientId: 'selfcare-guest',
                    clientSecret: 'fake-secret-that-looks-like-a-UUID'
                }
            }
        },
    ],
    logConfiguration: {
        appLogger: {
            level: 'warn',
            folder: 'logs',
            fileName: 'app.log',
            datePattern: 'yyyyMMdd ',
            prepend: true,
            json: true,
            formatLogs: true,
            log2Console: true,
            colorize: true
        }
    }
}

const fs = require('fs')

describe('API Handler', function () {

    before(function (this) {
        this.timeout(15000)

        fs.mkdirSync('./i18n')
        fs.writeFileSync('./i18n/en-US.json', JSON.stringify({
            'login.page.button.login': 'jhgjhgj'
        }))

        app = getAPIHandler(config)

    })

    after(function (done) {
        fs.unlinkSync('./i18n/en-US.json')
        fs.rmdirSync('./i18n')
        rimraf.sync('./logs/test.log.*')
        done()
    })


    describe('server config API', () => {
        context('when the initial configuration contains an integration section with servers and guestConfig definition', () => {
            let initConfig: ServerConfig
            let newConfig: ServerConfig

            before(() => {
                initConfig = {
                    integration: {
                        servers: [
                            { name: 'sso', url: 'https://ssotest.corp.amdocs.com:8190/auth' },
                            { name: 'backend', url: 'http://backend-test.corp.amdocs.com:3001' },
                            { name: 'apiman', url: 'http://fakeapiman.corp.amdocs.com:8443' },
                            { name: 'esb', url: 'http://fakeesb.corp.amdocs.com:8080' },
                            { name: 'help', url: 'http://fakehelpserver:8001/help' }
                        ],
                        guestConfig: [
                            { tenantName: 'testtenant', clientSecret: 'nananananananana-batcave' },
                            { tenantName: 'faketenant', clientSecret: 'nananananananana-batman' }
                        ]
                    },
                    tenantConfiguration: [
                        {
                            tenantName: 'testtenant',
                            sso: {
                                guestConfig: {
                                    clientId: 'selfcare-guest',
                                    clientSecret: 'the original clientSecret value which needs to be replaced'
                                }
                            }
                        }, {
                            tenantName: 'faketenant',
                            sso: {
                                guestConfig: {
                                    clientId: 'selfcare-guest',
                                    clientSecret: 'the original clientSecret value which needs to be replaced'
                                }
                            }
                        }, {
                            tenantName: 'tenantwithnoguestConfig'
                        }, {
                            tenantName: 'untouchableTenant',
                            sso: {
                                guestConfig: {
                                    clientId: 'selfcare-guest',
                                    clientSecret: 'some secret that shall not be touched'
                                }
                            }
                        }
                    ],
                    proxies: [{
                        name: 'backend',
                        options: { target: 'the original backend URL that should be replaced with a real value' }
                    }, {
                        name: 'apiman',
                        options: { target: 'the original apiman URL that should be replaced with a real value' }
                    }, {
                        name: 'esb'
                    }, {
                        name: 'untouchableProxy',
                        options: { target: 'some URL that should not be erased since there is no override' }
                    }]
                }
                newConfig = getServerConfig(initConfig)
            })
            it('should put the guest secrets into the guestConfig section of the tenantConfiguration', () => {
                newConfig.tenantConfiguration[0].sso.guestConfig.clientSecret.should.equal('nananananananana-batcave')
                newConfig.tenantConfiguration[1].sso.guestConfig.clientSecret.should.equal('nananananananana-batman')
            })
            it('should not modify a clientSecret if there is no override defined for it in the integration section', () => {
                newConfig.tenantConfiguration[3].sso.guestConfig.clientSecret.should.equal('some secret that shall not be touched')
            })

            it('should update the target for each proxy with the corresponding server URL', () => {
                newConfig.proxies[0].options.target.should.equal('http://backend-test.corp.amdocs.com:3001')
                newConfig.proxies[1].options.target.should.equal('http://fakeapiman.corp.amdocs.com:8443')
                newConfig.proxies[2].options.target.should.equal('http://fakeesb.corp.amdocs.com:8080')
            })

            it('should not modify the target for a proxy which has no corresponding override in the integration section', () => {
                newConfig.proxies[3].options.target.should.equal('some URL that should not be erased since there is no override')
            })
        })

        context('when the initial configuration does not contain an integration section with servers and guestConfig definition', () => {
            let initConfig: ServerConfig
            let newConfig: ServerConfig

            before(() => {
                initConfig = {
                    assetsPath: './'
                }
                newConfig = getServerConfig(initConfig)
            })
            it('should return the original configuration untouched', () => {
                newConfig.should.deep.equal(initConfig)
            })
        })
    })

    describe('config API', function () {
        it('should return the config object', function (done) {
            request(app)
                .get('/config')
                .expect('Content-Type', 'application/json; charset=utf-8')
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    res.body.should.be.instanceof(Object)
                    res.body.should.have.property('client')
                    res.body.should.have.property('tenantConfiguration')
                    let tenantConfiguration = res.body.tenantConfiguration
                    tenantConfiguration.length.should.equal(4, 'tenantConfiguration.length')
                    tenantConfiguration[0].sso.configuration.should.have.property('url', 'https://ssotest.amdocs.corp.com:8190/auth', 'tenantConfiguration[0].sso.configuration.url')
                    tenantConfiguration[0].sso.configuration.should.have.property('realm', 'csr-override-realm', 'tenantConfiguration[0].sso.configuration.realm')
                    tenantConfiguration[1].sso.configuration.should.have.property('url', 'https://ssotest.amdocs.corp.com:8190/auth', 'tenantConfiguration[1].sso.configuration.url')
                    tenantConfiguration[1].sso.configuration.should.have.property('realm', 'csr-ui_4', 'tenantConfiguration[1].sso.configuration.realm')
                    tenantConfiguration[2].sso.configuration.should.have.property('url', 'https://ssotest.amdocs.corp.com:8190/auth', 'tenantConfiguration[2].sso.configuration.url')
                    tenantConfiguration[2].sso.configuration.should.have.property('realm', 'selfcare-ui_2', 'tenantConfiguration[2].sso.configuration.realm')
                    tenantConfiguration[3].sso.configuration.should.have.property('url', 'https://ssotest.amdocs.corp.com:8190/auth', 'tenantConfiguration[3].sso.configuration.url')
                    tenantConfiguration[3].sso.configuration.should.have.property('realm', 'selfcare-ui_2', 'tenantConfiguration[3].sso.configuration.realm')
                    done()
                })

        })
        it('should return the config object with a server property containing the help server url ', function (done) {
            request(app)
                .get('/config')
                .expect('Content-Type', 'application/json; charset=utf-8')
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    res.body.should.be.instanceof(Object)
                    res.body.should.have.property('server')
                    res.body.server.should.have.property('help')
                    res.body.server.help.should.have.property('url', 'http://fakehelpserver:8001/help')

                    done()
                })

        })
    })

    describe('config/:tenantName API', function () {
        it('should return the config object with the tenant override', function (done) {
            request(app)
                .get('/config/tenant1')
                .expect('Content-Type', 'application/json; charset=utf-8')
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    res.body.should.be.instanceof(Object)
                    res.body.should.have.property('tenantName', 'tenant1')
                    res.body.should.have.property('lang', 'fr-FR')
                    done()
                })

        })
    })

    describe('i18n API', function () {
        it('should return the localization object for en-US', function (done) {
            request(app)
                .get('/i18n/en-US')
                .expect('Content-Type', 'application/json; charset=utf-8')
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    res.body.should.be.instanceof(Object)
                    res.body.should.have.property('login.page.button.login')
                    done()
                })

        })

        it('should return empty object for non existing language', function (done) {
            request(app)
                .get('/i18n/xxx')
                .expect('Content-Type', 'application/json; charset=utf-8')
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    res.body.should.be.instanceof(Object)
                    res.body.should.be.empty
                    done()
                })
        })
    })

    describe('guestAccessToken API', function () {
        let mock = nock('https://ssotest.amdocs.corp.com:8190/')
        before(() => {
            mock
                .post('/auth/realms/selfcare-ui_2/protocol/openid-connect/token')
                .reply(200, { message: 'SUCCESS' })
        })

        it('Should send the request to the mock SSO server and return 200', function (done) {
            request(app)
                .post('/guestAccessToken')
                .send({ tenant_name: 'testtenant' })
                .expect('Content-Type', 'application/json; charset=utf-8')
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    res.body.should.be.instanceof(Object)
                    res.body.should.have.property('message').which.equals('SUCCESS')
                    mock.isDone().should.be.true
                    done()
                })
        })

        it('Should return 500 if tenant does not exist', function (done) {
            request(app)
                .post('/guestAccessToken')
                .send({ tenant_name: 'notexistingtenant' })
                .expect('Content-Type', 'application/json; charset=utf-8')
                .expect(500)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    res.body.should.be.instanceof(Object)
                    res.body.should.have.property('error').which.equals('Client Configuration missing')
                    done()
                })
        })


        it('Should return 500 if tenant guestconfig does not exist', function (done) {
            request(app)
                .post('/guestAccessToken')
                .send({ tenant_name: 'noguesttenant' })
                .expect('Content-Type', 'application/json; charset=utf-8')
                .expect(500)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    res.body.should.be.instanceof(Object)
                    res.body.should.have.property('error').which.equals('Server Tenant Configuration missing')
                    done()
                })
        })


        it('Should Return a 400 if query param "tenant_name" missing', function (done) {
            request(app)
                .post('/guestAccessToken')
                .expect('Content-Type', 'application/json; charset=utf-8')
                .expect(400)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    res.body.should.be.instanceof(Object)
                    res.body.should.have.property('error').which.equals('Body param/s missing (tenant_name)')
                    done()
                })
        })


        it('Should Return a 400 if all Body Params missing', function (done) {
            request(app)
                .post('/guestAccessToken')
                .expect('Content-Type', 'application/json; charset=utf-8')
                .expect(400)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    res.body.should.be.instanceof(Object)
                    res.body.should.have.property('error').which.equals('Body param/s missing (tenant_name)')
                    done()
                })
        })
    })


    describe('guestRefreshToken API', function () {
        let mock = nock('https://ssotest.amdocs.corp.com:8190/')
        before(() => {
            mock
                .post('/auth/realms/selfcare-ui_2/protocol/openid-connect/token')
                .reply(200, { message: 'SUCCESS' })
        })

        it('Should send the request to the mock SSO server and return 200', function (done) {
            request(app)
                .post('/guestRefreshToken')
                .send({ tenant_name: 'testtenant', refresh_token: '123456' })
                .expect('Content-Type', 'application/json; charset=utf-8')
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    res.body.should.be.instanceof(Object)
                    res.body.should.have.property('message').which.equals('SUCCESS')
                    mock.isDone().should.be.true
                    done()
                })
        })

        it('Should return 500 if tenant does not exist', function (done) {
            request(app)
                .post('/guestRefreshToken')
                .send({ tenant_name: 'notexistingtenant', refresh_token: '123456' })
                .expect('Content-Type', 'application/json; charset=utf-8')
                .expect(500)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    res.body.should.be.instanceof(Object)
                    res.body.should.have.property('error').which.equals('Client Configuration missing')
                    done()
                })
        })

        it('Should return 500 if tenant guestconfig does not exist', function (done) {
            request(app)
                .post('/guestRefreshToken')
                .send({ tenant_name: 'noguesttenant', refresh_token: '123456' })
                .expect('Content-Type', 'application/json; charset=utf-8')
                .expect(500)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    res.body.should.be.instanceof(Object)
                    res.body.should.have.property('error').which.equals('Server Tenant Configuration missing')
                    done()
                })
        })

        it('Should Return a 400 if query param "refresh_token" missing', function (done) {
            request(app)
                .post('/guestRefreshToken?tenant_name=testtenant')
                .send({ tenant_name: 'testtenant' })
                .expect('Content-Type', 'application/json; charset=utf-8')
                .expect(400)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    res.body.should.be.instanceof(Object)
                    res.body.should.have.property('error').which.equals('Body Params missing ( tenant_name, refresh_token)')
                    done()
                })
        })

        it('Should Return a 400 if query param "tenant_name" missing', function (done) {
            request(app)
                .post('/guestRefreshToken')
                .send({ refresh_token: '123456' })
                .expect('Content-Type', 'application/json; charset=utf-8')
                .expect(400)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    res.body.should.be.instanceof(Object)
                    res.body.should.have.property('error').which.equals('Body Params missing ( tenant_name, refresh_token)')
                    done()
                })
        })


        it('Should Return a 400 if all Body Params missing', function (done) {
            request(app)
                .post('/guestRefreshToken')
                .expect('Content-Type', 'application/json; charset=utf-8')
                .expect(400)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    res.body.should.be.instanceof(Object)
                    res.body.should.have.property('error').which.equals('Body Params missing ( tenant_name, refresh_token)')
                    done()
                })
        })
    })

    describe('log API', function () {
        it('should return 200 for log request', function (done) {
            request(app)
                .put('/log')
                .send({ logLevel: 'info', message: 'test', metaTest: 'test' })
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err)
                    }
                    done()
                })

        })
    })
})