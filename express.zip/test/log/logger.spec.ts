'use strict'
process.env.NODE_ENV = 'test'

import 'mocha'
import { should } from 'chai'
should()

import { getLogger, detailedErrorLogger } from '../../server/API-handler/log/logger'
import { ServerConfig } from '../../server/API-handler/api'
import * as winston from 'winston'
import * as sinon from 'sinon'

let config: ServerConfig = {
    assetsPath: './',
    integration: {
        servers: [
            { name: 'sso', url: 'https://ssotest.amdocs.corp.com:8190/auth' },
            { name: 'paymentGateway', url: 'http://fakegateway:8001/paymentGateway' },
            { name: 'help', url: 'http://fakehelpserver:8001/help' }
        ],
        sso: {
            tenantConfiguration: [
                { tenantName: 'tenant1', realm: 'csr-override-realm' }
            ]
        }
    },
    tenantConfiguration: [
        {
            tenantName: 'testtenant',
            sso: {
                guestConfig: {
                    clientId: 'selfcare-guest',
                    clientSecret: 'fake-secret-that-looks-like-a-UUID'
                }
            }
        },
    ],
    logConfiguration: {
        appLogger: {
            level: 'warn',
            folder: 'logs',
            fileName: 'app.log',
            datePattern: 'yyyyMMdd ',
            prepend: true,
            json: true,
            formatLogs: true,
            log2Console: true,
            colorize: true
        }
    }
}

describe('API-Handler', () => {
    describe('getLogger', () => {
        context('with console logging and log formatting disabled', () => {
            let _logger
            before(() => {
                _logger = getLogger({
                    level: 'error',
                    folder: 'logs',
                    fileName: 'test.log',
                    datePattern: 'yyyyMMdd',
                    formatLogs: true,
                    log2Console: false,
                    colorize: true,
                    json: false
                })

            })
            it('should return a logger', () => {
                _logger.error('')
            })
        })

        context('with console logging and log formatting enabled', () => {
            let _logger
            before(() => {
                _logger = getLogger({
                    level: 'error',
                    folder: 'logs',
                    fileName: 'test.log',
                    datePattern: 'yyyyMMdd',
                    formatLogs: false,
                    log2Console: true,
                    colorize: true,
                    json: true
                })
            })
            it('should return a logger', () => {
                _logger.transports.should.have.property('console')
            })
        })

    })
    describe('detailedErrorLogger', () => {
        let _writeHead: sinon.SinonStub
        let _end: sinon.SinonStub

        before(() => {
            _writeHead = sinon.stub()
            _end = sinon.stub()
        })

        it('should return a message containing the code, origing, target, and message', () => {
            const _err = {
                code: 'CANNOT_COMPUTE',
                address: '127.0.0.1',
                port: 3001,
                message: 'DERP'
            }
            const _req = {
                headers: {
                    host: 'localhost:8001'
                },
                url: '/api/apu'
            }
            const _res = {
                writeHead: _writeHead,
                headersSent: true,
                end: _end
            }
            _end.reset()
            detailedErrorLogger(_err, _req, _res)
            _end.calledOnce.should.equal(true, 'res.end().calledOnce')
            _end.args[0][0].should.equal(`Error:[${_err.code}] occurred while trying to proxy from {${_req.headers.host}} to {${_err.address}:${_err.port}${_req.url}}. Message={${_err.message}}`, 'res.end(args)')
        })

        it('should return a 502 if the error is HPE_INVALID', () => {
            const _err = {
                code: 'HPE_INVALID',
                address: '127.0.0.1',
                port: 3001,
                message: 'DERP'
            }
            const _req = {
                headers: {
                    host: 'localhost:8001'
                },
                url: '/api/apu'
            }
            const _res = {
                writeHead: _writeHead,
                headersSent: false,
                end: _end
            }
            _writeHead.reset()
            detailedErrorLogger(_err, _req, _res)
            _writeHead.calledOnce.should.equal(true, 'res.writeHead().calledOnce')
            _writeHead.args[0][0].should.equal(502, 'res.writeHead(args)')
        })

        it('should return a 504 if the error is a connection refused', () => {
            const _err = {
                code: 'ECONNREFUSED',
                address: '127.0.0.1',
                port: 3001,
                message: 'DERP'
            }
            const _req = {
                headers: {
                    host: 'localhost:8001'
                },
                url: '/api/apu'
            }
            const _res = {
                writeHead: _writeHead,
                headersSent: false,
                end: _end
            }
            _writeHead.reset()
            detailedErrorLogger(_err, _req, _res)
            _writeHead.calledOnce.should.equal(true, 'res.writeHead().calledOnce')
            _writeHead.args[0][0].should.equal(504, 'res.writeHead(args)')
        })


        it('should return a 504 if the error is a connection reset', () => {
            const _err = {
                code: 'ECONNRESET',
                address: '127.0.0.1',
                port: 3001,
                message: 'DERP'
            }
            const _req = {
                headers: {
                    host: 'localhost:8001'
                },
                url: '/api/apu'
            }
            const _res = {
                writeHead: _writeHead,
                headersSent: false,
                end: _end
            }
            _writeHead.reset()
            detailedErrorLogger(_err, _req, _res)
            _writeHead.calledOnce.should.equal(true, 'res.writeHead().calledOnce')
            _writeHead.args[0][0].should.equal(504, 'res.writeHead(args)')
        })

        it('should return a 504 if the error is a NOT_FOUND error', () => {
            const _err = {
                code: 'ENOTFOUND',
                address: '127.0.0.1',
                port: 3001,
                message: 'DERP'
            }
            const _req = {
                headers: {
                    host: 'localhost:8001'
                },
                url: '/api/apu'
            }
            const _res = {
                writeHead: _writeHead,
                headersSent: false,
                end: _end
            }
            _writeHead.reset()
            detailedErrorLogger(_err, _req, _res)
            _writeHead.calledOnce.should.equal(true, 'res.writeHead().calledOnce')
            _writeHead.args[0][0].should.equal(504, 'res.writeHead(args)')
        })

        it('should return a 500 if the error is unknown', () => {
            const _err = {
                code: 'BANANA',
                address: '127.0.0.1',
                port: 3001,
                message: 'DERP'
            }
            const _req = {
                headers: {
                    host: 'localhost:8001'
                },
                url: '/api/apu'
            }
            const _res = {
                writeHead: _writeHead,
                headersSent: false,
                end: _end
            }
            _writeHead.reset()
            detailedErrorLogger(_err, _req, _res)
            _writeHead.calledOnce.should.equal(true, 'res.writeHead().calledOnce')
            _writeHead.args[0][0].should.equal(500, 'res.writeHead(args)')
        })
    })
})