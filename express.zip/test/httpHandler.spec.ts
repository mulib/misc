'use strict'
import { should, expect } from 'chai'
import * as sinon from 'sinon'
const nock = require('nock')
import 'mocha'
const FormData = require('form-data')
import * as  HttpHandler from '../server/HTTP-handler/httpHandler'

process.env.NODE_ENV = 'test'

describe('HTTP Handler', function () {

    it('should be able to set Headers', function () {
        let _http = new HttpHandler.HttpHandler()
        _http.setHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' })
        expect(_http._headers).not.to.be.undefined
        expect(_http._headers).to.be.instanceof(Object)
        expect(_http._headers).to.have.property('Content-Type')
        expect(_http._headers['Content-Type']).to.be.equals('application/x-www-form-urlencoded')

    })

    it('should be able to set http method ', function () {
        let _http = new HttpHandler.HttpHandler()
        _http.setMethod('POST')
        expect(_http._method).not.to.be.null
        expect(_http._method).to.be.a('string')
        expect(_http._method).to.be.equals('POST')
    })

    it('should be able to set URL ', function () {
        let _http = new HttpHandler.HttpHandler()
        _http.setURL('https://optssodev2.corp.amdocs.com:8190/auth/realms/selfcare_ui-2/protocol/openid-connect/token')
        expect(_http._url).not.to.be.null
        expect(_http._url).to.be.a('string')
        expect(_http._url).to.be.equals('https://optssodev2.corp.amdocs.com:8190/auth/realms/selfcare_ui-2/protocol/openid-connect/token')
    })

    it('should be able to set urlEncoded body ', function () {
        let _http = new HttpHandler.HttpHandler()
        _http.setBody({ client_id: 'selfcare-guest', grant_type: 'client_credentials' }, HttpHandler.HTTPBodyType.urlEncoded)
        expect(_http._body).not.to.be.null
        expect(_http._body).to.be.a('string')
        expect(_http._body).to.contains('client_id')
    })

    it('should be able to set raw body ', function () {
        let _http = new HttpHandler.HttpHandler()
        _http.setBody('this is a raw body', HttpHandler.HTTPBodyType.raw)
        expect(_http._body).not.to.be.null
        expect(_http._body).to.be.a('string')
        expect(_http._body).to.contains('raw body')
    })

    it('should be able to set formData body ', function () {
        let _http = new HttpHandler.HttpHandler()
        _http.setBody({ client_id: 'selfcare-guest', grant_type: 'client_credentials' }, HttpHandler.HTTPBodyType.formData)
        expect(_http._body).to.be.instanceof(FormData)
    })

    it('should be able to set default body in case body type its undefined', function () {
        let _http = new HttpHandler.HttpHandler()
        _http.setBody({ client_id: 'selfcare-guest', grant_type: 'client_credentials' }, undefined)
        expect(_http._body).to.be.instanceof(Object)
    })


    it('should be able to set binray body ', function () {
        let _http = new HttpHandler.HttpHandler()
        _http.setBody({ client_id: 'selfcare-guest', grant_type: 'client_credentials' }, HttpHandler.HTTPBodyType.binary)
        expect(_http._body).to.be.instanceof(Buffer)
    })

    it('should be able to set query params ', function () {
        let _http = new HttpHandler.HttpHandler()
        _http.setQueryParams({ client_id: 'selfcare-guest', grant_type: 'client_credentials' })
        expect(_http._queryParams).to.be.a('string')
    })

    it('should be able to send http Request and get 200 ', function (done) {
        let _http = new HttpHandler.HttpHandler()
        // let res: sinon.SinonSpy = sinon.stub()
        let res = {
            json: sinon.stub(),
            status: sinon.spy(() => { return res })
        }


        nock('http://www.mytinyurkll.com')
            .post('/postme')
            .reply(200, {
                token: 'abcd'
            })

        _http.setHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' })
        _http.setMethod('POST')
        _http.setURL('http://www.mytinyurkll.com/postme')
        _http.setBody({ tinyBody: 'tiny' }, HttpHandler.HTTPBodyType.urlEncoded)
        _http.sendHTTPRequest({}, res)

        setTimeout(() => {
            nock.isDone().should.be.true
            res.json.called.should.be.true
            res.status.called.should.be.false
            res.json.calledWith({ token: 'abcd' }).should.equal(true)
            res.status.args.should.be.empty
            done()
        }, 100)
    })

    it('should be able to send http Request and get error ( not 200 ) ', function (done) {
        let _http = new HttpHandler.HttpHandler()
        // let res: sinon.SinonSpy = sinon.stub()
        let res = {
            json: sinon.stub(),
            status: sinon.spy(() => { return res })
        }


        nock('http://www.mytinyurkll.com')
            .post('/postme')
            .reply(400, {
                error: 'something happened'
            })

        _http.setHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' })
        _http.setMethod('POST')
        _http.setURL('http://www.mytinyurkll.com/postme')
        _http.setBody({ tinyBody: 'tiny' }, HttpHandler.HTTPBodyType.urlEncoded)
        _http.sendHTTPRequest({}, res)

        setTimeout(() => {
            nock.isDone().should.be.true
            res.status.called.should.be.true
            res.json.called.should.be.true
            res.status.args[0][0].should.equal(400)
            res.json.calledWith({ error: 'Something went wrong' }).should.equal(true)
            done()
        }, 100)
    })
})
