"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// organize common elements of this module in a single import file
var api = require("./server/API-handler/api");
exports.getAPIHandler = api.getAPIHandler;
exports.getClientConfig = api.getClientConfig;
exports.getValidationSchema = api.getValidationSchema;
exports.getServerConfig = api.getServerConfig;
exports.getTenantConfig = api.getTenantConfig;

var logger = require("./server/API-handler/log/logger");
exports.getLogger = logger.getLogger;
exports.detailedErrorLogger = logger.detailedErrorLogger;
//# sourceMappingURL=index.js.map