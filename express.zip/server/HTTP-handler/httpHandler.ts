import * as fetch from 'node-fetch'
const querystring = require('querystring')
const FormData = require('form-data')


export enum HTTPBodyType {
    formData,
    urlEncoded,
    raw,
    binary
}

export const HTTPMethod = {
    POST: 'POST',
    GET: 'GET',
    PUT: 'PUT',
    DELETE: 'DELETE'
}

export class HttpHandler {

    _url: string
    het: string
    _body: any
    _headers: any
    _method: string
    _queryParams: string
    _requestOptions: Object

    setFormData(object): FormData {
        const formData = new FormData()
        Object.keys(object).forEach(key => formData.append(key, object[key]))
        return formData
    }

    setBody(body: any, type: HTTPBodyType) {
        switch (type) {
            case HTTPBodyType.formData:
                this._body = this.setFormData(body)
                break
            case HTTPBodyType.raw:
                this._body = body
                break
            case HTTPBodyType.urlEncoded:
                this._body = querystring.stringify(body)
                break
            case HTTPBodyType.binary:
                this._body = new Buffer(body.toString('binary'), 'binary') // not tested
                break
            default:
                this._body = body  // defaulting to as is input body
                break
        }
    }


    setHeaders(headers: Object) {
        this._headers = headers
    }

    setMethod(method: string) {
        this._method = method
    }

    setURL(url: string) {
        this._url = url
    }

    setQueryParams(params: Object) {
        this._queryParams = querystring.stringify(params)
    }

    setRequestOptions(request) {
        this._requestOptions = {
            method: this._method === undefined ? request.method : this._method,
            uri: this._url,
            qs: this._queryParams === undefined ? request.query : this._queryParams,
            headers: this._headers === undefined ? request.headers : this._headers,
            body: this._body === undefined ? request.body : this._body
        }
    }

    sendHTTPRequest(request, response: any) {
        // Setting Request Options
        this.setRequestOptions(request)

        // Call the API
        return fetch(this._url, this._requestOptions)
            .then(callbackResponse => {
                if (callbackResponse.status === 200) {
                    return callbackResponse.json()
                } else {
                    return callbackResponse
                }
            }).then(cbRwsponse => {
                if (cbRwsponse.status) {
                    response.status(cbRwsponse.status).json({ error: 'Something went wrong' })
                } else {
                    response.json(cbRwsponse)
                }
            }).catch(callbackError => {
                response.status(500).json(callbackError)
            })
    }

}