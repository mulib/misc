
import * as path from 'path'
import * as express from 'express'
import * as httpHandler from '../HTTP-handler/httpHandler'

import { getLogger } from './log/logger'

/* istanbul ignore next */
const env = process.env.NODE_ENV || 'production'

const debug = require('debug')('app:http')
const fs = require('fs')

process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'
export const apiHandler: express.Express = express()

const bodyParser = require('body-parser')
apiHandler.use(bodyParser.json())
apiHandler.use(bodyParser.urlencoded({ extended: true }))

export function getAPIHandler(currentConfig: ServerConfig): express.Express {
    apiHandler.use('/config/:tenantName', function (req, res, next) {
        res.set('content-type', 'application/json')
        res.send(getTenantConfig(currentConfig, req.params.tenantName))
        res.end()
    })

    apiHandler.use('/config', function (req, res, next) {
        res.set('content-type', 'application/json')
        res.send(getClientConfig(currentConfig))
        res.end()
    })

    apiHandler.use('/i18n/:lang', function (req, res, next) {
        res.set('content-type', 'application/json')
        res.send(getLang(req.params.lang, currentConfig.assetsPath))
        res.end()
    })

    apiHandler.post('/guestAccessToken', (req, res, next) => getGuestToken(req, res, next, currentConfig))
    apiHandler.post('/guestRefreshToken', (req, res, next) => getGuestToken(req, res, next, currentConfig, true))

    apiHandler.put('/log', function (req, res, next) {
        if (currentConfig.logConfiguration) {
            let appLogger = getLogger(currentConfig.logConfiguration.appLogger)
            let data = []
            let log
            if (req.body) {
                log = req.body
            }
            req.on('data', function (chunk) {
                data.push(chunk)
            })
            req.on('end', function () {
                if (data.length > 0) {
                    log = JSON.parse(data.toString())
                }
            })
            appLogger.log(log.logLevel, log.message, log.meta)
            res.status(200).end()
        }
        else {
            res.status(500).send('no log configuration found')
        }
    })

    return apiHandler

}

export interface ServerConfig {
    assetsPath?: string
    integration?: {
        servers: Server[]
        guestConfig?: { tenantName?: string, clientSecret?: string }[]
        sso?: {
            tenantConfiguration?: { tenantName?: string, realm?: string }[]
        }
    }
    logConfiguration?: {
        [key: string]: LoggerConfig
    }
    tenantConfiguration?: TenantConfiguration[]
    proxies?: { name: string, options?: { target?: string, secure?: boolean, pathRewrite?: {} } }[]
}

export interface Server {
    name?: string
    url?: string
}

export interface LoggerConfig {
    level?: string
    folder?: string
    fileName?: string
    datePattern?: string
    prepend?: boolean
    json?: boolean
    formatLogs?: boolean
    log2Console?: boolean
    colorize?: boolean
}

export interface TenantConfiguration {
    tenantName?: string
    sso?: SSOConfig
}

export interface SSOConfig {
    guestConfig?: {
        clientId?: string
        clientSecret?: string
    }
}

export function getClientConfig(config: ServerConfig) {
    const configUtils = require('config').util
    let envConfig = {}
    const configFolder = 'appConfig'
    const basePath = path.resolve(config.assetsPath, configFolder)
    let baseConfig = configUtils.loadFileConfigs(basePath)
    let mergedConnection = configUtils.extendDeep({}, baseConfig, JSON.parse(fs.readFileSync(path.resolve(basePath + '/connection.json'), 'utf8')))
    let ssoServer: Server = config.integration !== undefined && config.integration.servers !== undefined ? config.integration.servers.filter(server => server.name === 'sso')[0] : undefined
    let paymentGateway: Server = config.integration !== undefined && config.integration.servers !== undefined ? config.integration.servers.filter(server => server.name === 'paymentGateway')[0] : undefined
    let help: Server = config.integration !== undefined && config.integration.servers !== undefined ? config.integration.servers.filter(server => server.name === 'help')[0] : undefined
    let ssoTenantConfiguration = config.integration !== undefined && config.integration.sso !== undefined ? config.integration.sso.tenantConfiguration : undefined
    if (ssoServer !== undefined) {
        let tenantConfiguration = mergedConnection.tenantConfiguration !== undefined ? mergedConnection.tenantConfiguration.map((tenantConfiguration, index) => {
            let tenantOverride = ssoTenantConfiguration !== undefined ? ssoTenantConfiguration.filter(c => c.tenantName === tenantConfiguration.tenantName) : undefined
            let updatedConfig = { ...tenantConfiguration }
            if (updatedConfig.sso !== undefined && updatedConfig.sso.configuration !== undefined) {
                updatedConfig.sso.configuration.url = ssoServer.url
            }
            if (tenantOverride !== undefined && tenantOverride.length === 1 && tenantOverride[0].realm !== undefined) {
                updatedConfig.sso.configuration.realm = tenantOverride[0].realm
            }
            return updatedConfig
        }) : []
        mergedConnection.tenantConfiguration = tenantConfiguration
    }
    mergedConnection.tenantConfiguration = mergedConnection.tenantConfiguration.map(tenant => {
        if (tenant.restApiConfig && tenant.restApiConfig.servers) {
            Object.keys(tenant.restApiConfig.servers).forEach(server => {
                config.integration.servers.forEach(integration => {
                    if (integration.name === server) {
                        tenant.restApiConfig.servers[server].baseUrl = integration.url + mergedConnection.restApiConfig.servers[server].baseUrl
                    }
                })
            })
        }
        return tenant
    })
    Object.keys(mergedConnection.restApiConfig.servers).forEach(server => {
        config.integration.servers.forEach(integration => {
            if (integration.name === server) {
                mergedConnection.restApiConfig.servers[server].baseUrl = integration.url + mergedConnection.restApiConfig.servers[server].baseUrl
            }
        })
    })
    mergedConnection.server = {}

    if (paymentGateway !== undefined) {
        mergedConnection.server = { paymentGateway: { url: paymentGateway.url } }
    }

    if (help !== undefined) {
        mergedConnection.server.help = { url: help.url }
    }

    return mergedConnection
}

export function getServerConfig(config: ServerConfig): ServerConfig {
    let integration = config.integration
    let updatedConfig = { ...config }
    let guestConfig = integration !== undefined && integration.guestConfig !== undefined ? integration.guestConfig.reduce((guestConfig, next) => {
        guestConfig[next.tenantName] = next.clientSecret
        return guestConfig
    }, {}) : {}
    let serverMapping = integration !== undefined && integration.servers !== undefined ? integration.servers.reduce((serverMapping, next) => {
        serverMapping[next.name] = next.url
        return serverMapping
    }, {}) : {}
    if (updatedConfig.tenantConfiguration !== undefined) {
        updatedConfig.tenantConfiguration.forEach(tenantConfiguration => {
            if (tenantConfiguration.sso !== undefined && tenantConfiguration.sso.guestConfig !== undefined && guestConfig[tenantConfiguration.tenantName] !== undefined) {
                tenantConfiguration.sso.guestConfig.clientSecret = guestConfig[tenantConfiguration.tenantName]
            }
        })
    }
    if (updatedConfig.proxies !== undefined) {
        updatedConfig.proxies.forEach(proxyConfig => {
            if (serverMapping[proxyConfig.name] !== undefined) {
                if (proxyConfig.options === undefined) {
                    proxyConfig.options = { target: serverMapping[proxyConfig.name] }
                } else {
                    proxyConfig.options.target = serverMapping[proxyConfig.name]
                }
            }
        })
    }
    return updatedConfig
}

function getLang(language: String, assetsPath: string) {
    let fullFileName

    fullFileName = path.resolve(assetsPath, env === 'development' ? 'app' : '', 'i18n', language + '.json')

    if (!fs.existsSync(fullFileName)) {
        debug('Missing file:---> ' + fullFileName)
        return {}
    }

    let langJson = {}
    try {
        langJson = JSON.parse(fs.readFileSync(fullFileName, 'utf8'))
    } catch (e) {
        debug(e)
    }
    return langJson
}

function getGuestToken(request, callBackResponse, next, serverConfig: ServerConfig, refreshToken?: boolean) {
    let HEADERS = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }

    // Request Validations
    if ((refreshToken === false || refreshToken === undefined) && (request.body === undefined || request.body.tenant_name === undefined)) {
        callBackResponse.status(400).json({
            error: 'Body param/s missing (tenant_name)'
        })
    } else if (refreshToken === true && (request.body === undefined || request.body.tenant_name === undefined || request.body.refresh_token === undefined)) {
        callBackResponse.status(400).json({
            error: 'Body Params missing ( tenant_name, refresh_token)'
        })
    } else {
        // Configuration Validations
        let clientConfig = getTenantConfig(serverConfig, request.body.tenant_name)
        if (clientConfig === undefined || clientConfig.sso === undefined || clientConfig.sso.configuration === undefined) {
            callBackResponse.status(500).json({
                error: 'Client Configuration missing'
            })
        } else {
            if (serverConfig === undefined || serverConfig.tenantConfiguration === undefined) {
                callBackResponse.status(500).json({
                    error: 'Server Configuration missing'
                })
            } else {
                let serverTenantConfigs = serverConfig.tenantConfiguration.filter((t) => t.tenantName === request.body.tenant_name)

                let serverTenantConfig = serverTenantConfigs.length > 0 ? serverTenantConfigs[0] : undefined
                if (serverTenantConfig === undefined || serverTenantConfig.sso === undefined || serverTenantConfig.sso.guestConfig === undefined) {
                    callBackResponse.status(500).json({
                        error: 'Server Tenant Configuration missing'
                    })
                } else {
                    // Get new http handler to send the request
                    let _httpHandler = new httpHandler.HttpHandler()

                    // Decide on request body
                    let requestBody
                    if (refreshToken) {
                        requestBody = {
                            client_id: serverTenantConfig.sso.guestConfig.clientId,
                            client_secret: serverTenantConfig.sso.guestConfig.clientSecret,
                            grant_type: 'refresh_token',
                            refresh_token: request.body.refresh_token
                        }
                    } else {
                        requestBody = {
                            client_id: serverTenantConfig.sso.guestConfig.clientId,
                            client_secret: serverTenantConfig.sso.guestConfig.clientSecret,
                            grant_type: 'client_credentials'
                        }
                    }

                    // Set handler params
                    _httpHandler.setHeaders(HEADERS)
                    _httpHandler.setURL(clientConfig.sso.configuration.url + '/realms/' + clientConfig.sso.configuration.realm + '/protocol/openid-connect/token')
                    _httpHandler.setBody(requestBody, httpHandler.HTTPBodyType.urlEncoded)

                    // Send request ( response will be handled directly from callbackresponce) no need to resolve any promise
                    _httpHandler.sendHTTPRequest(request, callBackResponse)
                }


            }
        }

    }

}

export function getTenantConfig(config: ServerConfig, tenantName: string) {
    const configUtils = require('config').util
    const configFolder = 'appConfig'
    const basePath = path.resolve(config.assetsPath, configFolder)
    // set the NODE APP INSTANCE as 'tenantName' to allow tenant-based overrides
    // This means that tenantName.json and local-tenantName.json will come on top of the default.json
    process.env.NODE_APP_INSTANCE = tenantName
    let baseConfig = configUtils.loadFileConfigs(basePath)
    let tenantConfig = configUtils.extendDeep({}, baseConfig, JSON.parse(fs.readFileSync(path.resolve(basePath + '/connection.json'), 'utf8')))

    // add server configuration to app config
    let ssoServer: Server = config.integration !== undefined && config.integration.servers !== undefined ? config.integration.servers.filter(server => server.name === 'sso')[0] : undefined
    let paymentGateway: Server = config.integration !== undefined && config.integration.servers !== undefined ? config.integration.servers.filter(server => server.name === 'paymentGateway')[0] : undefined
    let help: Server = config.integration !== undefined && config.integration.servers !== undefined ? config.integration.servers.filter(server => server.name === 'help')[0] : undefined
    let ssoTenantConfiguration = config.integration !== undefined && config.integration.sso !== undefined ? config.integration.sso.tenantConfiguration : undefined
    if (ssoServer !== undefined) {
        if (tenantConfig.sso !== undefined && tenantConfig.sso.configuration !== undefined) {
            tenantConfig.sso.configuration.url = ssoServer.url
        }

        let tenantOverride = ssoTenantConfiguration !== undefined ? ssoTenantConfiguration.filter(c => c.tenantName === tenantName) : undefined
        if (tenantOverride !== undefined && tenantOverride.length === 1 && tenantOverride[0].realm !== undefined) {
            if (tenantConfig.sso && tenantConfig.sso.configuration) {
                tenantConfig.sso.configuration.realm = tenantOverride[0].realm
            }
        }

        Object.keys(tenantConfig.restApiConfig.servers).forEach(server => {
            config.integration.servers.forEach(integration => {
                if (integration.name === server) {
                    tenantConfig.restApiConfig.servers[server].baseUrl = integration.url + tenantConfig.restApiConfig.servers[server].baseUrl
                }
            })
        })

        tenantConfig.server = {}

        if (paymentGateway !== undefined) {
            tenantConfig.server = { paymentGateway: { url: paymentGateway.url } }
        }

        if (help !== undefined) {
            tenantConfig.server.help = { url: help.url }
        }
    }
    return tenantConfig
}



