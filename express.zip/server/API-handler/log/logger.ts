import * as winston from 'winston'
import * as fs from 'fs'


export function getLogger(loggerConfig: any): winston.LoggerInstance {

  const logLevel = loggerConfig.level

  const logDir = loggerConfig.folder
  const loggerFile = require('winston-daily-rotate-file')

  // Create the log directory if it does not exist
  /* istanbul ignore next */
  if (!fs.existsSync(logDir.toString())) {
    fs.mkdirSync(logDir.toString())
  }
  const tsFormat = () => new Date().toLocaleTimeString()

  let fileLoggerConfig = {
    filename: './' + logDir + '/' + loggerConfig.fileName,
    timestamp: tsFormat,
    datePattern: loggerConfig.datePattern,
    prepend: loggerConfig.prepend,
    json: loggerConfig.json,
    level: logLevel,
    formatter: loggerFormatter
  }

  if (loggerConfig.formatLogs) {
    fileLoggerConfig = (<any>Object).assign({}, fileLoggerConfig, { formatter: loggerFormatter })
  }

  let transports: Array<any> = [
    new loggerFile(fileLoggerConfig)
  ]

  if (loggerConfig.log2Console) {
    transports.push(new winston.transports.Console({
      level: logLevel,
      colorize: loggerConfig.colorize
    }))
  }

  const logger = new winston.Logger({
    level: logLevel,
    transports: transports
  })
  return logger
}

function loggerFormatter(options) {
  // Return string will be passed to logger.
  return (
    options.timestamp() +
    ' [' +
    options.level.toUpperCase() +
    '] ' +
    (undefined !== options.message ? options.message : '') +
    (options.meta && Object.keys(options.meta).length
      ? '\n\t' + JSON.stringify(options.meta)
      : '')
  )
}

/**
 * Custom error logger based off the original http-proxy-middleware defaultErrorHandler, which provides more info in the response
 * @param err the error that occurred
 * @param req the original http request
 * @param res the server response
 */
export function detailedErrorLogger(err, req, res) {
  const host = (req.headers && req.headers.host)
  const code = err.code
  if (res.writeHead && !res.headersSent) {
    if (/HPE_INVALID/.test(code)) {
      res.writeHead(502)
    } else {
      switch (code) {
        case 'ECONNRESET':
        case 'ENOTFOUND':
        case 'ECONNREFUSED':
          res.writeHead(504)
          break
        default: res.writeHead(500)
      }
    }
  }
  const target = `${err.address}:${err.port}`
  const message = `Error:[${code}] occurred while trying to proxy from {${host}} to {${target}${req.url}}. Message={${err.message}}`
  res.end(message)
}