import groovy.json.JsonSlurperClassic

/* *** USAGE EXAMPLES ***
node('digital')
{
    def wis
    stage("wiql query")
    {
         def wiql = "Select ID, title from [Issue] where (state  in ('Resolved') and [Work Item Type] in ('Bug', 'Task', 'Merge') and [Branch] in ('TBD') and ([ResolvedIn] = '') and [Area Path] under 'NBU\\Optima\\DevOps')"
         wis = tfsGetWIsByQuery(wiql)
         println "query result\n" + wis
    }

    stage("get details")
    {
        def wiDetails = tfsGetWIDetails(wis)
        println "wiDetails\n" + wiDetails
        def wiHTML = WItoHTML(wiDetails)
        println "HTML\n" + wiHTML[0]
        //println "WI\n" + wiHTML[1]
    }

    stage ("update tfs")
    {
        tfsUpdateWIResolvedIn([193280,193283,135805,195995],"Optima_01.01.06.00")
    }

}
*/


//get details about the relevant WIs
def tfsGetWIDetails(def ids, def listOfFields="System.Title,System.AreaPath,System.WorkItemType,System.State,System.AssignedTo,Microsoft.VSTS.Common.Severity,NBU.Branch,Microsoft.VSTS.Build.ResolvedIn")
{
    println "Getting details on the following work items: ${ids}"
    def wi_json
    withCredentials([usernamePassword(credentialsId: 'nbubuilder3', passwordVariable: 'CPASS', usernameVariable: 'CUSER')])
    {
        def cmd = 'curl -s -S -f --ntlm -u ' + CUSER + ':' + CPASS + ' "http://sason:8080/tfs/nbu-Collection/_apis/wit/workitems?ids=' + ids.join(',') + '&fields=' + listOfFields + '&api-version=1.0"'
        wi_json = sh script:cmd, returnStdout: true
    }
    return wi_json
}

def tfsUpdateWI(def id, def updateJson)
{
    def cmd = ""
    def status = null
    withCredentials([usernamePassword(credentialsId: 'nbubuilder3', passwordVariable: 'CPASS', usernameVariable: 'CUSER')])
    {
        cmd = 'curl -s -S -f --ntlm -u ' + CUSER + ':' + CPASS + ' -X PATCH "http://sason:8080/tfs/nbu-Collection/_apis/wit/workitems/' + id + '?api-version=1.0" --header "Content-Type: application/json-patch+json" --data \'' + updateJson + '\''
        status = sh  script: cmd, returnStatus: true, returnStdout: true
        if (status != 0)
            throw new GroovyRuntimeException("Update failed - aborting")
    }
}

def tfsUpdateWIResolvedIn(def ids, def version)
{
    //def updateJson ='[{"op": "add","path": "/fields/System.History","value": "test WI update using REST API"}]'
    def updateJson ='[{"op": "add","path": "/fields/Microsoft.VSTS.Build.ResolvedIn","value": "' + version + '"}]'
    def WIDetails=tfsGetWIDetails(ids)
    def jsonObject = new JsonSlurperClassic().parseText(WIDetails)
    for (def i=0; i < jsonObject.value.size(); i++)
    {
        println "Analyzing WI ${jsonObject.value[i].id}: " + jsonObject.value[i].fields."System.Title"
           if (jsonObject.value[i].fields."System.State" != "Resolved")
            println "Status is " + jsonObject.value[i].fields."System.State" + " - Skipping"
            else{
                println "Updating Resolved In to ${version}"
                tfsUpdateWI(jsonObject.value[i].id, updateJson)
            }
    }
    jsonObject = null
}

def tfsUpdateHistory(def ids, def version)
{
    def WIDetails=tfsGetWIDetails(ids)
    println WIDetails
    def updateJson ='[{"op": "add","path": "/fields/System.History","value": "Build In Job:'+ version +'"}]'
    
    def jsonObject = new JsonSlurperClassic().parseText(WIDetails)
    for (def i=0; i < jsonObject.value.size(); i++)
    {
         println "Adding to History 'Build In Job: ${version}'"
         tfsUpdateWI(jsonObject.value[i].id, updateJson)
    }
    jsonObject = null
}

def tfsGetWIsByQuery(def query)
{
    //WIQL query to find relevant WI numbers
    tmp = query.replace('\\','\\u005c')
    tmp = tmp.replace(/'/,'\\u0027')

    def wi_json
    withCredentials([usernamePassword(credentialsId: 'nbubuilder3', passwordVariable: 'CPASS', usernameVariable: 'CUSER')])
    {
        def cmd = 'curl -s -S --ntlm -u ' + CUSER + ':' + CPASS + ' -X POST "http://sason:8080/tfs/nbu-Collection/NBU/_apis/wit/wiql?api-version=1.0" --header "Content-Type: application/json" -d \'{"query": "' + tmp + '"}\''
        wi_json= sh script: cmd, returnStdout: true
    }

    return getIDsFromWIQLJson(wi_json)
}

@NonCPS
def getIDsFromWIQLJson(def wi_json)
{
    def jsonObject = new JsonSlurperClassic().parseText(wi_json)
    def list = []
    for (def i=0; i<jsonObject.workItems.size(); i++)
    {
        list << jsonObject.workItems[i].id
    }

    return list
}

@NonCPS
def WItoHTML(def wi_json)
{
    def tableStyle = 'style="border-collapse:collapse; text-align:left;"'
    def tableHeaderTRStyle = 'style="font-family:Calibri; font-weight:bold; background-color:#3D5277; color:#ffffff;"'
    def tableHeaderTDStyle = 'style="font-family:Calibri; font-weight:bold; text-align:center; background-color:#3D5277; color:#ffffff; border-color:#5c87b2; border-style:solid; border-width:thin; padding: 5px;"'
    def tableRowTRStyle = 'style=" font-family:Calibri; border-color:#5c87b2; border-style:solid; border-width:thin; padding: 5px;"'
    def tableRowTDStyle = 'style=" font-family:Calibri; border-color:#5c87b2; border-style:solid; border-width:thin; padding: 5px;"'

    def jsonObject = new JsonSlurperClassic().parseText(wi_json)

    def tableHTML = "<TABLE ${tableStyle}>\n<TR ${tableHeaderTRStyle}><TD ${tableHeaderTDStyle}>WI#</TD><TD ${tableHeaderTDStyle}>Title</TD><TD ${tableHeaderTDStyle}>Type</TD><TD ${tableHeaderTDStyle}>Assigned To</TD><TD ${tableHeaderTDStyle}>Severity</TD><TD ${tableHeaderTDStyle}>Area</TD></TR>\n"

    for (def i=0; i<jsonObject.value.size(); i++)
    {
        def it = jsonObject.value[i]
        tableHTML += "<TR ${tableRowTRStyle}><TD ${tableRowTDStyle}>" + it.id + "</TD><TD ${tableRowTDStyle}>" + it.fields."System.Title" + "</TD><TD ${tableRowTDStyle}>" + it.fields."System.WorkItemType" + "</TD><TD ${tableRowTDStyle}>" + it.fields."System.AssignedTo" +
                         "</TD><TD ${tableRowTDStyle}>" + it.fields."Microsoft.VSTS.Common.Severity" + "</TD><TD ${tableRowTDStyle}>" + it.fields."System.AreaPath" + "</TD></TR>\n"
    }
    tableHTML += "</TABLE>"

    //println tableHTML
    return tableHTML
}

return this;
