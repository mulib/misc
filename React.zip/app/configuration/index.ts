import * as _ from 'lodash'

// Add common configurations here
export const AppBaseWidgetConfiguration = _.merge({}, {}
)
