import { Action, Dispatch } from 'redux'

import { ExampleApiResponseType, ExampleApiState } from './exampleApiTypes'

export const BEGIN_EXAMPLE_API = '@@ExampleApi/BEGIN_EXAMPLE_API'
export const SUCCESS_EXAMPLE_API = '@@ExampleApi/SUCCESS_EXAMPLE_API'
export const FAILURE_EXAMPLE_API = '@@ExampleApi/FAILURE_EXAMPLE_API'
export const RESET_STATUS_EXAMPLE_API = '@@ExampleApi/RESET_STATUS_EXAMPLE_API'

/**
* @constant
* Action dispatched in order to indicate we are starting the exampleApi API call
*/
export const beginExampleApiAction: Action = {
    type: BEGIN_EXAMPLE_API
}

/**
 * Action dispatched to indicate the exampleApi API call was successful
 */
export interface ExampleApiSuccessAction extends Action {
    payload?: any
    totalCount?: number
}

/**
 * Action dispatched to indicate the exampleApi API call was unsuccessful
 */
export interface ExampleApiFailureAction extends Action {
    message: string
}

/**
* @constant
* Action dispatched in order to reset the exampleApi API call status.
* Mostly useful in case of create, update and delete situations, where we will want a 'clean slate' for every new operation.
*/
export const resetStatusExampleApiAction: Action = {
    type: RESET_STATUS_EXAMPLE_API
}

/**
 * 'Success' Action creator for the the exampleApi API call
 * @param data the output of the API call
 * @return a @type{ExampleApiSuccessAction} with the data in its payload
 */
export const exampleApiSuccessAction = (data?: any, totalCount?: number): ExampleApiSuccessAction => ({
    payload: data,
    totalCount,
    type: SUCCESS_EXAMPLE_API
})

/**
 * 'Failure' Action creator for the the exampleApi API call
 * @param data the output of the API call
 * @return a @type{ExampleApiFailureAction} with the data in its payload
 */
export const exampleApiFailureAction = (message: string): ExampleApiFailureAction => ({
    message,
    type: FAILURE_EXAMPLE_API
})

/**
 * Action Helper that executes the API call and dispatches the relevant actions when necessary
 */
export const exampleApi = (dispatch: Dispatch<ExampleApiState>, pathParams: {}, queryParams?: {}, headers?: {}): Promise<any> => {
    dispatch(beginExampleApiAction)

    return new Promise<any>((resolve, reject) => {
        const dataValue = {
            sortDropDownValue:  0,
            searchDropDownValue: 0,
            searchInputValue:  ''
        }

        const response = {
            status: 200,
            response: dataValue,
            totalCount: 10,
            message: 'success'
        }

        setTimeout(() => resolve(response), 10000)
    })
        .then((response: any) => {
            dispatch(exampleApiSuccessAction(response.response, response.totalCount))

            return response
        })
        .catch(error => {
            dispatch(exampleApiFailureAction(error.response ? error.response.data ? error.response.data.message : error.response : error))

            return new Promise<any>((resolve, reject) => { reject(error) })
        } )
}
