import { ResponseWrapper, CallStatus } from '@optima/core-ui-esb-sdk'

/**
 * This is the REST API response type definition
 */
export type ExampleApiResponseType = ResponseWrapper<any>

/**
 * Redux State interface for exampleApi
 * @param callStatus indicates the API call status. For each HTTP verb, it holds a loading and a success flag, as well as any remote message sent by the API
 * @param response is the entity stored upon successful API invocation
 * @param totalCount is the number of elements returned in the response array upon successful API invocation
 */
export interface ExampleApiState {
    callStatus?: CallStatus
    response?: any
    totalCount?: number
}
