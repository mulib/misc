import { Action, Reducer } from 'redux'
import { ExampleApiState } from './exampleApiTypes'
import { exampleApiInitialState } from './exampleApiMain'
import * as actions from './exampleApiActions'

/**
 * Reducer for the BeginExampleApiAction action
 * @param state the current state
 * @param action the BeginExampleApiAction action
 * @return a new ExampleApiState with the loading flag set to true
 */
export const beginExampleApiActionReducer: Reducer<ExampleApiState> = (state: ExampleApiState, action: Action) => {
    const newState = {...state}
    newState.callStatus = {...newState.callStatus, loading: true }

    return newState
}

/**
 * Reducer for the ExampleApiSuccessAction action
 * @param state the current state
 * @param action the ExampleApiSuccessAction action
 * @return a new ExampleApiState with the loading flag set to false, success to true, and the CustomerAccount from the payload in the state
 */
export const exampleApiSuccessActionReducer: Reducer<ExampleApiState> = (state: ExampleApiState, action: Action) => {
    const _action = action as actions.ExampleApiSuccessAction
    const newState = {...state, response: _action.payload, totalCount: _action.totalCount }
    newState.callStatus = {...newState.callStatus, loading: false, success: true }

    return newState
}

/**
 * Reducer for the ExampleApiFailureAction action
 * @param state the current state
 * @param action the ExampleApiFailureAction action
 * @return a new ExampleApiState with the loading flag set to false, success to false, and the message from the action in the state
 */
export const exampleApiFailureActionReducer: Reducer<ExampleApiState> = (state: ExampleApiState, action: Action) => {
    const _action = action as actions.ExampleApiFailureAction
    const newState = {...state}
    newState.callStatus = {...newState.callStatus, loading: false, success: false, message: _action.message }

    return newState
}

/**
 * Reducer for the ResetStatusExampleApiAction action
 * @param state the current state
 * @param action the ResetStatusExampleApiAction action
 * @return the exampleApiInitialState
 */
export const resetStatusExampleApiActionReducer: Reducer<ExampleApiState> = (state: ExampleApiState, action: Action) => {
    return exampleApiInitialState
}
