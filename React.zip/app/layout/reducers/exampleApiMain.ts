import { Action, Reducer } from 'redux'

import { ExampleApiState } from './exampleApiTypes'
import * as actions from './exampleApiActions'
import * as reducers from './exampleApiReducers'

export const exampleApiInitialState: ExampleApiState = {}

/**
 * Action/Reducer mapping object. Each key is an Action Type, each value the reducer that needs to be invoked when matching.
 */
interface ReducerMapping {
    [a: string]: Reducer<ExampleApiState>
}

const actionReducerMapping: ReducerMapping = {
    [actions.BEGIN_EXAMPLE_API]: reducers.beginExampleApiActionReducer,
    [actions.SUCCESS_EXAMPLE_API]: reducers.exampleApiSuccessActionReducer,
    [actions.FAILURE_EXAMPLE_API]: reducers.exampleApiFailureActionReducer,
    [actions.RESET_STATUS_EXAMPLE_API]: reducers.resetStatusExampleApiActionReducer
}

/**
 * the exampleApi reducereducers. It takes from the array of reducers defined above to find the proper reducer to invoke, based on the action type.
 */
export const exampleApiReducer: Reducer<ExampleApiState> = (state: ExampleApiState = exampleApiInitialState, action: Action): ExampleApiState => {
    const reducer: Reducer<ExampleApiState> = actionReducerMapping[action.type]
    if (reducer) {
        return reducer(state, action)
    }

    return state
}
