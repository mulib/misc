'use strict'

import * as routes from './rootRouter'
import { should } from 'chai'
should()
import * as sinon from 'sinon'

describe('layout', () => {
    describe('rootRouter', () => {
        describe('mainRedirect', () => {
            it('should redirect to /ui-components by default', () => {
                const replace = sinon.stub()
                const cb = sinon.stub()
                routes.mainRedirect()({ location: { pathname: '/', search: '', query: {}, state: {}, action: 'PUSH', key: '' }, routes: [], params: { tenantName: 'tenant1', accountInternalId: '125', serverId: '3' }, components: [] }, replace, cb)
                replace.called.should.be.true
                replace.args[0][0].should.equal('/ui-components')
            })
        })

        describe('getMainLayoutComponent', () => {
            it('Should contain the main layout components', (done) => {
                let expectedComp = undefined
                const cb = function (var1, comp) {
                    expectedComp = comp
                }
                routes.getMainLayoutComponent(null, cb)
                setTimeout(() => {
                    expect(expectedComp).to.exist
                    done()
                }, 0)
            })
        })

    })
})
