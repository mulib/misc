import { OPageContainer } from '@optima/core-ui-libs/ui-components'
import * as React from 'react'
import * as sinon from 'sinon'
import { ReactWrapper } from 'enzyme'

import { mountWithMockStore } from '../../common/testUtils.spec'
import { AppDesktop, IProps, IState } from './AppDesktop'

describe('<AppDesktop> component tests', () => {
  let _wrapper: ReactWrapper<IProps, {}>

  before(() => {
    _wrapper = mountWithMockStore(<AppDesktop routes={['rout1']} />)
  })

  it('should render <AppDesktop> correctly...', () => {
    expect(_wrapper).to.exist
  })
})
