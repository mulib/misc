import * as React from 'react'
import { connect } from 'react-redux'
import { Dispatch } from 'redux'
import { browserHistory } from 'react-router'
import { Navbar, Nav, NavItem, NavDropdown, MenuItem, Glyphicon, Image } from 'react-bootstrap'
import { AppState } from '../../store/AppStore'
// import exampleRoutes from '../../example/routes'
import axios from 'axios'
import { addLocaleData } from 'react-intl'
import { OApplicationHeader, IApplicationHeaderTabData, IApplicationHeaderActions, IApplicationHeaderSubMenu, IApplicationHeaderPageTitle, IODropDownListItem, OPageContainer } from '@optima/core-ui-libs/ui-components'
import { ConnectedIntlProvider, DEFAULT_LOCALE, updateIntlAction } from '@optima/core-ui-libs/common/reducers/I18nReducer'
import { OWidgetInstance } from '@optima/core-ui-libs/widgetFramework'
const config = require('envConfig')
const css = require('./AppDesktop.scss')

export interface IOwnProps {
  routes?: [any]
}

export interface IDispatchProps {
  setMessages?: () => void
}

export type IProps = IOwnProps & IDispatchProps

export interface IState {
  colors?: any
  currentTheme?: 'care' | 'self-care'
  fonts?: any
  showThemeMenu: boolean
  userAccessType: string
}

export const setMessages = (locale: string, dispatch: any) => {
  let url = window.location.protocol + '//' + window.location.host + '/i18n/' + locale
  axios.get(url)
    .then((response) => {
      dispatch(updateIntlAction(locale, response.data))
    })
    .catch((err) => {
      const util = require('util')
      console.error('setMessages error on ' + url + '   err =' + util.inspect(err, false, null))
    })
}

export class AppDesktop extends React.Component<IProps, IState> {
  constructor() {
    super()
    document.body.className = config.defaultTheme
    document.body.id = 'bootstrap-overrides'
    this.state = {
      colors: this.scColors,
      currentTheme: 'self-care',
      fonts: this.scFonts,
      showThemeMenu: true,
      userAccessType: 'SelfCare'
    }
    this.addLocale = this.addLocale.bind(this)
  }

  switchTheme = (themeName: string) => () => {

    if (themeName === 'care') {
      this.setState({ userAccessType: 'CSR', colors: this.csrColors, fonts: this.csrFonts, currentTheme: 'care', showThemeMenu: false }, () => { document.getElementsByTagName('BODY').item(0).className = 'CSR' })
    } else {
      this.setState({ userAccessType: 'SelfCare', colors: this.scColors, fonts: this.scFonts, currentTheme: 'self-care', showThemeMenu: false }, () => { document.getElementsByTagName('BODY').item(0).className = 'SelfCare' })
    }
  }

  csrColors = {
    c1: { hex: '#231F20', description: 'Text Color:Black', extraClass: '' },
    c2: { hex: '#02C4D8', description: 'Clickable:Turquise', extraClass: '' },
    c3: { hex: '#7ED960', description: 'Selected Color:Green', extraClass: '' },
    c4: { hex: '#184D8E', description: 'Header:Blue', extraClass: '' },
    c5: { hex: '#FF8C11', description: 'Highlights:Orange', extraClass: ' color-c1' },
    c6: { hex: '#B8C9DE', description: 'Extra Color:Blue Grey', extraClass: '' },
    c7: { hex: '#F3F5F9', description: 'Background Color:Brighter Gray', extraClass: ' color-c1' },
    c8: { hex: '#949CA3', description: 'Labels:Dark Grey', extraClass: '' },
    c9: { hex: '#CCCFD2', description: 'Disabled:Medium Gray', extraClass: '' },
    c10: { hex: '#EAEAEA', description: 'Seperators & Tile Borders:Gray', extraClass: ' color-c1' },
    c11: { hex: '#FFF', description: 'Background:White', extraClass: ' color-c1 borderColor-c9' },
    c12: { hex: '#FF3C48', description: 'Warning/Notifications:Red', extraClass: '' },
    c13: { hex: '#19447C', description: 'Background:Dark Blue', extraClass: '' }
  }

  scColors = {
    c1: { hex: '#3E3E3F', description: 'Dark gray', extraClass: '' },
    c2: { hex: '#738591', description: 'Gray', extraClass: ' color-c14' },
    c3: { hex: '#2A93FE', description: 'Blue, Brand Primary', extraClass: ' color-c14' },
    c4: { hex: '#6DE252', description: 'Green', extraClass: '' },
    c5: { hex: '#F3F5F8', description: 'Alternate gray', extraClass: '' },
    c6: { hex: '#EAEAEA', description: 'Light gray', extraClass: '' },
    c7: { hex: '#C8CCCE', description: 'Mid gray', extraClass: '' },
    c8: { hex: '#FF3946', description: 'Red, Brand Danger', extraClass: ' color-c14' },
    c9: { hex: '#ECF4FF', description: 'Baby blue', extraClass: '' },
    c10: { hex: '#B8C8DF', description: 'Gray blue', extraClass: '' },
    c11: { hex: '#698EBE', description: 'Dark gray blue', extraClass: ' color-c14' },
    c12: { hex: '#1A549D', description: 'Dark blue', extraClass: '' },
    c13: { hex: '#154581', description: 'Navy blue', extraClass: '' },
    c14: { hex: '#FFF', description: 'White', extraClass: '' },
    c15: { hex: '#000', description: 'Black', extraClass: '' },
    c16: { hex: '#0076F8', description: 'Hover blue', extraClass: ' color-c14' },
    c17: { hex: '#FFDA44', description: 'Yellow, Warning', extraClass: '' }
  }

  csrFonts = {
    tags: [{ 'h1': 'regular 30px montserrat' }, { 'h2': 'regular 20px montserrat' }, { 'h3': 'regular 18px montserrat' }, { 'h4': 'light 18px montserrat' }, { 'h5': 'regular 16px montserrat' }, { 'h6': 'regular 15px montserrat' }],
    classes: [{ 'font-h7': 'light 15px montserrat' }, { 'font-b1': 'bold 14px montserrat' }, { 'font-b2': 'regular 14px montserrat' }, { 'font-b3': 'bold 13px montserrat' }, { 'font-b4': 'light 13px montserrat' }]
  }

  scFonts = {
    tags: [{ 'h1': 'extra bold 36px montserrat' }, { 'h2': 'ultra light 36px montserrat' }, { 'h3': 'extra bold 28px montserrat' }, { 'h4': 'semi bold 28px montserrat' }, { 'h5': 'extra bold 22px montserrat' }, { 'h6': 'light 22px montserrat' }],
    classes: [{ 'font-h7': 'regular 22px montserrat' }, { 'font-h8': 'semi bold 28px montserrat' }, { 'font-b1': 'regular 18px montserrat' }, { 'font-b2': 'light 18px montserrat' }, { 'font-b3': 'semi bold 16px montserrat' }, { 'font-b4': 'regular 16px montserrat' }, { 'font-b5': 'light 16px montserrat' }, { 'font-b6': 'semi bold 14px montserrat' }, { 'font-b7': 'regular 14px montserrat' }, { 'font-b8': 'light 14px montserrat' }, { 'font-b9': 'semi bold 12px montserrat' }, { 'font-b10': 'regular 12px montserrat' }, { 'font-b11': 'light 12px montserrat' }, { 'font-b12': 'bold 14px montserrat' }, { 'font-b13': 'extra bold 18px montserrat' }]
  }

  gotoPage(path: string) {
    browserHistory.push(path)
    // this.setState({ showThemeMenu: true })
  }

  componentWillMount() {

    this.addLocale()
    this.props.setMessages && this.props.setMessages()
  }

  componentDidMount() {

  }

  addLocale() {
    let supportedLanguages = config.supportedLanguages ? config.supportedLanguages : [DEFAULT_LOCALE]
    for (let i = 0; i < supportedLanguages.length; i++) {
      let lang = supportedLanguages[i].split('-')[0]
      let requireLocale = require('react-intl/locale-data/' + lang)
      addLocaleData(requireLocale)
    }
  }
  applicationHeaderTabData: IApplicationHeaderTabData = {
    activeKey: 0,
    tabs: [
      { key: 0, content: 'UI-Components' },
      { key: 1, content: 'Form-validation' },
      { key: 2, content: 'Configurable-UI' },
      { key: 3, content: 'Configuration-Editor' }
    ]
  }

  applicationHeaderSubMenu: IApplicationHeaderSubMenu = {
    tabs: [
      {
        key: 0, content: <div><a href='#CSR' onClick={this.switchTheme('care')} style={{ 'margin': '16px', 'display': 'inline-block' }}>CSR </a> |
      <a href='#SelfCare' onClick={this.switchTheme('self-care')} style={{ 'margin': '16px', 'display': 'inline-block' }}> Self-Care</a></div>
      },
      {
        key: 1, content: <div><a href='#CSR' onClick={this.switchTheme('care')} style={{ 'margin': '16px', 'display': 'inline-block' }}>CSR </a> |
      <a href='#SelfCare' onClick={this.switchTheme('self-care')} style={{ 'margin': '16px', 'display': 'inline-block' }}> Self-Care</a></div>
      },
      {
        key: 2, content: <div><a href='#CSR' onClick={this.switchTheme('care')} style={{ 'margin': '16px', 'display': 'inline-block' }}>CSR </a> |
      <a href='#SelfCare' onClick={this.switchTheme('self-care')} style={{ 'margin': '16px', 'display': 'inline-block' }}> Self-Care</a></div>
      },
      {
        key: 3, content: <div><a href='#CSR' onClick={this.switchTheme('care')} style={{ 'margin': '16px', 'display': 'inline-block' }}>CSR </a> |
      <a href='#SelfCare' onClick={this.switchTheme('self-care')} style={{ 'margin': '16px', 'display': 'inline-block' }}> Self-Care</a></div>
      }
    ]
  }

  navigation(eventKey: number) {
    switch (eventKey) {
      case 0:
        this.gotoPage('/ui-components')
        break

      case 1:
        this.gotoPage('/form-validation')
        break

      case 2:
        this.gotoPage('/configurable-ui')
        break

      case 3:
        this.gotoPage('/widgets-admin')
        break

      default:
        console.error('unknown key')
    }
  }

  render() {
    return <ConnectedIntlProvider>
      <div>
        <OApplicationHeader
          fixed
          logo={<span className='logo'></span>}
          headerTabs={this.applicationHeaderTabData}
          onSelectTabs={(eventKey) => { this.navigation(eventKey) }}
          subMenu={this.state.showThemeMenu ? this.applicationHeaderSubMenu : undefined} />
        {this.props.children}
        <OPageContainer style={{
          'bottom': '10pxpx',
          'left': '870px',
          'position': 'fixed',
          'z-index': '99999999'
        }}>
          <OWidgetInstance instanceId='RefreshConfig' />
        </OPageContainer>
        <OPageContainer>
          <OWidgetInstance instanceId='AdminNavBar' />
        </OPageContainer>
      </div>
    </ConnectedIntlProvider>
  }
}

const mapStateToProps = (state: AppState) => ({

})

const mapDispatchToProps = (dispatch: Dispatch<AppState>): IDispatchProps => {
  return {
    setMessages: (): void => {
      const config = require('envConfig')
      const lang = config.lang ? config.lang : 'en-US'
      setMessages(lang, dispatch)
    }
  }
}

export default connect<{}, IDispatchProps, IOwnProps>(mapStateToProps, mapDispatchToProps)(AppDesktop)
