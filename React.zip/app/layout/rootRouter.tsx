import { EnterHook, RouterState, RedirectFunction } from 'react-router'
import { Dispatch } from 'redux'
import {
    ChangeHookLookup,
    EnterHookLookup,
    GetComponentLookup
} from '@optima/core-ui-libs/routing'
import { dummyAuthenticationEnterHook, keycloakAuthenticationEnterHook, secureApplicationEnterHook } from '@optima/core-ui-libs/common/hooks'
import { BaseApplicationConfiguration } from '@optima/core-ui-libs/common/reducers/ConfigReducer'
import { getCommonRouteComponents } from '@optima/core-ui-libs/common/pages/routes'
import { WIDGETS_ADMIN_ENTER } from '@optima/core-ui-libs/widgetFramework'

import { AppState } from '../store/AppStore'

import {
    getExampleRoutesComponents,
    CONFIGURABLE_UI_ENTER,
    FORM_VALIDATION_ENTER,
    UI_COMPONENTS_ENTER,
} from '../example/routes'

export const getMainLayoutComponent = (nextState: RouterState, cb?: Function): any => {
    require.ensure([], (require: any) => {
        cb && cb(null, require('./components/AppDesktop').default)
    }, 'main')
}

export const mainRedirect = (): EnterHook => (nextState: RouterState, replace: RedirectFunction, cb?: Function) => {
    replace('/ui-components')
    cb && cb()
}

export const rootEnterHooks = (appConfig: BaseApplicationConfiguration, dispatch: Dispatch<AppState>): EnterHookLookup => {
    return {
        mainRedirect: mainRedirect(),
        secureRoutes: secureApplicationEnterHook(appConfig, dispatch),
        dummyAuthentication: dummyAuthenticationEnterHook(appConfig),
        keycloakAuthentication: keycloakAuthenticationEnterHook(appConfig),
        CONFIGURABLE_UI_ENTER,
        FORM_VALIDATION_ENTER,
        UI_COMPONENTS_ENTER,
        WIDGETS_ADMIN_ENTER
    }
}

export const rootChangeHooks = (appconfig: BaseApplicationConfiguration, dispatch: Dispatch<AppState>): ChangeHookLookup => {
    return {
        // TODO: add hooks
    }
}

export const rootGetComponents: GetComponentLookup = {
    ...getCommonRouteComponents,
    ...getExampleRoutesComponents,
    getMainLayoutComponent
}
