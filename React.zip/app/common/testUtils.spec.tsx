import * as React from 'react'
import { createStore, Store } from 'redux'
import { AppState, appStore, appReducers } from '../store/AppStore'
import { mount, render, ReactWrapper } from 'enzyme'
import { Provider as ReduxProvider } from 'react-redux'

const initialState = appStore({}).getState()

export const createTestStore = (state?: AppState): Store<AppState> => {
    if (state) {
        const stateMerged: AppState = Object.assign(initialState, state)
        return createStore<AppState>(appReducers, stateMerged)
    }
    else {
        return createStore<AppState>(appReducers)
    }
}

export function mountWithMockStore<P, S>(element: any, testStore?: Store<AppState>): ReactWrapper<P, S> {
    // let testStore = createTestStore(state)
    return mount<P, S>(
        <ReduxProvider store={testStore ? testStore : appStore({})} >
            {element}
        </ReduxProvider>)
}

export function renderWithMockStore<P, S>(element: any, testStore?: Store<AppState>): Cheerio {
    // let testStore = createTestStore(state)
    return render<P, S>(
        <ReduxProvider store={testStore ? testStore : appStore({})} >
            {element}
        </ReduxProvider>)
}

const findRoute = (path: string, routes: any[]) => {
    return routes.find((val) => {
        return (val.path === path)
    })
}
// ////////////////////////////////////////////////////////////////////////////
// router test utility
//  a set of common tests on a page route
//  - route exists
//  - load route component and verify that the correct components is loaded

export const testRoute = (path: string, pageName: string, routes: any[]) => {
    it('renders the ' + pageName + ' page for ' + path + ' route', function () {
        let route = findRoute(path, routes)
        expect(route).to.not.be.null
        expect(route.getComponent).to.be.a('function')
        route.getComponent('next', (err, component) => {
            expect(component).to.not.be.null
            expect(component.name).to.equal(pageName)
        })
    })
}
