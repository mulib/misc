import { combineReducers, Reducer, Store, GenericStoreEnhancer, ReducersMapObject } from 'redux'
import { BaseState, BaseReducersMap } from '@optima/core-ui-libs/store/BaseStore'
import { BaseApplicationConfiguration } from '@optima/core-ui-libs/common/reducers/ConfigReducer'
import { StoreBuilder } from '@optima/core-ui-libs/store/StoreBuilder'

import { ExampleApiState } from '../layout/reducers/exampleApiTypes'
import { exampleApiReducer } from '../layout/reducers/exampleApiMain'

export interface AppState extends BaseState<BaseApplicationConfiguration> {
    exampleApi?: ExampleApiState
}

export const reducersMap: ReducersMapObject = {
    ...BaseReducersMap,
    exampleApi: exampleApiReducer
}

export const appReducers: Reducer<AppState> = combineReducers<AppState>(reducersMap)


/* istanbul ignore next */
const devToolsExtension: GenericStoreEnhancer = window && window.devToolsExtension ? window.devToolsExtension() : f => f

export const appStore = (config: BaseApplicationConfiguration): Store<AppState> => { return StoreBuilder(appReducers, config, devToolsExtension) }
