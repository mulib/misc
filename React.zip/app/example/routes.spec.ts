'use strict'
import * as routes from './routes'
import { should } from 'chai'
should()
import * as sinon from 'sinon'

describe('example', () => {
    describe('routes', () => {
        describe('enter hooks', () => {
            let _console: sinon.SinonStub
            before(() => {
                _console = sinon.stub(console, 'info')
            })
            after(() => {
                _console.restore()
            })

            describe('UI_COMPONENTS_ENTER', () => {
                it('should log a console message', () => {
                    const replace = sinon.stub()
                    const cb = sinon.stub()
                    _console.reset()
                    routes.UI_COMPONENTS_ENTER({ location: { pathname: '/', search: '', query: {}, state: {}, action: 'PUSH', key: '' }, routes: [], params: {}, components: [] }, replace, cb)
                    _console.called.should.equal(true, 'console.info.called')
                })
            })

            describe('CONFIGURABLE_UI_ENTER', () => {
                it('should log a console message', () => {
                    const replace = sinon.stub()
                    const cb = sinon.stub()
                    _console.reset()
                    routes.CONFIGURABLE_UI_ENTER({ location: { pathname: '/', search: '', query: {}, state: {}, action: 'PUSH', key: '' }, routes: [], params: {}, components: [] }, replace, cb)
                    _console.called.should.equal(true, 'console.info.called')
                })
            })

            describe('FORM_VALIDATION_ENTER', () => {
                it('should log a console message', () => {
                    const replace = sinon.stub()
                    const cb = sinon.stub()
                    _console.reset()
                    routes.FORM_VALIDATION_ENTER({ location: { pathname: '/', search: '', query: {}, state: {}, action: 'PUSH', key: '' }, routes: [], params: {}, components: [] }, replace, cb)
                    _console.called.should.equal(true, 'console.info.called')
                })
            })

        })
        describe('getExampleComponents', () => {
            describe('getUIComponent', () => {
                it('Should contain the UIComponent components', (done) => {
                    let expectedComp = undefined
                    const cb = function (var1, comp) {
                        expectedComp = comp
                    }
                    routes.getExampleRoutesComponents.getUIComponent(null, cb)
                    setTimeout(() => {
                        expect(expectedComp).to.exist
                        done()
                    }, 0)
                })
            })

            describe('getValidation', () => {
                it('Should contain the UIComponent components', (done) => {
                    let expectedComp = undefined
                    const cb = function (var1, comp) {
                        expectedComp = comp
                    }
                    routes.getExampleRoutesComponents.getValidation(null, cb)
                    setTimeout(() => {
                        expect(expectedComp).to.exist
                        done()
                    }, 0)
                })
            })

            describe('getConfigurableUI', () => {
                it('Should contain the UIComponent components', (done) => {
                    let expectedComp = undefined
                    const cb = function (var1, comp) {
                        expectedComp = comp
                    }
                    routes.getExampleRoutesComponents.getConfigurableUI(null, cb)
                    setTimeout(() => {
                        expect(expectedComp).to.exist
                        done()
                    }, 0)
                })
            })
            describe('getWidgetsAdmin', () => {
                it('Should contain the WidgetsAdmin components', (done) => {
                    let expectedComp = undefined
                    const cb = function (var1, comp) {
                        expectedComp = comp
                    }
                    routes.getExampleRoutesComponents.getWidgetsAdmin(null, cb)
                    setTimeout(() => {
                        expect(expectedComp).to.exist
                        done()
                    }, 0)
                })
            })
        })
    })
})
