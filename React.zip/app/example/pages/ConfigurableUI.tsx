import { hot } from 'react-hot-loader'
import * as React from 'react'
import { OWidgetInstance } from '@optima/core-ui-libs/widgetFramework'
import { OMarkDown, OPageContainer, OContent, MessageFormatterParams, NumberFormatterParams, DateFormatterParams, WidgetInstanceParams } from '@optima/core-ui-libs/ui-components'

const classes = require('./ConfigurableUI.scss')

interface IConfigurableUIProps { }
interface IConfigurableUIState {
}
export class ConfigurableUI extends React.Component<IConfigurableUIProps, IConfigurableUIState> {

  constructor(props: IConfigurableUIProps) {
    super(props)
  }
  render() {
    return (<OPageContainer>
      <OWidgetInstance instanceId='ConfigurableUI_DemoPage' />
    </OPageContainer>)
  }
}
export default hot(module)(ConfigurableUI)