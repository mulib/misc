export const validationMessages = {
    firstName: 'firstName',
    lastName: 'lastName',
    address: 'address',
    phoneNumber: 'phoneNumber',
    gender: 'gender',
    agree: 'agree',
    status: 'status',
    notifications: 'notifications',
    birthDate: 'birthDate',
    NameOfieldInputType: 'NameOfieldInputType',
    OCheckBox: 'OCheckBox',
    ODropDown: 'ODropDown',
    OSwitch: 'OSwitch',
    ORadio: 'ORadio'
}
