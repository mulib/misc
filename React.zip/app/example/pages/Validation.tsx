import { hot } from 'react-hot-loader'
import * as React from 'react'
import OInput from '@optima/core-ui-libs/ui-components/Validation/components/OInput'
import OCheckBox from '@optima/core-ui-libs/ui-components/Validation/components/OCheckBox'
import ORadioButton from '@optima/core-ui-libs/ui-components/Validation/components/ORadioButton'
import OFieldSet from '@optima/core-ui-libs/ui-components/Validation/components/OFieldSet'
import { ODropDown } from '@optima/core-ui-libs/ui-components/Validation/components/ODropDown'
import ODatePicker from '@optima/core-ui-libs/ui-components/Validation/components/ODatePicker'
import OButton from '@optima/core-ui-libs/ui-components/Validation/components/OButton'
import OForm from '@optima/core-ui-libs/ui-components/Validation/components/OForm'
import OExtendedData from '@optima/core-ui-libs/ui-components/Validation/components/OExtendedData'
import OSwitch from '@optima/core-ui-libs/ui-components/Validation/components/OSwitch'
import { OPageContainer, OTile, OTileHeader } from '@optima/core-ui-libs/ui-components'
import { Row } from 'react-bootstrap'
import { ExtendedAttribute } from '@optima/core-ui-libs'
import { validationSchemas } from './ValidationSchemas'
import { validationMessages } from './ValidationMessages'
import {
  InputParams, CheckBoxInputParams, ButtonParams, DatePickerParams, SwitchParams, RadioButtonParams,
  DropDownParams, ExtendedDataParams, MessageFormatterParams, IoDropDownListItem
} from '@optima/core-ui-libs/interfaces'
import { OField } from '@optima/core-ui-libs/ui-components/OField'


export interface IValidationProps {
}

export interface IValidationState {
  buttonValid: boolean,
  forceError: boolean
}

export class Validation extends React.Component<IValidationProps, IValidationState>  {
  constructor(props: IValidationProps) {
    super(props)
    this.state = {
      buttonValid: false,
      forceError: false
    }
  }


  handlePreSubmit = (values, formApi) => {
    // console.info(`pre submit is the place to parse and modify form values before submit`)
    // here you can parse and manipulate the values to fit the API
    return values
  }

  // TODO: Implement Form onSubmit
  handleSubmitFailure = (formApi) => {
    // here you can set errors visible to point the user to the error
    this.setState({ forceError: true })
    // here you can count number of fails submits
    // console.info(`number of submits: ${formApi.submits}`)
    // console.info(`errors: ${JSON.stringify(formApi.errors)}`)
  }
  handleOnInputChange = (event) => {
    // console.info(`value of firstName: ${event.target.value}`)
  }
  handleUpdate = (formState) => {
    // console.info(`values: ${JSON.stringify(formState.values)}`)
    // console.info(`errors: ${JSON.stringify(formState.errors)}`)
  }
  handleSubmit = (formApi) => {
    // here i can call the API and pass the values
    console.info(`values: ${JSON.stringify(formApi.values)}`)
  }
  handleButtonStateChanged = (isValid) => {
    this.setState({ buttonValid: isValid })
  }
  dropDownTemplate(item) {
    return (<span className='myCustomMenuItem'>
      <span className='myCustomMenuItemText'>{item.title}</span>
    </span>
    )
  }
  dropDownList = [
    { value: 'Default', title: 'please select status' },
    { value: 'Married', title: 'Married' },
    { value: 'Single', title: 'Single' },
    { value: 'Complicated', title: 'Complicated' }
  ]
  extendedData: ExtendedAttribute[] = [
    { paramId: 0, paramName: 'Integer', paramDataType: 1, isRequired: true, groupingId: '1', attributeDisplayOrder: 6 },
    { paramId: 1, paramName: 'String', paramDataType: 2, validationRules: '[abc]+', isRequired: true, groupingId: '1', attributeDisplayOrder: 4 },
    { paramId: 2, paramName: 'Date', paramDataType: 3, isRequired: true, attributeDisplayOrder: 3 },
    { paramId: 3, paramName: 'Big Integer', paramDataType: 4, isRequired: false, attributeDisplayOrder: 1 },
    { paramId: 4, paramName: 'Boolean', paramDataType: 5, isRequired: true, attributeDisplayOrder: 2 },
    {
      // enumerationSortOrder: 1 1=asc 2=desc , enumerationSortBasis: 1 [1=alpahnumeric, 2=numeric, 3='sortIndex' 4='primaryKey']
      paramId: 5, paramName: 'Enumeration', paramDataType: 1, isRequired: false, enumerationSortOrder: 1, enumerationSortBasis: 1,
      enumerationData: [
        {
          enumerationName: 'GenericEnumeration',
          enumerationData: [
            {
              keyData: [{ fieldName: 'EnumerationKey', fieldValue: 'account_referral' },
              { fieldName: 'Value', fieldValue: '1' }],
              valueData: [{ fieldName: 'DisplayValue', fieldValue: 'Friend' },
              { fieldName: 'IsDefault', fieldValue: 'false' }],
            },
            {
              keyData: [{ fieldName: 'EnumerationKey', fieldValue: 'account_referral' },
              { fieldName: 'Value', fieldValue: '2' }],
              valueData: [{ fieldName: 'DisplayValue', fieldValue: 'Family' },
              { fieldName: 'IsDefault', fieldValue: 'true' }]
            }
          ]
        }
      ]
      , attributeDisplayOrder: 5
    }
  ]

  render() {
    const labelContentParamsMessage: MessageFormatterParams = {
      type: 'message',
      messageId: 'OField.enter.firstName.lastName',
      dataAttribute: 'name'
    }

    const fieldDataSource = {
      name: {
        firstName: 'John',
        lastName: 'snow'
      }
    }
    const textInputTypeParams: InputParams = {
      type: 'text',
      size: 'medium',
      id: 'OInputName',
      className: 'OClassName',
      disabled: false,
      required: true,
      field: 'NameOfieldInputType',
      clear: false,
      name: 'NameOfieldInputType',
      placeholder: 'Plase enter your name',
      defaultValue: 'My Name is JS',
      label: labelContentParamsMessage,
      forceError: {
        show: false,
        messageId: 'Please enter given name'
      }
    }
    const checkBoxLabel: MessageFormatterParams = {
      type: 'message',
      messageId: 'OField.checkbox.text'
    }

    const checkBoxConfig: CheckBoxInputParams = {
      type: 'checkbox',
      id: 'checkBox',
      label: checkBoxLabel,
      className: 'checkBoxClass',
      disabled: false,
      required: true,
      field: 'OCheckBox',
      defaultChecked: true,
      name: 'OCheckBox',
      forceError: {
        show: false,
        messageId: 'Error in checkbox'
      }
    }

    const buttonLabel: MessageFormatterParams = {
      type: 'message',
      messageId: 'OField.button.text'
    }
    const buttonConfig: ButtonParams = {
      type: 'button',
      id: 'button',
      primary: true,
      submit: true,
      label: buttonLabel
    }

    const datePickerLabel: MessageFormatterParams = {
      type: 'message',
      messageId: 'OField.button.text'
    }
    const datePickerConfig: DatePickerParams = {
      type: 'datePicker',
      size: 'medium',
      required: true,
      forceError: {
        show: false,
        messageId: 'Error in date Picker'
      }
      ,
      field: 'birthDate',
      placeholder: 'DD/MM/YYY',
      label: datePickerLabel,
      id: 'birthDate',
      disablePastDays: true,
      dateFormat: 'DD/MMM/YYYY',
      enableOutsideDays: true
    }
    const switchLabel: MessageFormatterParams = {
      type: 'message',
      messageId: 'OField.button.text'
    }
    const switchConfig: SwitchParams = {
      type: 'switch',
      field: 'OSwitch',
      id: 'SwitchId',
      label: switchLabel,
      forceError: {
        show: false,
        messageId: 'Error in switch'
      }
    }

    const dropDownLabel: MessageFormatterParams = {
      type: 'message',
      messageId: 'OField.dropdown.text',
      dataAttribute: 'ODropDown'
    }
    const dropDownList: IoDropDownListItem[] = [
      { value: 'Default', title: 'please select status' },
      { value: 'Married', title: 'Married' },
      { value: 'Single', title: 'Single' },
      { value: 'Complicated', title: 'Complicated' }
    ]
    const dropDownConfig: DropDownParams = {
      type: 'dropDown',
      defaultValue: 'Married',
      field: 'ODropDown',
      required: true,
      id: 'DropDownId',
      label: dropDownLabel,
      list: dropDownList,
      className: 'ODropDownClass',
      disabled: false,
      forceError: {
        show: false,
        messageId: 'Error in date Picker'
      }
    }

    const label: MessageFormatterParams = {
      type: 'message',
      messageId: 'OField.radioBtton.label'
    }

    const radioLabelMale: MessageFormatterParams = {
      type: 'message',
      messageId: 'OField.radioBtton.labelMale'
    }

    const radioLabelFeMale: MessageFormatterParams = {
      type: 'message',
      messageId: 'OField.radioBtton.labelFeMale'
    }

    const radioConfig: RadioButtonParams = {
      type: 'radioButton',
      field: 'ORadio',
      name: 'ORadio',
      id: 'RadioIdOne',
      defaultChecked: true,
      label: label,
      radioLabels: [
        radioLabelMale,
        radioLabelFeMale
      ],
      values: ['Male', 'Female'],
      forceError: {
        show: false,
        messageId: 'Error in radio'
      }
    }

    const extendedDataConfig: ExtendedDataParams = {
      type: 'extendedData',
      extendedData: this.extendedData,
      id: 'OExtendedDataId'
    }
    return (
      <OPageContainer id='validation' className='validationPage'>
        <Row>
          <OTile xs={12} md={12} minHeight='200px' id='colors'>
            <OForm
              id='myForm'
              formDidUpdate={this.handleUpdate}
              onSubmit={this.handleSubmit}
              onSubmitFailure={this.handleSubmitFailure}
              onButtonStateChanged={this.handleButtonStateChanged}
              preSubmit={this.handlePreSubmit}
              extendedData={this.extendedData}
              validationSchemas={validationSchemas}
              validationMessages={validationMessages}>
              <div>
                <OTileHeader title='pre-define validation rules' subtitle='validated fields' />
                <div className='contentPadding' style={{ width: '400px' }}>
                  <OInput required forceError={{ show: this.state.forceError }} field='firstName' placeholder='First name' label='First name' id='firstName' onChange={this.handleOnInputChange} size='medium' defaultValue='xxx' />
                  <OInput forceError={{ show: this.state.forceError, messageId: 'this is very customized message' }} field='lastName' placeholder='Last name' label='Last name' id='lastName' clear size='medium' />
                  <OInput required forceError={{ show: this.state.forceError }} field='phoneNumber' placeholder='Phone number' label='Phone number' id='phoneNumber' size='medium' />
                  <OCheckBox defaultChecked required forceError={{ show: this.state.forceError }} field='agree' label='Agree to terms' id='agree' />
                  <OSwitch required forceError={{ show: this.state.forceError }} field='notifications' label='Receive notifications' id='notifications' />
                  <ODatePicker required forceError={{ show: this.state.forceError }} field='birthDate' placeholder='DD/MM/YYY' label='Birth date' id='birthDate' disablePastDays={true} dateFormat='DD/MMM/YYYY' enableOutsideDays={true} />
                  <OFieldSet label='Gender' required>
                    <ORadioButton label='Male' field='gender' name='gender' id='male' value='male' defaultChecked />
                    <ORadioButton label='Female' field='gender' name='gender' id='female' value='female' />
                  </OFieldSet>
                  <ODropDown required id='status' field='status' label='Status' list={this.dropDownList} template={this.dropDownTemplate} defaultValue={'Married'} />
                </div>
                <OTileHeader title='Extended data' subtitle='fields and validation created dynamically' />
                <div className='contentPadding' style={{ width: '400px' }}>
                  <OExtendedData id='validation.extendedData' forceError={{ show: this.state.forceError }} display={{ boolean: 'switch' }} extendedData={this.extendedData} />
                </div>
                <div className='contentPadding'>
                  <OButton id='Validation.button' primary submit valid={this.state.buttonValid} label={'Submit'}></OButton>
                </div>
              </div>
              <div>
                <OTileHeader title='Field Descripter' subtitle='View type configuration' />
                <div className='contentPadding' style={{ width: '400px' }}>
                  <OField fieldParams={textInputTypeParams} dataSource={fieldDataSource} className='x' id='z' />
                  <OField fieldParams={checkBoxConfig} dataSource={fieldDataSource} className='xx' id='zz' />
                  <OField fieldParams={datePickerConfig} dataSource={fieldDataSource} className='xxxx' id='zzzz' />
                  <OField fieldParams={dropDownConfig} dataSource={fieldDataSource} className='xxxxx' id='zzzzz' />
                  <OField fieldParams={switchConfig} dataSource={fieldDataSource} className='xxxxxxx' id='zzzzzz' />
                  <OField fieldParams={radioConfig} dataSource={fieldDataSource} className='xxxxxxxx' id='zzzzzzz' />
                  <OField fieldParams={extendedDataConfig} dataSource={fieldDataSource} className='xxxxxxxxx' id='zzzzzzzz' />
                </div>
                <div className='contentPadding'>
                  <OField fieldParams={buttonConfig} dataSource={fieldDataSource} className='xxx' id='zzz' />
                </div>
              </div>
            </OForm>
          </OTile>
        </Row>
      </OPageContainer>
    )
  }
}

export default hot(module)(Validation)