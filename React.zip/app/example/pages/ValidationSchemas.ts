
export const validationSchemas = {
    firstName: {
        'type': 'object',
        'properties': {
            'firstName': { 'type': 'string' }
        },
        'required': ['firstName']
    },
    lastName: {
        'type': 'object',
        'properties': {
            'lastName': {
                'type': 'string',
                'minLength': 2,
                'maxLength': 7
            },
        },
    },
    phoneNumber: {
        'type': 'object',
        'properties': {
            'phoneNumber': {
                'type': 'string',
                'pattern': '^(\\([0-9]{3}\\))?[0-9]{3}-[0-9]{4}$'
            }
        },
        'required': ['phoneNumber']
    },
    address: {
        'type': 'object',
        'properties': {
            'address': {
                'type': 'string',
                'pattern': '^(\\([0-9]{3}\\))?[0-9]{3}-[0-9]{4}$'
            }
        },
        'required': ['address']
    },
    agree: {
        'type': 'object',
        'properties': {
            'agree': {
                'enum': [true]
            }
        },
        'required': ['agree']
    },
    notifications: {
        'type': 'object',
        'properties': {
            'notifications': {
                'enum': [true]
            }
        },
        'required': ['notifications']
    },
    gender: {
        'type': 'object',
        'properties': {
            'gender': {
                'enum': ['male', 'female']
            }
        },
        'required': ['gender']
    },
    status: {
        'type': 'object',
        'properties': {
            'status': {
                'enum': ['Married', 'Single', 'Complicated']
            }
        },
        'required': ['status']
    },
    birthDate: {
        'type': 'object',
        'properties': {
            'birthDate': {
                'format': 'full-date'
            }
        },
        'required': ['birthDate']
    },
    NameOfieldInputType: {
        'type': 'object',
        'properties': {
            'NameOfieldInputType': { 'type': 'string' }
        },
        'required': ['NameOfieldInputType']
    },
    OCheckBox: {
        'type': 'object',
        'properties': {
            'OCheckBox': {
                'enum': [true]
            }
        },
        'required': ['OCheckBox']
    },
    ODropDown: {
        'type': 'object',
        'properties': {
            'ODropDown': {
                'enum': ['Married', 'Single', 'Complicated']
            }
        },
        'required': ['ODropDown']
    },
    OSwitch: {
        'type': 'object',
        'properties': {
            'OSwitch': {
                'enum': [true]
            }
        },
        'required': ['OSwitch']
    },
    ORadio: {
        'type': 'object',
        'properties': {
            'ORadio': {
                'enum': ['RadioIdOne', 'RadioIdTwo']
            }
        },
        'required': ['ORadio']
    }
}