import { hot } from 'react-hot-loader'
import { ExtendedAttribute, ExtendedData } from '@optima/core-ui-libs'
import {
  HelpPresentationProviderContract,
  HelpStorageProviderContract,
  HelpStorageProviderDataDefinition,
  HelpStorageProviderFlexiDataDefinition,
  IApplicationHeaderActions,
  IApplicationHeaderPageTitle,
  IApplicationHeaderSubMenu,
  IApplicationHeaderTabData,
  IOCollapsibleTabsData,
  IODropDownMultiselectStatus,
  IORadioGroupListItem,
  IOTableData,
  IOWizardData,
  IOVerticalTabsData,
  OAccordion,
  OAlert,
  OAlerts,
  OApplicationHeader,
  OAutoComplete,
  OButton,
  OCheckBox,
  OCollapsibleTabs,
  OCounter,
  ODataExport,
  ODatePicker,
  ODatePickerPeriod,
  ODateRangePicker,
  ODesktop,
  ODocumentActions,
  ODocumentDownload,
  ODocumentThumbnail,
  ODocumentUpload,
  ODropDown,
  OContent,
  OEdit,
  OEditInPlace,
  OExtendedData,
  OFilter,
  OFilterPanel,
  OHelp,
  OImage,
  OInput,
  OLabel,
  OMasterDetail,
  OMasterDetailGroup,
  OMasterDetailItem,
  OMobile,
  OModal,
  OPageContainer,
  OPager,
  ORadioGroup,
  OScroll,
  OSearchInput,
  OSwitch,
  OTab,
  OTable,
  OTablet,
  OTabs,
  OTile,
  OTileHeader,
  OTooltip,
  OUsageBar,
  OVerticalTabs,
  OView,
  OWizard,
  SortDirections,
  Type,
} from '@optima/core-ui-libs/ui-components'
import * as moment from 'moment'
import * as React from 'react'
import { Col, Image, Label, Panel, Row, Table } from 'react-bootstrap'

const config = require('envConfig')
const styles = require('./UIComponents.scss')
const car = require('@optima/theme-care/styles/images/Icons/car.svg')
const cloud = require('@optima/theme-care/styles/images/Icons/cloudRefreshOrange.svg')
const data = require('@optima/theme-care/styles/images/Icons/databaseOrange.svg')
const magazin = require('@optima/theme-care/styles/images/Icons/magazine.svg')
const tv = require('@optima/theme-care/styles/images/Icons/tvBlack.svg')
const wireless = require('@optima/theme-care/styles/images/Icons/wirelessOrange.svg')
const tiles = require('../codeExamples/tiles.png')
const tiles_sc = require('../codeExamples/tiles_sc.png')
const colors = require('../codeExamples/colors.png')
const typo = require('../codeExamples/typo.png')
const pager = require('../codeExamples/pager.png')
const font = require('../codeExamples/font.png')
const buttons = require('../codeExamples/buttons.png')
const radio = require('../codeExamples/radio.png')
const radio1 = require('../codeExamples/radio1.png')
const radio2 = require('../codeExamples/radio2.png')
const dropdown1 = require('../codeExamples/dropdown1.png')
const dropdown2 = require('../codeExamples/dropdown2.png')
const dropdown3 = require('../codeExamples/dropdown3.png')
const tabs = require('../codeExamples/tabs.png')
const modal = require('../codeExamples/modal.png')
const input = require('../codeExamples/input.png')
const image = require('../codeExamples/image.png')
const image1 = require('../codeExamples/image1.png')
const searchinput = require('../codeExamples/searchinput.png')
const searchinput1 = require('../codeExamples/searchinput1.png')
const filter = require('../codeExamples/filter.png')
const filter1 = require('../codeExamples/filter1.png')
const form = require('../codeExamples/form.png')
const alert1 = require('../codeExamples/alert.png')
const autocomplete = require('../codeExamples/autocomplete.png')
const checkbox = require('../codeExamples/checkbox.png')
const checkbox1 = require('../codeExamples/checkbox1.png')
const daterangepicker = require('../codeExamples/daterangepicker.png')
const datepicker_csr = require('../codeExamples/datepicker_csr.png')
const datepicker_sc = require('../codeExamples/datepicker_sc.png')
const datepickerperiod_sc = require('../codeExamples/datepickerperiod_sc.png')
const datepickeralwaysopened_csr = require('../codeExamples/datepickeralwaysopened_csr.png')
const masterdetail = require('../codeExamples/masterdetail.png')
const table = require('../codeExamples/table.png')
const tableSticky = require('../codeExamples/tableSticky.png')
const imgTabsSelfCareSecondary1 = require('../codeExamples/imgTabsSelfCareSecondary1.PNG')
const oSwitchImg = require('../codeExamples/oSwitchImg.png')
const documentUpload = require('../codeExamples/documentUpload.png')
const documentActions = require('../codeExamples/documentactions.png')
const documentDownload = require('../codeExamples/documentDownload.png')
const documentThumbnail = require('../codeExamples/documentThumbnail.png')
const tooltipCode = require('../codeExamples/tooltipCode.png')
const owizardDetail = require('../codeExamples/owizardDetail.PNG')
const collapsibleTabs = require('../codeExamples/collapsibleTabs.png')
const collapsibleList = require('../codeExamples/collapsibleTabsList.png')
const oWizardStepDetails = require('../codeExamples/OWizardStepDetails.PNG')
const dataExport = require('../codeExamples/dataexport.png')
const help = require('../codeExamples/help.png')
const responsive = require('../codeExamples/responsive.png')
const scrollTo = require('../codeExamples/scrollTo.png')
const usageBar = require('../codeExamples/usageBar.PNG')
const counter = require('../codeExamples/counter.PNG')
const counter1 = require('../codeExamples/counter1.PNG')
const exdata = require('../codeExamples/OExtendedData.png')
const rangeDisabled = {
  after: new Date()
}
const accordion1 = require('../codeExamples/accordionData.png')
const accordion2 = require('../codeExamples/accordion.png')
const VerticalTabs = require('../codeExamples/OVerticalTab.png')
const VerticalTabs1 = require('../codeExamples/OVerticalTab1.png')
const OApplicationHeaderImage1 = require('../codeExamples/OApplicationHeaderImage1.png')
const OApplicationHeaderImage2 = require('../codeExamples/OApplicationHeaderImage2.png')
const label = require('../codeExamples/oLabel.png')
const contentDataSource = {
  firstName: 'michael',
  lastName: 'levi',
  friends: ['haim', 'moshe', 'nimrod'],
  billingAddress: {
    type: 'residential',
    addressLine1: '11 zibi st',
    addressLine2: { aptNumber: '11', zibi: [1, 2, 3] }
  }
}
const contentParams = {
  type: 'dataMapping',
  dataAttribute: 'billingAddress',
  path: 'addressLine2.zibi[2]'
}
enum Api {
  Accordion,
  Alerts,
  Autocomplete,
  Buttons,
  Checkbox,
  CollapsibleTabs,
  Colors,
  DatePicker,
  DatePickerVisible,
  DatePickerVisibleSC,
  DatePickerPeriod,
  DateRangePicker,
  DocumentActions,
  DocumentDownload,
  DocumentThumbnail,
  DocumentUpload,
  Dropdown,
  Filter,
  Forms,
  GridAndTiles,
  Images,
  Input,
  MasterDetail,
  Modal,
  Pager,
  RadioButtons,
  Responsive,
  ScrollTo,
  SearchInput,
  Table,
  TableSticky,
  Tabs,
  TabsAlternate1,
  TabsAlternate2,
  ToggleSwitch,
  Tooltip,
  Typography,
  Wizard,
  DataExport,
  Help,
  usageBar,
  counter,
  FilterPanel,
  ExtendedData,
  VerticalTabs,
  OApplicationHeader,
  Label
}

export interface IUIComponentsProps { }
export interface IUIComponentsState {
  currentTheme?: 'care' | 'self-care',
  inputValue?: any,
  OTabsData: Array<any>,
  searchInputValue?: string | number,
  searchDropDownValue?: string | number,
  filterSearchDropDownValue?: string | number,
  filterSearchInputValue?: any,
  filterSortDropDownValue?: string | number,
  openedAPI?: Api,
  dropDownValue?: string | number,
  dropDownValue1?: string | number,
  dropDownValue2?: string | number,
  clearAutoCompleteValue?: string,
  noCaretAutoCompleteValue?: string,
  radioGroupValue?: any,
  radioGroupValue1?: any,
  myCheckBoxGroup?: any,
  openedModal?: number,
  emailValue?: string,
  emailConfirmValue?: string,
  tileLoading?: boolean,
  pageLoading?: boolean,
  isEditMode?: boolean,
  isEditLoading?: boolean,
  selectedIndex?: number
  selectedIndex1?: number,
  datePickerValue?: Date,
  datePickerValue2?: Date,
  datePickerValueFrom?: Date,
  datePickerValueTo?: Date,
  dateRangePickerValueFrom: Date,
  dateRangePickerValueTo: Date,
  colors?: any,
  fonts?: any,
  eventKey?: any,
  oSwitch?: any
  myAwesomeExpandedFilter?: { panelVisible?: boolean },
  wizardData?: IOWizardData[],
  userAccesstype?: any
  isFilterDisabled: boolean,
  filterCheckBox: any,
  selectedFilters: any,
  searchInput1Value?: string | number,
  searchInput2Value?: string | number,
  searchInput3Value?: string | number,
  searchInput4Value?: string | number,
  searchInput5Value?: string | number,
  dropDownValue3?: string | number,
  dropDownValue4?: string | number,
  dropDownValue5?: string | number,
  dropDownValue6?: IODropDownMultiselectStatus[],
  extendedDataValues?: ExtendedData[],
  base64?: string
}
export class UIComponents extends React.Component<IUIComponentsProps, IUIComponentsState> {
  constructor(props: any) {
    super(props)
    this.state = {
      currentTheme: 'care',
      OTabsData: [
        { title: 'Title1', content: 'content 0' },
        { title: 'Title2', content: 'content 1' },
        { title: 'Title3', content: 'content 2' },
        { title: 'Title4', content: 'content 3' }
      ],
      inputValue: '',
      searchInputValue: '',
      searchDropDownValue: 0,
      filterSearchDropDownValue: 0,
      filterSearchInputValue: '',
      filterSortDropDownValue: 0,
      openedAPI: undefined,
      dropDownValue: 0,
      dropDownValue1: 11,
      dropDownValue2: 22,
      dropDownValue6: [
        { title: 'AAA', selected: false, value: 0 },
        { title: 'BBB', selected: false, value: 1 },
        { title: 'CCC', selected: false, value: 2 },
        { title: 'DDD', selected: false, value: 3 },
        { title: 'EEE', selected: false, value: 4 },
      ],
      clearAutoCompleteValue: '',
      noCaretAutoCompleteValue: '',
      radioGroupValue: 'myRadio2',
      radioGroupValue1: 'myRadio13',
      myCheckBoxGroup: { 'chk1': true, 'chk2': false, 'chk3': false, 'chk4': false },
      openedModal: undefined,
      emailValue: '',
      emailConfirmValue: '',
      // tileLoading: true,
      // pageLoading: true,
      isEditMode: false,
      isEditLoading: false,
      selectedIndex: 0,
      selectedIndex1: 0,
      datePickerValue: new Date(),
      datePickerValue2: new Date(),
      datePickerValueFrom: new Date(),
      datePickerValueTo: moment().add(5, 'day').toDate(),
      dateRangePickerValueFrom: moment().add(1, 'day').toDate(),
      dateRangePickerValueTo: moment().add(3, 'day').toDate(),
      colors: this.csrColors,
      fonts: this.csrFonts,
      oSwitch: { 'chk1': true, 'chk2': true },
      myAwesomeExpandedFilter: { panelVisible: true },
      wizardData: [
        { key: 0, header: ' Step 1', content: 'Content 1', completed: true, current: false },
        { key: 1, header: ' Step 2', content: 'Content 2', completed: false, current: true },
        { key: 2, header: ' Step 3', content: 'Content 3', completed: false, current: false },
        { key: 3, header: ' Step 4', content: 'Content 4', completed: false, current: false }
      ],
      userAccesstype: 'CSR',
      isFilterDisabled: true,
      filterCheckBox: false,
      selectedFilters: { searchInput2: '', dd5: 3, filterChk1: false },
      searchInput1Value: '',
      searchInput2Value: '',
      searchInput3Value: '',
      searchInput4Value: '',
      searchInput5Value: '',
      dropDownValue3: 2,
      dropDownValue4: 10,
      dropDownValue5: 3,
      extendedDataValues: [
        { paramId: 2, paramName: 'String', paramValue: 'abba', isRequired: false, paramDatatype: 2 },
        { paramId: 1, paramName: 'Integer', paramValue: '1', isRequired: true, paramDatatype: 1 }
      ]
    }
  }
  scrollToDataExport = null
  wait = (ms) => new Promise((resolve: Function) => setTimeout(resolve, ms))

  handleEditClose = () => {
    this.setState({ isEditMode: false })
  }
  handleEditSave = () => {
    this.setState({ isEditLoading: true })
    console.info('loading..')
    this.wait(3000).then(() => { this.setState({ isEditLoading: false }) })
    this.wait(3000).then(() => { this.setState({ isEditMode: false }); console.info('saved') })
  }

  handleSearchDropDownSelect = (value) => {
    this.setState({ searchDropDownValue: value })
  }

  handleSearchInputChange = (e) => {
    this.setState({ searchInputValue: e.target.value })
  }

  handleSearchInput1Change = (e) => {
    this.setState({ searchInput1Value: e.target.value })
  }

  handleSearchInput2Change = (e) => {
    this.setState({ searchInput2Value: e.target.value })
  }

  handleSearchInput3Change = (e) => {
    this.setState({ searchInput3Value: e.target.value })
  }

  handleSearchInput4Change = (e) => {
    this.setState({ searchInput4Value: e.target.value })
  }

  handleSearchInput5Change = (e) => {
    this.setState({ searchInput5Value: e.target.value })
  }

  handleFilterSearch = (option, searchText) => {
    console.info('option: ' + option + ' | search for: ' + searchText)
  }

  handleFilterSort = (value) => {
    console.info('sort by: ' + value)
  }

  handleFilterClearAll = (e) => {
    this.setState({ dropDownValue3: 2, dropDownValue4: 10, searchInput4Value: '' })
  }

  handleFilterPanelSearch = (e) => {
    let _filters = Object.assign({}, this.state.selectedFilters)
    _filters[e.target.id] = e.target.value
    this.setState({ searchInput5Value: e.target.value, selectedFilters: _filters, isFilterDisabled: false })
  }

  handleFilterPanelDropDown = (value) => {
    let _filters = Object.assign({}, this.state.selectedFilters)
    _filters['dd5'] = value
    this.setState({ dropDownValue5: value, selectedFilters: _filters, isFilterDisabled: false })
  }

  handleFilterPanelCheckbox = (target) => {
    let _filters = Object.assign({}, this.state.selectedFilters)
    _filters[target.value] = target.checked
    this.setState({ filterCheckBox: target.checked, selectedFilters: _filters, isFilterDisabled: false })
  }

  handleFilterPanelClear = (e) => {
    this.setState({ searchInput5Value: '', dropDownValue5: 3, filterCheckBox: undefined, isFilterDisabled: true, selectedFilters: { searchInput2: '', dd5: 3, filterChk1: false } })
  }

  handleFilterPanelApply = (e) => {
    console.info(this.state.selectedFilters)
  }

  handleSearch1Clear = (e) => {
    this.setState({ searchInput1Value: '' })
  }

  handleSearch2Clear = (e) => {
    this.setState({ searchInput2Value: '' })
  }

  handleSearch4Clear = (e) => {
    this.setState({ searchInput4Value: '' })
  }

  handleSearch5Clear = (e) => {
    this.setState({ searchInput5Value: '' })
  }

  handleSearch = () => {
    console.info('option: ' + this.state.searchDropDownValue + ' | search for: ' + this.state.searchInputValue)
  }
  handleInputChange = (e) => {
    this.setState({ inputValue: e.target.value })
  }
  handleEmailChange = (e) => {
    this.setState({ emailValue: e.target.value })
  }
  handleEmailChangeConfirm = (e) => {
    this.setState({ emailConfirmValue: e.target.value })
  }
  handleInputClear = (e) => {
    this.setState({ inputValue: '' })
  }
  handleContextMenuSelect = (key, row) => {
    console.info('key: ' + key, ' row: ' + row)
  }
  onExpandFilter = (expandFilter: boolean) => {
    this.setState({ myAwesomeExpandedFilter: { panelVisible: expandFilter } })
  }
  contextMenuValues = [
    { key: 'edit', value: 'Edit' },
    { key: 'expire', value: 'Expire' },
    { key: 'duplicate', value: 'Duplicate' },
  ]

  scTableDataHeader(obj) {
    return (
      <div id='tableHeaderCell' className='tableHeaderCell' >
        {obj.icon && <Image className='tableHeaderIcon' src={obj.icon} />}
        <div className='tableHeaderCellDescr'>
          {obj.title && <div className='font-b4 color-c1 tableHeaderTitle'>{obj.title}</div>}
          {obj.subTitle && <div className='font-b11 color-c1 tableHeaderSubTitle'>{obj.subTitle}</div>}
        </div>
      </div>
    )
  }

  scTableDataTatle(obj) {
    return (
      <div id='tableRowCell' className='tableRowCell' >
        {obj.title && <div className='font-b4 color-c1 tableRowTitle'>{obj.title}</div>}
        <div className='tableRowCellDescr'>
          {obj.icon && <Image className='tableRowIcon' src={obj.icon} />}
          {obj.subTitle && <div className='font-b8 color-c1 tableRowSubTitle'>{obj.subTitle}</div>}
        </div>
        {obj.comment && <div className='font-b7 color-c1 tableRowComment'>{obj.comment}</div>}
      </div>
    )
  }

  componentWillMount() {
    // this.stopPageLoad()
    // this.stopTileLoad()
    this.data = {
      // selectAll: true, // select all rows by default
      // breakLongText: true, // will break long text will make the table less responsive
      headers: [
        { key: 'firstName', value: 'first name', sort: SortDirections.ASC },
        { key: 'lastName', value: 'last name', sort: SortDirections.DESC },
        { key: 'phoneNumber', value: 'phone number' },
        // { key: 'description', value: 'description', width: '100px' }, // setting width will make the table less responsive
        { key: 'description', value: 'description' },
        { key: 'someFancyHeader', value: <OCheckBox checked={this.state.myCheckBoxGroup.chk3} value='chk4' name='myCheckBoxGroup' id='chk4' label='check me!' onChange={this.handleCheckBoxChange.bind(this)} /> },

      ],
      rows: [
        {
          selected: true,
          key: '0',
          // expand: 'MyComponent',
          contextMenu: this.contextMenuValues,
          cells: [
            { key: 'firstName', value: 'John' },
            { key: 'lastName', value: 'snow' },
            { key: 'phoneNumber', value: '052-6155521' },
            { key: 'description', value: 'king of the north' },
            { key: 'someComponent', value: <OButton secondary label='hello john' onClick={() => { console.info('john') }} /> },
          ]
        },
        {
          key: '1',
          expand: 'MyComponent',
          disabled: true,
          cells: [
            { key: 'firstName', value: 'aria' },
            { key: 'lastName', value: 'stark' },
            { key: 'phoneNumber', value: '052-55555' },
            { key: 'description', value: 'no body' },
            { key: 'someComponent', value: <OButton secondary label='hello aria' onClick={() => { console.info('aria') }} /> },
          ]
        },
        {
          key: '2',
          // expand: 'MyComponent',
          cells: [
            { key: 'firstName', value: 'robert' },
            { key: 'lastName', value: 'baratheon' },
            { key: 'phoneNumber', value: '052-55555' },
            { key: 'description', value: 'King of the Seven Kingdoms' },
            { key: 'someComponent', value: <OButton secondary label='hello robert' onClick={() => { console.info('robert') }} /> },
          ]
        }
        ,
        {
          key: '3',
          expand: 'MyComponent',
          cells: [
            { key: 'firstName', value: 'Cersei' },
            { key: 'lastName', value: 'Lannister' },
            { key: 'phoneNumber', value: '052-55555' },
            { key: 'description', value: 'Queen Regent of the Seven Kingdoms' },
            { key: 'someComponent', value: <OButton secondary label='hello cersei' onClick={() => { console.info('cersei') }} /> },
          ]
        }
      ]
    }

    this.stickyData = {
      // selectAll: true, // select all rows by default
      // breakLongText: true, // will break long text will make the table less responsive
      headers: [
        { key: 'dataSChead_col1', value: this.scTableDataHeader({ icon: data, title: 'What', subTitle: 'To Redirect' }) },
        { key: 'dataSChead_col2', value: this.scTableDataHeader({ icon: data, title: 'Which Account', subTitle: 'will be billed' }) },
        { key: 'dataSChead_col3', value: this.scTableDataHeader({ icon: data, title: 'When', subTitle: 'To Redirect' }) },
        { key: 'dataSChead_col4', value: 'Day/Hour', sort: SortDirections.ASC },
      ],
      rows: [
        {
          selected: false,
          key: '0_stc',
          // expand: 'MyComponent',
          contextMenu: this.contextMenuValues,
          cells: [
            { key: 'dataSCrow1_col1', value: this.scTableDataTatle({ icon: data, title: 'All Charges', subTitle: 'Entire Account' }) },
            { key: 'dataSCrow1_col2', value: this.scTableDataTatle({ title: 'South West District', subTitle: '(123456789)' }) },
            { key: 'dataSCrow1_col3', value: this.scTableDataTatle({ comment: '14/12/10 - 14/12/16' }) },
            { key: 'dataSCrow1_col4', value: 'WeekDays Mon-Fri' },
          ]
        },
        {
          selected: false,
          key: '1_stc',
          expand: 'MyComponent',
          cells: [
            { key: 'dataSCrow2_col1', value: this.scTableDataTatle({ icon: data, title: 'All Reccuring Charges', subTitle: 'Entire Account' }) },
            { key: 'dataSCrow2_col2', value: this.scTableDataTatle({ title: 'North West District', subTitle: '(123456789)' }) },
            { key: 'dataSCrow2_col3', value: this.scTableDataTatle({ comment: '15/08/15 - No expiry' }) },
            { key: 'dataSCrow2_col4', value: '' },
          ]
        },
        {
          selected: false,
          key: '2_stc',
          expand: 'MyComponent',
          cells: [
            { key: 'dataSCrow3_col1', value: this.scTableDataTatle({ icon: car, title: 'All Reccuring Charges', subTitle: '123 Renault' }) },
            { key: 'dataSCrow3_col2', value: this.scTableDataTatle({ title: 'West District', subTitle: '(123456789)' }) },
            { key: 'dataSCrow3_col3', value: this.scTableDataTatle({ comment: '25/03/10 - 25/03/16' }) },
            { key: 'dataSCrow3_col4', value: '' },
          ]
        }
        ,
        {
          selected: true,
          key: '3_stc',
          expand: 'MyComponent',
          cells: [
            { key: 'dataSCrow3_col1', value: this.scTableDataTatle({ icon: car, title: 'Usage Charges', subTitle: '123 Audi' }) },
            { key: 'dataSCrow3_col2', value: this.scTableDataTatle({ title: 'South District', subTitle: '(45678910)' }) },
            { key: 'dataSCrow3_col3', value: this.scTableDataTatle({ comment: '08/06/13 - 08/06/14' }) },
            { key: 'dataSCrow3_col4', value: 'Working Hours 08:00 - 17:00' },
          ]
        }
      ]
    }
  }

  stopPageLoad = () => {
    this.wait(4000).then(() => { this.setState({ pageLoading: false }) })
  }
  stopTileLoad = () => {
    this.wait(6000).then(() => { this.setState({ tileLoading: false }) })
  }
  handleDropDownSelect(value) {
    this.setState({ dropDownValue: value }, this.alertChange)
  }
  handleDropDownSelect1(value) {
    this.setState({ dropDownValue1: value })
  }
  handleDropDownSelect2(value) {
    this.setState({ dropDownValue2: value })
  }
  handleDropDownSelect3(value) {
    this.setState({ dropDownValue3: value })
  }
  handleDropDownSelect4(value) {
    this.setState({ dropDownValue4: value })
  }
  handleDropDownSelect6(value) {
    let newInput: IODropDownMultiselectStatus[] = Object.assign([], this.state.dropDownValue6)
    newInput[value].selected = !newInput[value].selected
    this.setState({ dropDownValue6: newInput })
  }
  handleClearAutoCompleteChange = (value) => {
    this.setState({ clearAutoCompleteValue: value })
  }
  handleClearAutoCompleteClear = () => {
    this.setState({ clearAutoCompleteValue: '' })
  }
  handleNoCaretAutoCompleteChange = (value) => {
    this.setState({ noCaretAutoCompleteValue: value })
  }
  handleNoCaretAutoCompleteClear = () => {
    this.setState({ noCaretAutoCompleteValue: '' })
  }
  handleRadioChange(value) {
    this.setState({ radioGroupValue: value }, () => { console.info(value + ' selected') })
  }
  handleRadioChange1(value) {
    this.setState({ radioGroupValue1: value }, () => { console.info(value + ' selected') })
  }

  handleCheckBoxChange(target) {
    /**************************************
    target: {
      name ?: string,
      value ?: string | number | string[],
      checked ?: boolean
    }
    ***************************************/
    let _myCheckBoxGroup = Object.assign({}, this.state.myCheckBoxGroup)
    _myCheckBoxGroup[target.value] = target.checked
    this.setState({ myCheckBoxGroup: _myCheckBoxGroup }, () => { console.info(JSON.stringify(this.state.myCheckBoxGroup)) })
  }

  alertChange() {
    console.info(this.state.dropDownValue)
  }
  switchTheme = (themeName: string) => () => {

    if (themeName === 'care') {
      this.setState({ userAccesstype: 'CSR', colors: this.csrColors, fonts: this.csrFonts, currentTheme: 'care' }, () => { document.getElementsByTagName('BODY').item(0).className = 'CSR' })
    } else {
      this.setState({ userAccesstype: 'SelfCare', colors: this.scColors, fonts: this.scFonts, currentTheme: 'self-care' }, () => { document.getElementsByTagName('BODY').item(0).className = 'SelfCare' })
    }
  }

  onOPagerChanged = (pageNo: number, pageSize: number) => {
    console.info(`Current Page: ${pageNo}\rCurrent Page Size: ${pageSize}`)
  }
  onOPagerChangedSilent = (pageNo: number, pageSize: number) => {
    console.info(`Current Page: ${pageNo}\r Current Page Size: ${pageSize}`)
  }
  handleButtonClick = () => {
    console.info('button click')
  }
  handleOpenAPIClick = (panelNumber: number) => {
    this.setState({ openedAPI: panelNumber })
  }
  handleCloseAPIClick = () => {
    this.setState({ openedAPI: undefined })
  }
  handleOpenModal = (modalNumber: number) => {
    this.setState({ openedModal: modalNumber })
  }
  handleRowButtonClick = (selectedRowKey: string) => {
    console.info('row' + selectedRowKey + 'selected')
  }

  handleTableSort(sortBy: string, sortDirection: SortDirections) {
    console.info(`sort by ${sortBy} ; sort direction: ${sortDirection}`)
  }
  handleTableRowSelect(selectedRows: any) {
    let str = JSON.stringify(selectedRows)
    console.info(`selected rows:  ${str}`)
  }
  handleRowExpand(key: any) {
    console.info(`expand row:  ${key}`)
  }
  handleDateChange = (dateFormatted, date) => {
    this.setState({
      datePickerValue: date
    })
  }
  handleDateChange2 = (dateFormatted, date) => {
    this.setState({
      datePickerValue2: date
    })
  }
  handleDateChangePeriod = (dateFromFormatted, dateFrom, dateToFormatted, dateTo) => {
    this.setState({
      datePickerValueFrom: dateFrom,
      datePickerValueTo: dateTo,
    })
    console.info('from date: ' + dateFromFormatted + ' | ' + dateFrom)
    console.info('to date: ' + dateToFormatted + ' | ' + dateTo)
  }
  handleDayClickExtended = (e, from, to) => {
    this.setState({
      dateRangePickerValueFrom: from,
      dateRangePickerValueTo: to,
    })
    console.info('Date Range selected from:' + from + ' to:' + to)
  }
  handleAccordionSelect(obj) {
    console.info('key ' + obj + ' selected')
  }
  handleExtendedDataChange = (obj: ExtendedData[]) => {
    console.info('Extended Data Changed', obj)
    this.setState({ extendedDataValues: obj })
  }
  handleExtendedDataValidate = () => {
    if (this.extendedDataRef) {
      this.extendedDataRef.isValid()
    }
  }
  showAPI = (index: number) => {
    return (
      <OButton className='showApi' link label={this.state.openedAPI === index ? 'Hide API' : 'Show API'} onClick={this.state.openedAPI === index ? this.handleCloseAPIClick : this.handleOpenAPIClick.bind(this, index)} />
    )
  }
  compatible = (CSR: boolean, SC: boolean) => {
    return (
      <div className='compatible'>
        <Label bsStyle={CSR ? 'success' : 'danger'}>CSR</Label>
        <Label bsStyle={SC ? 'success' : 'danger'}>Self care</Label>
      </div>
    )
  }

  data: IOTableData
  stickyData: IOTableData
  accordionList = [
    { key: '0', header: 'header0', content: 'content0' },
    { key: '1', header: 'header1', content: 'content1' },
    { key: '2', header: 'header2', content: 'content2' },
    { key: '3', header: 'header3', content: 'content3' },
    { key: '4', header: 'header4', content: 'content4' },
    { key: '5', header: 'header5', content: 'content5' },
    { key: '6', header: 'header6', content: 'content6' }
  ]

  collapsibleTabsData: IOCollapsibleTabsData = {
    // defaultActiveKey: 2,
    tabs: [
      { key: 0, label: 'tab 0', content: 'content 0' },
      { key: 1, disabled: true, label: 'tab 1', content: 'content 1' },
      { key: 2, label: 'tab 2', content: 'content 2' },
      { key: 3, label: 'tab 3', content: 'content 3' }
    ]
  }

  verticalTabsData: IOVerticalTabsData = {
    activeKey: 2,
    tabs: [
      { key: 0, content: 'content 0' },
      { key: 1, content: 'content 1', disabled: true },
      { key: 2, content: 'content 2' },
      { key: 3, content: 'content 3' }
    ]
  }
  applicationHeaderPageTitle: IApplicationHeaderPageTitle = {
    title: [
      { key: 0, pageTitle: 'ABOUT', isOpen: false },
      { key: 1, pageTitle: 'DOCUMENTS', isOpen: false },
      { key: 2, pageTitle: 'COMPONENTS', isOpen: false }
    ]

  }
  applicationHeaderTabData: IApplicationHeaderTabData = {
    tabs: [
      { key: 0, content: 'tab 0' },
      { key: 1, content: 'tab 1' },
      { key: 2, content: 'tab 2' },
      { key: 3, content: 'tab 3' }
    ]
  }
  applicationShortCutTabData: IApplicationHeaderActions = {
    activeKey: 0,
    actionTabs: [
      { key: 0, content: <span className='userProfile active'></span> }
    ]
  }

  applicationHeaderSubMenu: IApplicationHeaderSubMenu = {
    tabs: [
      { key: 1, content: 'DocumentsTab', isOpen: false },
      { key: 2, content: 'Components', isOpen: false }
    ]
  }

  applicationHeaderActions: IApplicationHeaderActions = {
    actionTabs: [
      { key: 0, content: <span className='userProfile'></span> },
      { key: 1, content: <span className='userProfile'></span> },
      { key: 2, content: <span className='userProfile'></span> },
      { key: 3, content: <span className='userProfile'></span> }
    ]
  }
  radioListHorizontal: IORadioGroupListItem[] = [
    { key: 'rdb1', value: 'myRadio1', label: 'im disabled', disabled: true },
    { key: 'rdb2', value: 'myRadio2', label: 'select me!' },
    { key: 'rdb3', value: 'myRadio3', label: 'select me!' },
    { key: 'rdb4', value: 'myRadio4', label: 'select me!' },
  ]
  radioListVertical: IORadioGroupListItem[] = [
    { key: 'rdb11', value: 'myRadio11', label: 'im disabled', disabled: true },
    { key: 'rdb12', value: 'myRadio12', label: 'select me!' },
    { key: 'rdb13', value: 'myRadio13', label: 'select me!' },
    { key: 'rdb14', value: 'myRadio14', label: 'select me!' },
  ]
  dropDownList = [
    { value: 0, title: 'AAA', description: 'aaa' }, // value is the only mandatory field
    { value: 1, title: 'BBB', description: 'bbb' },
    { value: 2, title: 'CCC', description: 'ccc' },
    { value: 3, title: 'DDD', description: 'ddd' },
    { value: 4, title: 'EEE', description: 'eee' },
  ]
  dropDownList1 = [
    { value: 10, title: 'AAA', description: 'aaa' }, // value is the only mandatory field
    { value: 11, title: 'BBB', description: 'bbb' },
    { value: 12, title: 'CCC', description: 'ccc' },
    { value: 13, title: 'DDD', description: 'ddd' },
    { value: 'divider' },
    { value: 14, title: 'EEE', description: 'eee' },
    { value: 15, title: 'This is a much longer title', description: ' and a much longer description' },
  ]
  dropDownList2 = [
    { value: 20, title: 'AAA ', description: 'aaa' }, // value is the only mandatory field
    { value: 21, title: 'BBB', description: 'bbb' },
    { value: 22, title: 'CCC', description: 'ccc' },
    { value: 23, title: 'DDD ', description: 'ddd' },
    { value: 24, title: 'EEE', description: 'eee' },
    { value: 25, title: 'FFF', description: ' fff' },
    { value: 26, title: 'GGG', description: ' ggg' },
    { value: 27, title: 'HHH', description: ' hhhh' },
    { value: 28, title: 'III', description: ' iiiii' },
    { value: 29, title: 'This is a longer title', description: ' and a longer description' },
  ]
  dropDownList3 = [
    { value: 0, title: 'AAA', description: 'aaa' }, // value is the only mandatory field
    { value: 1, title: 'BBB', description: 'bbb' },
    { value: 2, title: 'CCC', description: 'ccc' },
    { value: 3, title: 'DDD', description: 'ddd' },
    { value: 4, title: 'EEE', description: 'eee' },
  ]
  dropDownList4 = [
    { value: 10, title: 'AAA', description: 'aaa' }, // value is the only mandatory field
    { value: 11, title: 'BBB', description: 'bbb' },
    { value: 12, title: 'CCC', description: 'ccc' },
    { value: 13, title: 'DDD', description: 'ddd' },
    { value: 'divider' },
    { value: 14, title: 'EEE', description: 'eee' },
    { value: 15, title: 'This is a much longer title', description: ' and a much longer description' },
  ]
  dropDownList5 = [
    { value: 0, title: 'AAA', description: 'aaa' }, // value is the only mandatory field
    { value: 1, title: 'BBB', description: 'bbb' },
    { value: 2, title: 'CCC', description: 'ccc' },
    { value: 3, title: 'DDD', description: 'ddd' },
    { value: 4, title: 'EEE', description: 'eee' },
  ]
  dropDownList6 = [
    { value: 0, title: 'AAA', description: 'aaa' }, // value is the only mandatory field
    { value: 1, title: 'BBB', description: 'bbb' },
    { value: 2, title: 'CCC', description: 'ccc' },
    { value: 3, title: 'DDD', description: 'ddd' },
    { value: 4, title: 'EEE', description: 'eee' },
  ]
  autoCompleteList = [
    { value: 30, title: 'Tyrion Lannister' },
    { value: 31, title: 'Jaime Lannister' },
    { value: 32, title: 'Cersei Lannister' },
    { value: 33, title: 'Daenerys Targaryen' },
    { value: 34, title: 'Petyr Baelish' },
    { value: 35, title: 'Jorah Mormont' },
    { value: 36, title: 'Sansa Stark' },
    { value: 37, title: 'Arya Stark' },
    { value: 38, title: 'Theon Greyjoy' },
    { value: 39, title: 'Bran Stark' },
    { value: 40, title: 'Sandor Clegane (The Hound)' },
    { value: 41, title: 'Joffrey Baratheon )' }
  ]
  smallAutoCompleteList = [
    { value: 30, title: 'AAA' },
    { value: 31, title: 'BBB' },
    { value: 32, title: 'CCC' },
    { value: 33, title: 'DDD' },
    { value: 34, title: 'A longer drop-down value so the text will be truncated' }
  ]
  searchOptions = [
    { value: 0, text: 'phone number' },
    { value: 1, text: 'account id' },
    { value: 2, text: 'email' },
    { value: 3, text: 'whatever' }
  ]
  filterSearchOptions = [
    { value: 0, text: 'phone number' },
    { value: 1, text: 'account id' },
    { value: 2, text: 'email' },
    { value: 3, text: 'whatever' }
  ]
  filterSortOptions = [
    { value: 0, text: 'phone number' },
    { value: 1, text: 'account id' },
    { value: 2, text: 'email' },
    { value: 3, text: 'whatever' }
  ]
  oPagerDDList = [
    { key: 1, value: 6, description: ' Per Page' },
    { key: 2, value: 12, description: ' Per Page' }
  ]
  oPagerCustomDDList = [
    { key: 1, value: 6, description: ' Por pagina' },
    { key: 2, value: 12, description: ' Por pagina' },
    { key: 3, value: 24, description: ' Por pagina' }
  ]
  csrColors = {
    c1: { hex: '#231F20', description: 'Text Color:Black', extraClass: '' },
    c2: { hex: '#02C4D8', description: 'Clickable:Turquise', extraClass: '' },
    c3: { hex: '#7ED960', description: 'Selected Color:Green', extraClass: '' },
    c4: { hex: '#184D8E', description: 'Header:Blue', extraClass: '' },
    c5: { hex: '#FF8C11', description: 'Highlights:Orange', extraClass: ' color-c1' },
    c6: { hex: '#B8C9DE', description: 'Extra Color:Blue Grey', extraClass: '' },
    c7: { hex: '#F3F5F9', description: 'Background Color:Brighter Gray', extraClass: ' color-c1' },
    c8: { hex: '#949CA3', description: 'Labels:Dark Grey', extraClass: '' },
    c9: { hex: '#CCCFD2', description: 'Disabled:Medium Gray', extraClass: '' },
    c10: { hex: '#EAEAEA', description: 'Seperators & Tile Borders:Gray', extraClass: ' color-c1' },
    c11: { hex: '#FFF', description: 'Background:White', extraClass: ' color-c1 borderColor-c9' },
    c12: { hex: '#FF3C48', description: 'Warning/Notifications:Red', extraClass: '' },
    c13: { hex: '#19447C', description: 'Background:Dark Blue', extraClass: '' }
  }
  scColors = {
    c1: { hex: '#3E3E3F', description: 'Dark gray', extraClass: '' },
    c2: { hex: '#738591', description: 'Gray', extraClass: ' color-c14' },
    c3: { hex: '#2A93FE', description: 'Blue, Brand Primary', extraClass: ' color-c14' },
    c4: { hex: '#6DE252', description: 'Green', extraClass: '' },
    c5: { hex: '#F3F5F8', description: 'Alternate gray', extraClass: '' },
    c6: { hex: '#EAEAEA', description: 'Light gray', extraClass: '' },
    c7: { hex: '#C8CCCE', description: 'Mid gray', extraClass: '' },
    c8: { hex: '#FF3946', description: 'Red, Brand Danger', extraClass: ' color-c14' },
    c9: { hex: '#ECF4FF', description: 'Baby blue', extraClass: '' },
    c10: { hex: '#B8C8DF', description: 'Gray blue', extraClass: '' },
    c11: { hex: '#698EBE', description: 'Dark gray blue', extraClass: ' color-c14' },
    c12: { hex: '#1A549D', description: 'Dark blue', extraClass: '' },
    c13: { hex: '#154581', description: 'Navy blue', extraClass: '' },
    c14: { hex: '#FFF', description: 'White', extraClass: '' },
    c15: { hex: '#000', description: 'Black', extraClass: '' },
    c16: { hex: '#0076F8', description: 'Hover blue', extraClass: ' color-c14' },
    c17: { hex: '#FFDA44', description: 'Yellow, Warning', extraClass: '' }
  }
  csrFonts = {
    tags: [{ 'h1': 'regular 30px montserrat' }, { 'h2': 'regular 20px montserrat' }, { 'h3': 'regular 18px montserrat' }, { 'h4': 'light 18px montserrat' }, { 'h5': 'regular 16px montserrat' }, { 'h6': 'regular 15px montserrat' }],
    classes: [{ 'font-h7': 'light 15px montserrat' }, { 'font-b1': 'bold 14px montserrat' }, { 'font-b2': 'regular 14px montserrat' }, { 'font-b3': 'bold 13px montserrat' }, { 'font-b4': 'light 13px montserrat' }]
  }
  scFonts = {
    tags: [{ 'h1': 'extra bold 36px montserrat' }, { 'h2': 'ultra light 36px montserrat' }, { 'h3': 'extra bold 28px montserrat' }, { 'h4': 'semi bold 28px montserrat' }, { 'h5': 'extra bold 22px montserrat' }, { 'h6': 'light 22px montserrat' }],
    classes: [{ 'font-h7': 'regular 22px montserrat' }, { 'font-h8': 'semi bold 28px montserrat' }, { 'font-b1': 'regular 18px montserrat' }, { 'font-b2': 'light 18px montserrat' }, { 'font-b3': 'semi bold 16px montserrat' }, { 'font-b4': 'regular 16px montserrat' }, { 'font-b5': 'light 16px montserrat' }, { 'font-b6': 'semi bold 14px montserrat' }, { 'font-b7': 'regular 14px montserrat' }, { 'font-b8': 'light 14px montserrat' }, { 'font-b9': 'semi bold 12px montserrat' }, { 'font-b10': 'regular 12px montserrat' }, { 'font-b11': 'light 12px montserrat' }, { 'font-b12': 'bold 14px montserrat' }, { 'font-b13': 'extra bold 18px montserrat' }]
  }

  extendedDataRef
  extendedData: ExtendedAttribute[] = [
    { paramId: 2, paramName: 'String', paramDataType: 2, validationRules: '[abc]+', isRequired: false, groupingId: '1', attributeDisplayOrder: 2 },
    { paramId: 1, paramName: 'Integer', paramDataType: 1, isRequired: true, groupingId: '1', attributeDisplayOrder: 1 },
    { paramId: 3, paramName: 'Date', paramDataType: 3, isRequired: true },
    { paramId: 4, paramName: 'Currency', paramDataType: 4, isRequired: false },
    { paramId: 5, paramName: 'Boolean', paramDataType: 5, isRequired: false },
    {
      paramId: 6, paramName: 'Drop down', paramDataType: 1, isRequired: false, enumerationSortOrder: 1, enumerationSortBasis: 3,
      enumerationData: [
        {
          enumerationName: 'GenericEnumeration',
          enumerationData: [
            {
              keyData: [{ fieldName: 'EnumerationKey', fieldValue: 'account_referral' },
              { fieldName: 'Value', fieldValue: '1' }],
              valueData: [{ fieldName: 'DisplayValue', fieldValue: 'Friend' },
              { fieldName: 'IsDefault', fieldValue: 'true' }],
            },
            {
              keyData: [{ fieldName: 'EnumerationKey', fieldValue: 'account_referral' },
              { fieldName: 'Value', fieldValue: '2' }],
              valueData: [{ fieldName: 'DisplayValue', fieldValue: 'Family' },
              { fieldName: 'IsDefault', fieldValue: 'false' }]
            }
          ]
        }
      ]
    }
  ]
  dropDownTemplate(item) {
    return (<span className='myCustomMenuItem'>
      <span className='atitle'>{item.title}</span>
      <span className='description'>{item.description}</span>
    </span>
    )
  }
  dropDownTemplate1(item) {
    return (<span className='myCustomMenuItem'>
      <span className='atitle'>{item.title}</span>
      <span className='description'>{item.description}</span>
    </span>
    )
  }

  onChange = (count: number) => {
    console.info(count)
  }

  dropDownTemplate2(item) {
    return (<span className='myCustomMenuItem'>
      <span className='atitle'>{item.title}</span>
      <span className='description'>{item.description}</span>
    </span>
    )
  }

  dropDownTemplate3(item) {
    return (<span className='myCustomMenuItem'>
      <span className='atitle'>{item.title}</span>
      <span className='description'>{item.description}</span>
    </span>
    )
  }

  dropDownTemplate4(item) {
    return (<span className='myCustomMenuItem'>
      <span className='atitle'>{item.title}</span>
      <span className='description'>{item.description}</span>
    </span>
    )
  }

  dropDownTemplate5(item) {
    return (<span className='myCustomMenuItem'>
      <span className='atitle'>{item.title}</span>
      <span className='description'>{item.description}</span>
    </span>
    )
  }

  dropDownTemplate6(item) {
    return (<span className='myCustomMenuItem'>
      <span className='atitle'>{item.title}</span>
      <span className='description'>{item.description}</span>
    </span>
    )
  }

  hpp: HelpPresentationProviderContract = {
    present(url: string, data: HelpStorageProviderFlexiDataDefinition): void {
      alert('Help Presentation Provider')
    }
  }
  hsp: HelpStorageProviderContract = {
    getDefaultUrl(): string {
      return 'www.amdocs.com'
    },
    getCollection(): HelpStorageProviderDataDefinition {
      return {}
    },
    getApplicationReferences(): HelpStorageProviderDataDefinition {
      return {}
    },
    getPresentationData(): HelpStorageProviderFlexiDataDefinition {
      return {}
    }
  }
  autoCompleteComperator(item, comparer) {
    return (
      item.title.includes(comparer) || item.description.includes(comparer)
    )
  }
  overlayContent = (elem: number) => {
    let contents = [
      <label>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
    labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
    laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
    voluptate velit esse cillum dolore eu fugiat nulla pariatur.
    <hr />
        Excepteur sint occaecat cupidatat
    non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
    </label>
      ,
      <div className='tooltipContent'>
        Monttly Charges<span className='right'>$50.00</span><br />
        One time Charges<span className='right'> $16.00</span>
        <hr />
        Sub Total<span className='right'>$66.00</span>
      </div>
      , <label>Label Tooltip</label>
      , <label>Example content</label>
    ]
    return contents[elem]
  }
  triggerContent = (elem: number) => {
    let contents = [
      <OButton link label='click- top'></OButton>,
      <OButton link label='click- bottom'></OButton>,
      <OButton link label='hover- right'></OButton>,
      <OButton link label='focus|click- left'></OButton>
    ]
    return contents[elem]
  }
  handleOSwitch(target) {
    /**************************************

    target: {
      name ?: string,
      checked ?: boolean
    }
    ***************************************/

    let _oSwitch = Object.assign({}, this.state.oSwitch)
    _oSwitch[target.name] = target.checked
    this.setState({ oSwitch: _oSwitch })
    console.info(`Switch: ${target.name} Checked: ${target.checked}`)
  }

  updateWizardContent(eventKey) {
    console.info('Event Key', eventKey)
    let _wizardData: IOWizardData[] = Object.assign([], this.state.wizardData)
    let _activeItem = _wizardData.find((step, index) => {
      return step.current === true
    })
    let _activeKey = _activeItem ? _activeItem.key : 0
    let _prevKey = eventKey - 1
    if (_wizardData[eventKey].completed || eventKey === _activeKey || ((_prevKey >= 0) && _wizardData[_prevKey].completed || _wizardData[_prevKey].current)) {
      _wizardData[_activeKey].current = false
      _wizardData[eventKey].current = true
      /// _wizardData[_activeKey].completed = true
    }
    this.setState({ wizardData: _wizardData })
  }

  GetBase64File(key) {
    // simulate call to action to get the document's base64 from document management
    this.setState({ base64: '/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAAiAHsDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9CvG3xd0Twx4otPCEeqWS+NNRtJLqx0yaTa8yIfp9775Vf4tj++PJdR17XfE15Il1cXV1P/z6x7/k/wCAJX51fFHxlrXxm/aC1bWbG5m/tPVNbS10qRH2SRJ5/k2xR/4NnyV+yHg3w6/h3QrG3vrkalq6W0Md7qjxJHJeSogRpX29zj8Kw4g4flP2P77/ABRPChOePlNfYPnwtq3h2RGIvNLJ/wB+EV6j4R+K0Vi2j6V4mvra11TVXK6dE58ua4X++6Y+TP8AD/er0u80+2v7VobiGOeJ+Cki7lr87Pj1pusaD8YNbF7qEl5eJOtzb3kn39md8P8A3x9z/gFfK0cDPJ5e1hLmgfoPCHDMc6xc6E63Lywufo8qAciuC+IWtAXNnodrrUWh3MyPdyXUk6RbUT7iZP8Affb/AMAR6v8Awx8VP4w8A6DrD48y7tIZXH+0UG7/AMezWpYaDFa6pqV7I/2i6vnQ7nUDaiJhE+gy5/4G1fYwlzLmPBrUpUas6UviiO8La9D4k8O2OqW4QrcRb3RG3bX/AI0/Bq4bwlqXiTT/AAzpFjClxqs+pWkMtpqd2N/2cumXNy/+x/B/f+5/t13GmeH49NvNUeOTMF9MJxDsGIn2hXP/AALFWfD+mDQNB07T1l84WdukG/u21Mf0qjE5DS/tNh8LdazfXVxc2y6kiX0z/vjsmm2Pv+gFWv8AhEBLoMNzpmpXunan9nSWK6+2zTR79n8aO+x1rYj8MqvhvUNIFw228+0/vtvKec7uf/Q6zJvCGr6lpken3uvhbHy/KnjsbPyXlTGNu/e+z/gFBJDqnim8vfA+iX9oBZ3us/ZI1ZV3/Z/O2b2x/sZP5VLd+ChZ2M0um6jqFnqsSbkvJ76acM//AE0R32OvTjjr/DWzqvh2w1TRW0uWLyrIIqp5HyeTsxsZP7m3bxWRN4T1jVrP7DqXiHz9Pf5ZRBZ+TPMv9x33/wDoCJQBHqnie7vvBuiX1sv2O61p7WGNsBzb+byz/gua0LPwXYWkkE8VxqZuImVzLJqE7ed/vjfterureH7PWNJFhKjQ24CeUYPkeFlxsdP7m3FUrXSfEMc9qJ/ECT2sTfPtsFSaX/fffs/75QUijC8Y5h11LrVYdRl8OJaY8zT5pFFvMWfe8qRfP93Z8/8ABh/Wu202eOXT7Z7OQXdq0amKfzd3mLjhs981ma1pur3Ugk0/Vxpq7cPG9os3vvT/AGvruFaWg6RB4f0Wy021DfZrSFYY9552qMDNID8P4pLj4M/GqOS6iaW58J+IPMlh/v8A2a6/+ISv238O+ILDxVoOn6zpdwl1Yahbx3NtMvR43UMp/I18w/tB/sm+Gta+JEnxVGkXOvz21tuufC8K5h1C5TYkcz552qn30X7/AJaf7WfJdD/aK8eeH9Yu7yPWjcefJ5ktldRF4U/2ET+D/gFfWYiP9rwhOlvE+DxWb0cgq+yxO0z9CuFBPc1+c/7Q/jO38ZfFnXL21bfa25W0Rh/F5P3/APx/fWp4y/aQ8eeL7byZ9XXSbf8AjTS1MW76P98V6t8LfhPD8bJ9J8aeJ9Jm0nULSbdckRbIdb258ucp/A/9/wDv18vm2UYiGHjJn6T4ece5VRzWs6kJfB7sj2v4VWafD34O6N/ari1TT9LSW7d/+WWE3v8AlzXl/wAO/h5f/tGaHb+PviPfas2i65EL3RfBtjfz2VnY2L/PA9z5Lo9zcOmx38w7E37FT5Mn3rxf4et/Fvg/WNAndo7fVLGaxeReqrKhQ/o1eT/s0fEKK48E6d8PPEDpo3xE8IWcGkaportskfykCJdQjHz28ypvR14AbYfnQ1hGPLDlMq9eWIrTrS+3r95g/ET4e337OegXPj34cXurLpGiRte614NvtQnvbO+s0O+d7bznd7a4RN7p5fyPs2Mnz5HpniL4U+Cvi8un+I9Qt7y+M1mn2aa11a8tkaFhvT5IZkU/e/WuS/aY+IUVt4I1H4f6C6av8QfF9nPpGl6PG+6RPNQo91MMfJbwq+93bAwuwfO4rjrX4L+Gdd/aAk8J69Zya3pvhzwDo0FnHNcyoibbq9jd9iP990RPyqznJNF8E6WPjprnwpTVdY8QeB20CDW7nS7zWbmaTRbz7VshjS58zzkSaPzH8p3/AOWOej1Vv/gP4Oh/aW0PwwtvrA0G58J6hqEtl/wkOpbHuUvLJEf/AF/ZHk/77r6B8E/Dfwv8NNNk0/wroFloVtM/nzJYw7DK/wDfdv42/wB6uD1b/k8Pwx/2Iup/+nDT6AMP4j+DrD4V2/w007ww99ptreeO7E3KyalczmbfDNuTfK7ts+RPkzs4rT+Kk2q/B3xdL8TLCW+1LwlLGlv4t0be8wtoF+5qdtH/AANDz5yL9+L5/vx/Pb/aK/4/PhP/ANj3p/8A6Jnp3wjme5+MHxvillaaFNb09VjZtyKp0m1P6mgDg/2iviNqfxE8LeKvCPgDVns7TTdAm1fxH4q02cZsoTavNbWttIP+W83yPv8A4Ifm+86V7V8NNUSH4SeFNT1G6KodCtbq4up3/wCmCM7u1cb4y+G/hj4Ufs7fEDQfCWiWmhaS2katdfZbSMhPNeGR2fHf/wDZWuL8WXk3i34O/Cj4VWE7JeeONOs4NQZW/eQaPDbRvfuf99Nlt/vXQoAyfhP448SWPxK0bx94g1C7bwf8W5prXTtNu/8AV6S0O99K2D+H7TapM7/7fl19ZV558X/hrH8Q/hbqfhmwmTSL5Ykl0i7jXb9hvYWWS1mT02Sohqf4QfE63+JXw30TxDcQ/wBmahcRtFf6fJw1peRSNDcwH/rnNHIn/AaAO569a+dv2lvC+jHT5NQOk2Jvz1uvsyeaf+BYz+tFFe1lX8c+F4u/3E479m3wxo99eRzXGk2NxMhJWSW2RmH0JFfXEfyqAOBiiit84/io4uDP92kSV5D+0j4D8M+KfB5vda8O6Tq95af8e9xf2MU8kP8AuMykr+FFFfPH6OR/s0+BfDfhjwf9t0fw9pWk3l3/AMfFxY2UUMk3++yqC3413dnpNiPiVrGoCyt/t7aTYwm68pfNMYluyELYztBJ4zjk0UUAdRXLXmk2J+JGl6gbK3+3rpN5ALryl80RmW2JTdjO3IBxnHAoooATxtpdlqTaJ9rs4Lr7Nq1rPB50Sv5UgJw65HysMnkc0vh3S7Oz1zxVd29pBBdXeowNcTxxqrzEWtuoLsBliFAAz2GKKKALXjK1gvvDer21zDHcW02n3SSQyqGR1K4IIPBB96wvDvh7SrPxFol3BplnDdQ+Ho7OKeOBFeOAPGfKVgMhOB8o44HFFFAHeV83eLvhf4N1DxVq9zdeEtCubma7leSabTYXd2LEkklckn1NFFAH/9k=' })
  }
  render() {
    let accordionData1 = {
      defaultActiveKey: '1',
      list: [
        {
          key: '0',
          header: <ODocumentThumbnail fileName='someFileName.pdf' fileSize='1.92KB' />,
          body: 'content 0'
        },
        {
          key: '1',
          header: <ODocumentThumbnail fileName='otherFileName.pdf' fileSize='1.93KB' />,
          body: 'content 1'
        },
        {
          key: '2',
          header: <ODocumentThumbnail fileName='differentFileName.pdf' fileSize='1.94KB' />,
          body: 'content 2'
        },
        {
          key: '3',
          header: <ODocumentThumbnail fileName='someFileName(1).pdf' fileSize='1.95KB' />,
          body: 'content 3'
        }

      ]
    }
    let accordionData = {
      defaultActiveKey: '2',
      list: [
        {
          key: '1',
          header: 'header 1',
          body: 'content 1',
          onExpand: () => { this.handleAccordionSelect('1') }
        },
        {
          key: '2',
          header: 'header 2',
          body: 'content 2',
          onExpand: () => { this.handleAccordionSelect('2') }
        },
        {
          key: '3',
          header: 'header 3 (no content)',
          onExpand: () => { this.handleAccordionSelect('3') }
        },
        {
          key: '4',
          header: 'header 1',
          body: 'content 1',
          onExpand: () => { this.handleAccordionSelect('4') }
        }
      ]
    }
    let showColors = Object.keys(this.state.colors).map(key => {
      return <tr key={key}>
        <td>{key}</td>
        <td>{this.state.colors[key].hex}</td>
        <td>{this.state.colors[key].description}</td>
      </tr>
    })

    let colorExamples = Object.keys(this.state.colors).map(key => {
      return <span key={key} className={'color bgColor-' + key + this.state.colors[key].extraClass}>{key}</span>
    })

    let tags = this.state.fonts.tags.map(tag => {
      let tagValue = Object.keys(tag)[0]
      return <tr key={tagValue}>
        <td>{tagValue}</td>
        <td>{tag[tagValue]}</td>
      </tr>
    })

    let classes = this.state.fonts.classes.map(classValue => {
      let className = Object.keys(classValue)[0]
      return <tr key={className}>
        <td>{className}</td>
        <td>{classValue[className]}</td>
      </tr>
    })

    let fontExamples = this.state.fonts.tags.map(tag => {
      let tagValue = Object.keys(tag)[0]
      let component = React.createElement(tagValue, { key: tagValue }, tagValue + '. Lorem ipsum dolor sit amet')
      return component
    })

    fontExamples.push.apply(fontExamples, this.state.fonts.classes.map(classValue => {
      let className = Object.keys(classValue)[0]
      return <p key={className} className={className}>{className}. Lorem ipsum dolor sit amet</p>
    }))

    let fileDetails = {
      id: 1,
      displayValue: 'filename.jpg'
    }
    return (
      <OPageContainer id='uiComponents' className='UIComponents' showLoading={this.state.pageLoading} loadingText='loading...'>

        {/* <Row>
          <OTile xs={12} md={12} height='50px' className='fixedThemeNavigation'>
            <a href='#CSR' onClick={this.switchTheme('care')} style={{ 'margin': '16px', 'display': 'inline-block' }}>CSR </a> |
            <a href='#SelfCare' onClick={this.switchTheme('self-care')} style={{ 'margin': '16px', 'display': 'inline-block' }}> Self-Care</a>
          </OTile>
        </Row > */}
        {/*colors*/}
        <Row>
          <OTile xs={12} md={12} minHeight='200px' id='colors'>
            <OTileHeader title='colors' subtitle=''>
              {this.showAPI(Api.Colors)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.Colors}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <p className='exampleText'>
                  code example show utility classes for color attributes.<br />
                  usually it easier to use colors as scss variables:
                  <code>
                    color:$c3
                    </code>
                </p>
                <div className='codeExample'>
                  <Image src={colors} responsive />
                </div>
                <h2 className='exampleHeader'>classes</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>className prefix</th>
                      <th>description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>bgColor</td>
                      <td>background color</td>
                    </tr>
                    <tr>
                      <td>color</td>
                      <td>font color</td>
                    </tr>
                    <tr>
                      <td>borderColor</td>
                      <td>border color</td>
                    </tr>
                  </tbody>
                </Table>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>className suffix</th>
                      <th>value</th>
                      <th>description</th>
                    </tr>
                  </thead>
                  <tbody>
                    {showColors}
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='contentPadding colors font-b1 color-c11'>
              {colorExamples}
            </div>
          </OTile>
        </Row>
        {/*typography programicaly*/}
        <Row>
          <OTile xs={12} md={12} id='typo'>
            <OTileHeader title='typography' subtitle=''>
              {this.showAPI(Api.Typography)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.Typography}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <p className='exampleText'>
                  code example show utility classes for typo attributes.<br />
                  usually it easier to use font as scss variables:
                  <code>
                    font:$c3;
                    </code><br />
                  for headers, just use it without class and get the font attributes for free:
                    <code>
                    &lt;some title/&gt;
                    </code>
                </p>
                <div className='codeExample'>
                  <Image src={typo} responsive />
                  <br />
                  <Image src={font} responsive />
                </div>

                <h2 className='exampleHeader'>classes</h2>
                <h2 className='exampleHeader'>headers</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>tag name</th>
                      <th>value</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tags}
                  </tbody>
                </Table>
                <h2 className='exampleHeader'>classes</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>className</th>
                      <th>value</th>
                    </tr>
                  </thead>
                  <tbody>
                    {classes}
                  </tbody>
                </Table>
              </div>
            </Panel>

            <div className='contentPadding typo'>
              {fontExamples}

            </div>
          </OTile>
        </Row>
        {/*grid*/}
        <Row>
          <OTile xs={12} md={12}>
            <OTileHeader title='grid and tiles' subtitle='responsive layout and tiles'>
              {this.showAPI(Api.GridAndTiles)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.GridAndTiles}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  {document.getElementsByTagName('BODY').item(0).className === 'CSR' &&
                    <Image src={tiles} responsive />}
                  {document.getElementsByTagName('BODY').item(0).className === 'SelfCare' &&
                    <Image src={tiles_sc} responsive />}
                </div>
                <h2 className='exampleHeader'>OTile props (inherits from react-bootstrap Col props)</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>sm | md | lg | xs</td>
                      <td>number</td>
                      <td></td>
                      <td>The number of columns(out of 12) you wish to span for xs|small|medium|Large devices</td>
                    </tr>
                    <tr>
                      <td>height</td>
                      <td>string</td>
                      <td></td>
                      <td>fix height for the tile to achieve consistent hight to tiles in a row</td>
                    </tr>
                    <tr>
                      <td>minHeight</td>
                      <td>string</td>
                      <td></td>
                      <td>minimum height for the tile</td>
                    </tr>
                  </tbody>
                </Table>
                <h2 className='exampleHeader'>OTileHeader props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>title</td>
                      <td>string</td>
                      <td></td>
                      <td>tile header title</td>
                    </tr>
                    <tr>
                      <td>subtitle</td>
                      <td>string</td>
                      <td></td>
                      <td>tile header subtitle</td>
                    </tr>
                    <tr>
                      <td>onExpandClick</td>
                      <td>function</td>
                      <td></td>
                      <td>event handler for expand click</td>
                    </tr>
                    <tr>
                      <td>onEditClick</td>
                      <td>function</td>
                      <td></td>
                      <td>event handler for Edit click- works together with OEditInPlace</td>
                    </tr>
                  </tbody>
                </Table>
                <h2 className='exampleHeader'>OEditInPlace props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>isEditMode</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>edit mode flag. should be mapped to state in order to toggle edit mode</td>
                    </tr>
                    <tr>
                      <td>onClose</td>
                      <td>function</td>
                      <td></td>
                      <td>event handler for close click. should set isEditMode:false</td>
                    </tr>
                    <tr>
                      <td>onSave</td>
                      <td>function</td>
                      <td></td>
                      <td>event handler for save click. should post data while show loading  then set isEditMode:false (see example)</td>
                    </tr>
                  </tbody>
                </Table>
                <h2 className='exampleHeader'>OTileRow props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>title</td>
                      <td>string</td>
                      <td></td>
                      <td>tile row title</td>
                    </tr>
                    <tr>
                      <td>subtitle</td>
                      <td>string</td>
                      <td></td>
                      <td>tile row subtitle</td>
                    </tr>
                    <tr>
                      <td>value</td>
                      <td>string</td>
                      <td></td>
                      <td>tile row value</td>
                    </tr>
                    <tr>
                      <td>valueIconUrl</td>
                      <td>string</td>
                      <td></td>
                      <td>tile row value icon url</td>
                    </tr>
                    <tr>
                      <td>isValueClickable</td>
                      <td>boolean</td>
                      <td></td>
                      <td>tile row value link visible</td>
                    </tr>
                    <tr>
                      <td>onClick</td>
                      <td>function</td>
                      <td></td>
                      <td>tile row value link onClick event</td>
                    </tr>
                    <tr>
                      <td>isEditable</td>
                      <td>boolean</td>
                      <td></td>
                      <td>tile row edit icon visible</td>
                    </tr>
                    <tr>
                      <td>tooltipValue</td>
                      <td>string</td>
                      <td></td>
                      <td>event row tooltip on title</td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
          </OTile>
        </Row>
        <Row>
          {/*tile with header and loading*/}
          {document.getElementsByTagName('BODY').item(0).className === 'CSR' &&
            <OTile showLoading={this.state.tileLoading} xs={12} md={4} height='220px'>
              <OTileHeader title='Tile' subtitle='subtitle' onExpandClick={() => { console.info('expand') }} >
                <div> extra content</div>
              </OTileHeader>
              <h1 className='contentPadding'>Content</h1>
            </OTile>
          }
          {document.getElementsByTagName('BODY').item(0).className === 'SelfCare' &&
            <OTile showLoading={this.state.tileLoading} xs={12} md={8} height='220px'>
              <OTileHeader title='Title1' subtitle='subtitle' />
              <h1 className='contentPadding'>Content</h1>
              {/* <OTileRow title='Title' subtitle='Subtitle' value='Link text' isEditable={false} onClick={() => console.info('click')} isValueClickable={true} tooltipValue='Tooltip' />
                <OTileRow title='Title' subtitle='Subtitle' value='Value with editable icon' isEditable={true} onClick={() => console.info('click')} isValueClickable={false} valueIconUrl={magazin} />
                <OTileRow title='Title' subtitle='Subtitle' value='Value with editable icon' isEditable={true} onClick={() => console.info('click')} isValueClickable={false} valueIconUrl={magazin} /> */}
            </OTile>
          }
          {/*tile with header and loading and text*/}
          <OTile showLoading={this.state.tileLoading} loadingText='loading...' xs={12} md={4} height='220px'>
            <OTileHeader title='Title2' subtitle='subtitle' />
            <h1 className='contentPadding'>Content</h1>
          </OTile>
          {/*complete example with edit in place*/}
          {document.getElementsByTagName('BODY').item(0).className === 'CSR' &&
            <OTile xs={12} md={4} showLoading={this.state.isEditLoading} height='220px'>
              <OEditInPlace onClose={this.handleEditClose} onSave={this.handleEditSave} isEditMode={this.state.isEditMode}>
                <OTileHeader title='Tile with edit in place' subtitle='' onEditClick={() => { this.setState({ isEditMode: true }); console.info('in edit mode') }} />
                <OAlert visible status='info'>Some message</OAlert>
                <div className='contentPadding'>
                  <p className='fieldLabel'>Phone number:</p>
                  <OView>052-6155521</OView>
                  <OEdit><OInput id='myInput' value='052-6155521' /></OEdit>
                </div>
              </OEditInPlace>
            </OTile>
          }
        </Row>
        {/*buttons*/}
        <Row>
          <OTile xs={12} md={12} minHeight='250px'>
            <OTileHeader title='buttons'>
              {this.showAPI(Api.Buttons)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.Buttons}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={buttons} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>link | primary | secondary | notification</td>
                      <td>boolean</td>
                      <td></td>
                      <td>button type</td>
                    </tr>
                    <tr>
                      <td>big</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>will show big button</td>
                    </tr>
                    <tr>
                      <td>notifications</td>
                      <td>string</td>
                      <td></td>
                      <td>will show balloon with notifications</td>
                    </tr>
                    <tr>
                      <td>onClick</td>
                      <td>event</td>
                      <td></td>
                      <td>click event</td>
                    </tr>
                    <tr>
                      <td>disabled</td>
                      <td>boolean</td>
                      <td></td>
                      <td>button will be visually and functionally disabled</td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='buttons'>

              <OButton link label='link' onClick={this.handleButtonClick} />
              <OButton link disabled label='link disabled' />
              <OButton primary label='primary' />
              <OButton primary label='primary' showLoading />
              <OButton primary disabled label='primary disabled' />
              <OButton secondary label='secondary' />
              <OButton secondary disabled label='secondary disabled' />
              <OButton notification label='notification' />
              <OButton notification disabled label='notification disabled' />
              <OButton primary big label='primary big' />
              {document.getElementsByTagName('BODY').item(0).className === 'CSR' &&
                <div>
                  <OButton secondary label='with notifications' notifications='23' />
                  <OButton secondary label='with notifications' notifications='5' />
                </div>
              }
            </div>
          </OTile>
        </Row>
        {/*radio button*/}
        < Row >
          <OTile xs={12} md={12}>
            <OTileHeader title='radio buttons' subtitle=''>
              {this.showAPI(Api.RadioButtons)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.RadioButtons}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={radio1} responsive />
                  <Image src={radio2} responsive />
                  <Image src={radio} responsive />
                </div>
                <h2>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>groupValue</td>
                      <td>string</td>
                      <td></td>
                      <td>group value. will typically mapped to state. represent the item value (see code example above)</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>name</td>
                      <td>string</td>
                      <td></td>
                      <td>group name (same as html 'name' attribute)</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>list</td>
                      <td>Array&lt;&#123; id: string, value: string, label: string, disabled?: boolean &#125;&gt;</td>
                      <td></td>
                      <td>list of radio buttons</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>label</td>
                      <td>any</td>
                      <td></td>
                      <td>label for the radio button group</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onChange</td>
                      <td>any</td>
                      <td></td>
                      <td>fire onChange events bind with group value. typically you will set the value on state</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>arrange</td>
                      <td>string</td>
                      <td>'vertical'</td>
                      <td>will show th radio buttons horizontally or vertically)</td>
                      <td>'vertical' | 'horizontal'</td>
                    </tr>
                    <tr>
                      <td>cssClass</td>
                      <td>string</td>
                      <td></td>
                      <td>will add custom cssClass to Alert classes</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='radios contentPadding'>
              <ORadioGroup
                id='radioGroup'
                label='Horizontal'
                arrange='horizontal'
                name='myRadioGroup'
                groupValue={this.state.radioGroupValue}
                list={this.radioListHorizontal}
                onChange={this.handleRadioChange.bind(this)} />
            </div>
            <div className='radios contentPadding'>
              <ORadioGroup
                id='radioGroup1'
                label='Vertical'
                name='myRadioGroup1'
                groupValue={this.state.radioGroupValue1}
                list={this.radioListVertical}
                onChange={this.handleRadioChange1.bind(this)}
              />
            </div>
          </OTile>
        </Row >
        {/*checkbox*/}
        < Row >
          <OTile xs={12} md={12}>
            <OTileHeader title='checkbox'>
              {this.showAPI(Api.Checkbox)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.Checkbox}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={checkbox1} responsive />
                  <Image src={checkbox} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>id</td>
                      <td>string</td>
                      <td></td>
                      <td>component ID</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>name</td>
                      <td>string</td>
                      <td></td>
                      <td>Specifies the name of the element</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>value</td>
                      <td>string</td>
                      <td></td>
                      <td>Specifies the value of the element</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>disabled</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>Element is disabled</td>
                      <td>true | false</td>
                    </tr>
                    <tr>
                      <td>checked</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>Element is checked</td>
                      <td>true | false</td>
                    </tr>
                    <tr>
                      <td>onChange</td>
                      <td>any</td>
                      <td></td>
                      <td>fire onChange events bind with group value. typically you will set the value on state</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>label</td>
                      <td>any</td>
                      <td></td>
                      <td>label for the checkbox</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>className</td>
                      <td>string</td>
                      <td></td>
                      <td>will add specfied custom css class to classes</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            {/* controlled checkbox! dont use prop 'checked' */}
            <div className='checkbox contentPadding'>
              <OCheckBox defaultChecked={true} value='chk1' name='myCheckBoxGroup'
                id='chk1' label='check me!' onChange={this.handleCheckBoxChange.bind(this)} />
              <OCheckBox value='chk2' name='myCheckBoxGroup'
                id='chk2' label='check me!' onChange={this.handleCheckBoxChange.bind(this)} />
              <OCheckBox value='chk3' name='myCheckBoxGroup'
                id='chk3' label='check me!' onChange={this.handleCheckBoxChange.bind(this)} />
            </div>
          </OTile>
        </Row >
        {/*drop down*/}
        < Row >
          <OTile xs={12} md={12}>
            <OTileHeader title='dropdown' subtitle=''>
              {this.showAPI(Api.Dropdown)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.Dropdown}>
              <div className='contentPadding'>
                <div className='codeExample'>
                  <Image src={dropdown2} responsive />
                  <Image src={dropdown3} responsive />
                  <Image src={dropdown1} responsive />
                </div>
                <h2>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>className</td>
                      <td>string</td>
                      <td></td>
                      <td>set custom class to the component wrapper ('.oInput myCustomClass')</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>size</td>
                      <td>string</td>
                      <td></td>
                      <td>will set pre-define width per CSR style guide: 130px|240px|300px </td>
                      <td>'large' | 'small' | 'medium'</td>
                    </tr>
                    <tr>
                      <td>id</td>
                      <td>string</td>
                      <td></td>
                      <td>uniq identifier</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>label</td>
                      <td>any</td>
                      <td></td>
                      <td>will show label above the input</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>value</td>
                      <td>any</td>
                      <td></td>
                      <td>dropDown value will typically mapped to state</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onChange</td>
                      <td>any</td>
                      <td></td>
                      <td>fire onChange event bind with dropDown value. typically you will update the value on the component state</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>highlighter</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>will decorate list item with highlighter</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='dropdowns contentPadding'>
              <ODropDown customToggle='(-;' dropDownHeader='Header' size='small' id='xxx' template={this.dropDownTemplate} list={this.dropDownList} value={this.state.dropDownValue} onSelect={this.handleDropDownSelect.bind(this)} label='custom toggle' /> <br />
              <ODropDown size='medium' id='yyy' template={this.dropDownTemplate1} list={this.dropDownList1} value={this.state.dropDownValue1} onSelect={this.handleDropDownSelect1.bind(this)} />
              <ODropDown size='large' id='zzz' template={this.dropDownTemplate2} list={this.dropDownList2} value={this.state.dropDownValue2} onSelect={this.handleDropDownSelect2.bind(this)} label='please select something' highlighter={true} />
              <ODropDown size='small' id='multiselectDD' isMultiselect={true} label='Multiselect Dropdown' template={this.dropDownTemplate6} list={this.dropDownList6} value={this.state.dropDownValue6} onSelect={this.handleDropDownSelect6.bind(this)} highlighter={true} multiSelectLabel='example.ODropDown.multiselect.label' />
            </div>
          </OTile>
        </Row >
        {/*input*/}
        < Row >
          <OTile xs={12} md={12}>
            <OTileHeader title='text input'>
              {this.showAPI(Api.Input)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.Input}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={input} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>type</td>
                      <td>string</td>
                      <td></td>
                      <td>set input type (same as html type attribute) </td>
                      <td>'text' | 'email' | 'password' | 'file' | 'number' | 'textarea'</td>
                    </tr>
                    <tr>
                      <td>placeholder</td>
                      <td>string</td>
                      <td></td>
                      <td>set input placeholder (same as html placeholder attribute) </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>className</td>
                      <td>string</td>
                      <td></td>
                      <td>set custom class to the component wrapper ('.oInput myCustomClass')</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>size</td>
                      <td>string</td>
                      <td></td>
                      <td>will set pre-define width per CSR style guide: 130px|240px|300px </td>
                      <td>'large' | 'small' | 'medium'</td>
                    </tr>
                    <tr>
                      <td>id (mandatory)</td>
                      <td>string</td>
                      <td></td>
                      <td>uniq identifier</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>label</td>
                      <td>any</td>
                      <td></td>
                      <td>will show label above the input</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>value</td>
                      <td>any</td>
                      <td></td>
                      <td>input value will typically mapped to state</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onChange</td>
                      <td>any</td>
                      <td></td>
                      <td>fire onChange event bind with input value. typically you will update the value on the component state</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onClear</td>
                      <td>any</td>
                      <td></td>
                      <td>will show 'X' icon that fires onClear event. typically you will update the value on the component state to the initial value ('')</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='inputs contentPadding'>
              <OInput size='large' value={this.state.inputValue} onChange={this.handleInputChange} onClear={this.handleInputClear} id='txtEmail' type='email' label='Enter your email' placeholder='example@email.com' />
              <OInput size='small' id='txtPassword' type='password' label='Enter a password' placeholder='password' />
              <OInput size='medium' id='txtNumber' type='number' label='Enter a number' placeholder='1234' />
              <OInput id='txtArea' type='textarea' label='Enter text' placeholder='comment...' />
            </div>
          </OTile>
        </Row >
        {/*auto complete*/}
        < Row >
          <OTile xs={12} md={12}>
            <OTileHeader title='autocomplete' subtitle=''>
              {this.showAPI(Api.Autocomplete)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.Autocomplete}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <Image src={autocomplete} responsive />
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>placeholder</td>
                      <td>string</td>
                      <td></td>
                      <td>set input placeholder (same as html placeholder attribute) </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>className</td>
                      <td>string</td>
                      <td></td>
                      <td>set custom class to the component wrapper ('.oInput myCustomClass')</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>size</td>
                      <td>string</td>
                      <td></td>
                      <td>will set pre-define width per CSR style guide: 130px|240px|300px </td>
                      <td>'large' | 'small' | 'medium'</td>
                    </tr>
                    <tr>
                      <td>id</td>
                      <td>string</td>
                      <td></td>
                      <td>uniq identifier</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>label</td>
                      <td>any</td>
                      <td></td>
                      <td>will show label above the input</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>value</td>
                      <td>any</td>
                      <td></td>
                      <td>input value will typically mapped to state</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onChange</td>
                      <td>any</td>
                      <td></td>
                      <td>fire onChange event bind with input value. typically you will update the value on the component state</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onClear</td>
                      <td>any</td>
                      <td></td>
                      <td>will show 'X' icon that fires onClear event, 'X' replaces the caret once text is entered. typically you will update the value on the component state to the initial value ('')</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>caret</td>
                      <td>boolean</td>
                      <td>true</td>
                      <td>to disable the caret, set to false, otherwise the caret is displayed</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>highlight</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>will highlight the filter text for each list item</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='dropdowns contentPadding'>
              <OAutoComplete highlight placeholder='enter something' size='large' label='large, with caret and clear' id='clear' list={this.autoCompleteList} value={this.state.clearAutoCompleteValue} onChange={this.handleClearAutoCompleteChange} onClear={this.handleClearAutoCompleteClear} />
              <OAutoComplete highlight placeholder='enter something' size='small' label='small, no caret, clear' id='nocaret' list={this.autoCompleteList} value={this.state.noCaretAutoCompleteValue} onChange={this.handleNoCaretAutoCompleteChange} onClear={this.handleNoCaretAutoCompleteClear} caret={false} />
            </div>
          </OTile>
        </Row >
        {/*search input*/}
        <Row>
          <OTile xs={12} md={12}>
            <OTileHeader title='search input'>
              {this.showAPI(Api.SearchInput)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.SearchInput}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={searchinput1} responsive />
                  <Image src={searchinput} responsive />
                  <Image src={autocomplete} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>placeholder</td>
                      <td>string</td>
                      <td></td>
                      <td>set input placeholder (same as html placeholder attribute) </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>className</td>
                      <td>string</td>
                      <td></td>
                      <td>set custom class to the component wrapper ('.oInput myCustomClass')</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>id</td>
                      <td>string</td>
                      <td></td>
                      <td>uniq identifier</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>value</td>
                      <td>any</td>
                      <td></td>
                      <td>input value will typically mapped to state</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>value</td>
                      <td>string | number</td>
                      <td></td>
                      <td>input value will typically mapped to state</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>dropDownValue</td>
                      <td>string | number</td>
                      <td></td>
                      <td>dropdown value. will typically mapped to state</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>options</td>
                      <td>{'{ value: number; text: string;}[]'}</td>
                      <td></td>
                      <td>dropdown options</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onSearch</td>
                      <td>any</td>
                      <td></td>
                      <td>fire onSearch event bind with input value and dropdown option value (if provided). typically you will update the value on the component state or post the values to BE</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onBlur</td>
                      <td>any</td>
                      <td></td>
                      <td>use this event to handle input change. will typically update state value</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onDropDownSelected</td>
                      <td>any</td>
                      <td></td>
                      <td>fire onDropDownSelected event bind with dropDown value . typically you will update the value on the component state or post the values to BE</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='contentPadding oSearchWrapper'>
              <OSearchInput placeholder='search something..' dropDownValue={this.state.searchDropDownValue}
                options={this.searchOptions} onSearch={this.handleSearch.bind(this)} value={this.state.searchInputValue}
                onDropDownSelected={this.handleSearchDropDownSelect.bind(this)} id='focusSearch'
                onBlur={this.handleSearchInputChange.bind(this)} onChange={this.handleSearchInputChange.bind(this)}
                searchWithCrossBtn={this.state.userAccesstype === 'SelfCare' ? true : false} />
              <OSearchInput placeholder='search something..' onSearch={this.handleSearch.bind(this)} onSearchClear={this.handleSearch1Clear}
                value={this.state.searchInput1Value} id='searchInput' onBlur={this.handleSearchInput1Change.bind(this)}
                onChange={this.handleSearchInput1Change.bind(this)} searchWithCrossBtn={this.state.userAccesstype === 'SelfCare' ? true : false} />
              {this.state.userAccesstype === 'SelfCare' ? <OSearchInput searchBoxType='extended' placeholder='search something..' onSearch={this.handleSearch.bind(this)}
                value={this.state.searchInput2Value} onSearchClear={this.handleSearch2Clear} id='searchInput' onBlur={this.handleSearchInput2Change.bind(this)}
                onChange={this.handleSearchInput2Change.bind(this)} searchWithCrossBtn={this.state.userAccesstype === 'SelfCare' ? true : false}
                currentIndex={0} numOfResults={3} /> : ''}
            </div>
          </OTile>
        </Row>
        {/*filter*/}
        <Row>
          <OTile xs={12} md={12}>
            <OTileHeader title='filter'>
              {this.showAPI(Api.Filter)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.Filter}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={filter1} responsive />
                  <Image src={filter} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>title</td>
                      <td>string | JSX.Element</td>
                      <td></td>
                      <td>filter title </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>subTitle</td>
                      <td>string | JSX.Element</td>
                      <td></td>
                      <td>filter subtitle </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>sortTitle</td>
                      <td>string | JSX.Element</td>
                      <td></td>
                      <td>sort title </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>className</td>
                      <td>string</td>
                      <td></td>
                      <td>set custom class to the component wrapper ('.oFilter myCustomClass')</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>id</td>
                      <td>string</td>
                      <td></td>
                      <td>uniq identifier</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>sortDropDownValue</td>
                      <td>number</td>
                      <td></td>
                      <td>default value for sort</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>sortOptions</td>
                      <td>{'{value: number, text: string | JSX.Element}[]'}</td>
                      <td></td>
                      <td>dropdown options</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>dropDownValue</td>
                      <td>string | number</td>
                      <td></td>
                      <td>dropdown value. will typically mapped to state</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>options</td>
                      <td>{'{ value: number; text: string | JSX.Element}[]'}</td>
                      <td></td>
                      <td>dropdown options</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onSearch</td>
                      <td>(searchBy,searchValue) => void</td>
                      <td></td>
                      <td>fire onSearch event bind with dropdown option value (search by, if provided) and input value. typically you will update the value on the component state or post the values to BE</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onSort</td>
                      <td>(value) => void</td>
                      <td></td>
                      <td>use this event to handle sort event. will typically update state value or use sort API</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onDropDownSelected</td>
                      <td>any</td>
                      <td></td>
                      <td>fire onDropDownSelected event bind with dropDown value . typically you will update the value on the component state or post the values to BE</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>panelVisible</td>
                      <td>boolean</td>
                      <td></td>
                      <td>lets you control the state of the filter (expanded or not) externally. use in conjunction with the onFilterExpand callback prop</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onFilterExpand</td>
                      <td>(isExpanded: boolean) => void</td>
                      <td></td>
                      <td>callback prop fired upon clicking of the filter image. use in order to signify to the parent prop that the image has been clicked, to update the parent state that controls the panelVisible prop</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
          </OTile>
        </Row>
        {this.state.userAccesstype !== 'SelfCare' ?
          <Row>
            <OFilter id='myAwesomeFilter' title='Filter title' subTitle='Filter subtitle' sortTitle='sort title'
              searchDropDownValue={this.filterSearchOptions[0].value} searchOptions={this.filterSearchOptions}
              onSearch={this.handleFilterSearch} searchInputValue={this.state.searchInput3Value}
              sortDropDownValue={this.filterSortOptions[0].value} sortOptions={this.filterSortOptions}
              onSort={this.handleFilterSort} handleOnChangeSearchInput={(searchInputEvent) => { this.handleSearchInput3Change(searchInputEvent) }}>
              <h1 className='contentPadding'>extended filter content</h1>
            </OFilter>
          </Row> : ''}
        <Row>
          <OFilter id='myAwesomeExpandedFilter' title='Filter title' subTitle='this panel is expanded by default, and calls an expansion callback' sortTitle='sort title'
            panelVisible={this.state.myAwesomeExpandedFilter.panelVisible}
            sortDropDownValue={this.filterSortOptions[0].value}
            sortOptions={this.filterSortOptions} onSort={this.handleFilterSort}
            onFilterExpand={this.onExpandFilter} onFilterOnly={this.state.userAccesstype === 'SelfCare' ? true : false}>
            {this.state.userAccesstype === 'SelfCare' ? <div className='oFilterExpandWrapper'>
              <div className='oFilterOptionsWrapper'>
                <ODropDown className='dropdown' size='medium' id='dd3' template={this.dropDownTemplate3} list={this.dropDownList3} value={this.state.dropDownValue3} onSelect={this.handleDropDownSelect3.bind(this)} label='please select something' highlighter={true} />
                <ODropDown className='dropdown' size='medium' id='dd4' template={this.dropDownTemplate4} list={this.dropDownList4} value={this.state.dropDownValue4} onSelect={this.handleDropDownSelect4.bind(this)} label='please select something' highlighter={true} />
                <div className='oFilterSearchWrapper'>
                  <OSearchInput className={'oFilterSearchInput'} placeholder='search something..' onSearch={this.handleSearch.bind(this)} onSearchClear={this.handleSearch4Clear}
                    value={this.state.searchInput4Value} id='searchInput' onBlur={this.handleSearchInput4Change.bind(this)}
                    onChange={this.handleSearchInput4Change.bind(this)} searchWithCrossBtn={this.state.userAccesstype === 'SelfCare' ? true : false} />
                </div>
              </div>
              <OButton link label='Clear All' onClick={this.handleFilterClearAll}></OButton>
            </div> : <h1 className='contentPadding'>extended filter content</h1>}
          </OFilter>
        </Row>
        {this.state.userAccesstype === 'SelfCare' ? <Row className='oFilterPanelDropDown'>
          <Col xs={3} sm={3} md={3}>
            <OFilterPanel id='desktopFilterPanel' searchFilterInput={<OSearchInput className={'oSearchInputCustClass'} placeholder='search something..' onSearch={this.handleSearch.bind(this)}
              onSearchClear={this.handleSearch5Clear} value={this.state.searchInput5Value} searchWithCrossBtn={this.state.userAccesstype === 'SelfCare' ? true : false}
              id='searchInput2' onBlur={this.handleSearchInput5Change.bind(this)} onChange={this.handleFilterPanelSearch} />}
              title='Filter List Web' isLinkDisable={this.state.isFilterDisabled} isButtonDisable={this.state.isFilterDisabled} linkTitle='Clear' buttonTitle='Apply'
              resetFilters={this.handleFilterPanelClear} applyFilter={this.handleFilterPanelApply}>
              <ODropDown size='small' id='dd5' template={this.dropDownTemplate5} list={this.dropDownList5} value={this.state.dropDownValue5} onSelect={this.handleFilterPanelDropDown} label='please select something' />
              <div className='oFilterCheckBoxWrapper'>
                <OCheckBox checked={this.state.filterCheckBox} value='filterChk1' name='filterCheckBox1' id='filterChk1' label='check me!' onChange={this.handleFilterPanelCheckbox} />
              </div>
            </OFilterPanel>
          </Col>
        </Row> : ''}
        {/*alerts*/}
        <Row>
          <OTile xs={12} md={12}>
            <OTileHeader title='alerts'>
              {this.showAPI(Api.Alerts)}
              {this.compatible(true, false)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.Alerts}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={alert1} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>status</td>
                      <td>string</td>
                      <td>'error'</td>
                      <td>alert status- color and icon</td>
                      <td>'danger' | 'warning' | 'success' | 'info'</td>
                    </tr>
                    <tr>
                      <td>closable</td>
                      <td>boolean</td>
                      <td>true</td>
                      <td>will show 'X' icon enables to close the alert</td>
                      <td>true | false</td>
                    </tr>
                    <tr>
                      <td>autoClose</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>will fade out after 5 seconds</td>
                      <td>true | false</td>
                    </tr>
                    <tr>
                      <td>visible</td>
                      <td>boolean</td>
                      <td>true</td>
                      <td>shown or hidden</td>
                      <td>true | false</td>
                    </tr>
                    <tr>
                      <td>kind</td>
                      <td>string</td>
                      <td>'box'</td>
                      <td>inline or box (with border)</td>
                      <td>'box' | 'inline'</td>
                    </tr>
                    <tr>
                      <td>cssClass</td>
                      <td>string</td>
                      <td></td>
                      <td>will add custom cssClass to Alert classes</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
          </OTile>
        </Row>
        <Row>
          <OTile xs={12} md={4} minHeight='100px'>
            <OAlert className='myClass' visible autoClose status='danger'><strong>Alert</strong> Danger</OAlert>
          </OTile>
          <OTile xs={12} md={4} minHeight='100px'>
            <OAlert visible closable={false} status='info'><strong>Alert</strong> Info</OAlert>
          </OTile>
          <OTile xs={12} md={4} minHeight='100px'>
            <OAlert visible status='success'><strong>Alert</strong> Success</OAlert>
          </OTile>
        </Row>
        <Row>
          <OTile xs={12} md={4} minHeight='100px'>
            <OAlert visible status='warning'><strong>Alert</strong> Warning</OAlert>
          </OTile>
          <OTile xs={12} md={4} minHeight='100px'>
            <OAlert visible status='danger'><strong>Alert</strong> Danger</OAlert>
          </OTile>
          <OTile xs={12} md={4} minHeight='100px'>
            <OAlert visible status='warning'><h4>with Long HTML</h4></OAlert>
          </OTile>
        </Row>
        {/*images*/}
        <Row>
          <OTile xs={12} md={12}>
            <OTileHeader title='Images'>
              {this.showAPI(Api.Images)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.Images}>
              <div className='contentPadding'>
                <h2>code example</h2>
                <div className='codeExample'>
                  <Image src={image1} responsive />
                  <Image src={image} responsive />
                </div>
                <h2>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>src</td>
                      <td>any</td>
                      <td></td>
                      <td>image source</td>
                      <td>'danger' | 'warning' | 'success' | 'info'</td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='contentPadding'>
              <OImage src={car} rounded className='car' />
              <OImage src={cloud} circle className='cloud' />
              <OImage src={magazin} thumbnail className='magazin' />
              <OImage src={tv} className='tv' />
              <OImage src={data} className='data' />
              <OImage src={wireless} className='wireless' />
            </div>
          </OTile>
        </Row>
        {/*modal*/}
        <Row>
          <OTile xs={12} md={12}>
            <OTileHeader title='modal'>
              {this.showAPI(Api.Modal)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.Modal}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image responsive src={modal} />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>remark</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><b>isOpen</b></td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>Specify the opened state</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>headerContent</td>
                      <td>Text/HTML/React Component</td>
                      <td></td>
                      <td>Content of the header</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>footerContent</td>
                      <td>Text/HTML/React Component</td>
                      <td></td>
                      <td>Content of the footer</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onTop</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>Specify if the modal should be opened on the top of screen</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onBottom</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>Specify if the modal should be opened on the bottom of screen</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>fullWidth</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>Specify if the modal should be spread all over the screen width</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>isInline</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>Specify if the modal should be inline over the component where rendered</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='contentPadding flexed'>
              <OButton primary label='Default Modal' onClick={() => { this.setState({ openedModal: 1 }) }} />
              <OModal isOpen={this.state.openedModal === 1} onHide={() => { this.setState({ openedModal: undefined }) }}>
                <div>modal body</div>
              </OModal>
              <OButton primary label='Header/Footer' onClick={() => { this.setState({ openedModal: 2 }) }} />
              <OModal isOpen={this.state.openedModal === 2} onHide={() => { this.setState({ openedModal: undefined }) }} headerContent={'Header'}
                footerContent={<div className='flexed'><OButton primary label='OK' onClick={() => { this.setState({ openedModal: undefined }) }} />
                  <OButton secondary label='Cancel' onClick={() => { this.setState({ openedModal: undefined }) }} /></div>}>
                <div>
                  <h1>This is</h1>
                  <h2>the modal</h2>
                  <h3>body</h3>
                </div>
              </OModal>
              <OButton primary label='On Top' onClick={() => { this.setState({ openedModal: 3 }) }} />
              <OModal isOpen={this.state.openedModal === 3} onHide={() => { this.setState({ openedModal: undefined }) }} onTop>
                <div>
                  <h1>This is</h1>
                  <h2>the modal</h2>
                  <h3>body</h3>
                </div>
              </OModal>
              <OButton primary label='On Bottom' onClick={() => { this.setState({ openedModal: 4 }) }} />
              <OModal isOpen={this.state.openedModal === 4} onHide={() => { this.setState({ openedModal: undefined }) }} onBottom>
                <div>
                  <h1>This is</h1>
                  <h2>the modal</h2>
                  <h3>body</h3>
                </div>
              </OModal>
              <OButton primary label='Full Width' onClick={() => { this.setState({ openedModal: 5 }) }} />
              <OModal isOpen={this.state.openedModal === 5} onHide={() => { this.setState({ openedModal: undefined }) }} fullWidth>
                <div>
                  <h1>This is</h1>
                  <h2>the modal</h2>
                  <h3>body</h3>
                </div>
              </OModal>
              <OButton primary label='Inline Modal' onClick={() => { this.setState({ openedModal: 6 }) }} />
            </div>
          </OTile>
        </Row >
        <Row>
          <OTile>
            <OModal isOpen={this.state.openedModal === 6} onHide={() => { this.setState({ openedModal: undefined }) }} fullWidth isInline={true}>
              <div>
                <h1>This is</h1>
                <h2>the modal</h2>
                <h3>body</h3>
              </div>
            </OModal>
          </OTile>
        </Row>
        {/*pager*/}
        < Row >
          <OTile xs={12} md={12}>
            <OTileHeader title='pager'>
              {this.showAPI(Api.Pager)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.Pager}>
              <div className='contentPadding pagers'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={pager} responsive />
                </div>
                <h2 className='exampleHeader' >Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>remark</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><b>totalRowCount</b></td>
                      <td>number</td>
                      <td></td>
                      <td>Total No of Rows</td>
                      <td>If the totalRowCount combined with the pageSize (either from the pageSize prop when not using a dropdown, or the activePageSize when using a dropdown) causes the number of pages to drop to 1, the component shall hide itself.</td>
                    </tr>
                    <tr>
                      <td><b>onPageChanged</b></td>
                      <td>call back function</td>
                      <td></td>
                      <td>Handles click on a Page No</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>previousLabel</td>
                      <td>string</td>
                      <td></td>
                      <td>'Previous' label value</td>
                      <td>Since app-core does not support intl messages</td>
                    </tr>
                    <tr>
                      <td>nextLabel</td>
                      <td>string</td>
                      <td></td>
                      <td>'Next' label value</td>
                      <td>Since app-core does not support intl messages</td>
                    </tr>
                    <tr>
                      <td>activePageNo</td>
                      <td>number</td>
                      <td>1</td>
                      <td>Current Selected Page</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>activePageSize</td>
                      <td>number</td>
                      <td>1</td>
                      <td>Current Selected Page Size</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>showDropDown</td>
                      <td>boolean</td>
                      <td>true</td>
                      <td>Show the DropDown control</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onPageSizeChanged</td>
                      <td>call back function</td>
                      <td></td>
                      <td>Handles selected Page Size in dropdown</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>customPageSizeList</td>
                      <td>Array&lt;IValueTitleDescription&gt;</td>
                      <td></td>
                      <td>Page Size DropDown list</td>
                      <td>If set 'pageSize' won't be taken in account</td>
                    </tr>
                    <tr>
                      <td>pageSize</td>
                      <td>number</td>
                      <td></td>
                      <td>No of records per Page</td>
                      <td>Should be set if customPageSizeList is not set</td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='contentPadding pagers'>
              <OPager totalRowCount={36} nextLabel='Next' previousLabel='Previous'
                onPageChanged={this.onOPagerChanged} customPageSizeList={this.oPagerDDList} onPageSizeChanged={this.onOPagerChanged} />

              {/* pager with page size dropdown (default) */}
              <OPager
                totalRowCount={72}
                nextLabel='Suivant'
                previousLabel='Précédent'
                onPageChanged={this.onOPagerChangedSilent} activePageNo={3}
                onPageSizeChanged={this.onOPagerChangedSilent}
                customPageSizeList={[
                  { key: 1, value: 6, description: ' Par Page' },
                  { key: 2, value: 12, description: ' Par Page' }
                ]} />

              {/* pager without page size dropdown */}
              <OPager totalRowCount={149} nextLabel='Next' previousLabel='Previous'
                onPageChanged={this.onOPagerChangedSilent}
                showDropDown={false} pageSize={12} />
            </div>
          </OTile>
        </Row >
        {/* TABS */}
        <Row>
          <div>
            <OTile xs={12} md={12}>
              <div className={'tabs'}>
                <OTileHeader title='tabs'>
                  {this.showAPI(Api.Tabs)}
                  {this.compatible(true, true)}
                </OTileHeader>
                <Panel collapsible expanded={this.state.openedAPI === Api.Tabs}>
                  <div className='contentPadding'>
                    <h2 className='exampleHeader'>code example</h2>
                    <div className='codeExample'>
                      <Image src={tabs} responsive />
                    </div>
                    <h2 className='exampleHeader'>Props</h2>
                    <Table responsive>
                      <thead>
                        <tr>
                          <th>prop</th>
                          <th>type</th>
                          <th>default</th>
                          <th>description</th>
                          <th>options</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>showDropDownOverLimit</td>
                          <td>boolean</td>
                          <td>false</td>
                          <td>the tabs turn into a dropdown when the number of tabs exceed the parent container width in Selfcare</td>
                        </tr>
                        <tr>
                          <td>showAddButton</td>
                          <td>boolean</td>
                          <td>false</td>
                          <td>shows a add button beside the tab to provide user with a onClick event in Selfcare</td>
                        </tr>
                        <tr>
                          <td>onClickAdd</td>
                          <td>function</td>
                          <td></td>
                          <td>the event fired on the click of the add button beside the tab selfcare</td>
                        </tr>
                      </tbody>
                    </Table>
                  </div>
                </Panel>

                {document.getElementsByTagName('BODY').item(0).className === 'CSR' &&
                  <OTabs index={this.state.selectedIndex}
                    showArrows={true}
                    isTabsResponsive={false}
                    onChange={n => { this.setState({ selectedIndex: n }); console.info(`tab index ${n} selected`) }}>
                    <OTab title='Tab 1'>Tab 1 content for trial</OTab>
                    <OTab title='Tab 2' disabled>Tab 2 content</OTab>
                    <OTab title='Tab 3' subtitle='Subtitle 3'>Tab 3 content</OTab>
                    <OTab title={<h4 title='Tab 4' style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>Tab 4 title</h4>}>Tab 4 content</OTab>
                    <OTab title={<label>Tab 5</label>} subtitle='Subtitle 5'>Tab 5 content</OTab>
                  </OTabs>}
                {document.getElementsByTagName('BODY').item(0).className === 'SelfCare' &&
                  <OTabs index={this.state.selectedIndex}
                    showArrows={false}
                    showAddButton={true}
                    onClickAdd={() => {

                      let flagArray: Array<any> = this.state.OTabsData
                      let OTabsDataDummy: Array<any> = flagArray.concat({ title: 'Title Added', content: 'Title Content' })
                      this.setState({ OTabsData: OTabsDataDummy })
                    }}
                    showDropDownOverLimit={true}
                    isTabsResponsive={true}
                    onChange={n => { this.setState({ selectedIndex: n }); console.info(`tab index ${n} selected`) }}>
                    {this.state.OTabsData.map((item: any, index: any) => {
                      return <OTab title={item.title} disabled>{item.content}</OTab>
                    })}
                  </OTabs>}
              </div>

            </OTile>
            {
              document.getElementsByTagName('BODY').item(0).className === 'SelfCare' &&
              <div className={'tabs'}>
                <OTile xs={12} md={12}>
                  <OTileHeader title='Secondary (minimize window to show dropdown)'>
                    {this.showAPI(Api.TabsAlternate1)}
                    {this.compatible(true, true)}
                  </OTileHeader>
                  <Panel collapsible expanded={this.state.openedAPI === Api.TabsAlternate1}>
                    <div className='contentPadding'>
                      <h2 className='exampleHeader'>code example</h2>
                      <div className='codeExample'>
                        <Image src={imgTabsSelfCareSecondary1} responsive />
                      </div>
                    </div>
                  </Panel>
                  <OTabs showArrows={false} className='secondary' showDropDownOverLimit={true} index={this.state.selectedIndex1}
                    isTabsResponsive={true} onChange={n => { this.setState({ selectedIndex1: n }) }}>
                    <OTab title='Tab 1'>Tab 1 content</OTab>
                    <OTab title='Tab 2' subtitle='Subtitle 2'>Tab 2 content</OTab>
                    <OTab title='Tab 3'>Tab 3 content</OTab>
                    <OTab disabled title='Tab 4' subtitle='Subtitle 4'>Tab 4 content</OTab>
                    <OTab title='Tab 5'>Tab 5 content</OTab>
                  </OTabs>
                </OTile>
              </div>
            }
          </div>
        </Row>

        {/*ODatePicker visible*/}
        {
          document.getElementsByTagName('BODY').item(0).className === 'CSR' &&
          <Row>
            <OTile xs={12} md={12} minHeight='150px'>
              <OTileHeader title='Date Picker visible' >
                {this.showAPI(Api.DatePickerVisible)}
                {this.compatible(true, false)}
              </OTileHeader>
              <Panel collapsible expanded={this.state.openedAPI === Api.DatePickerVisible}>
                <div className='contentPadding'>
                  <h2 className='exampleHeader'>code example</h2>
                  <div className='codeExample'>
                    <Image src={datepickeralwaysopened_csr} responsive />
                  </div>
                  <h2 className='exampleHeader'>ODatePicker uses DayPicker from 'react-day-picker</h2>
                </div>
              </Panel>
              <div id='ODatePickerDivIdSC' className='contentPadding'>
                <ODatePicker
                  id='datePickerIdVisible'
                  className='sampleClassODatePickerSC'
                  label='Date'
                  value={this.state.datePickerValue ? new Date(this.state.datePickerValue) : undefined}
                  onChange={this.handleDateChange}
                  dateFormat='D MMM YYYY'
                  enableOutsideDays={true}
                  showCalendar={false}
                  disabledDays={rangeDisabled}
                  disablePastDays={true}
                />
              </div>
              <div id='ODatePickerDivIdSC' className='contentPadding'>
                <ODatePicker
                  customTrigger={<a>Hello</a>}
                  id='datePickerIdVisible'
                  className='sampleClassODatePickerSC'
                  value={this.state.datePickerValue ? new Date(this.state.datePickerValue) : undefined}
                  onChange={this.handleDateChange}
                  dateFormat='D MMM YYYY'
                  enableOutsideDays={true}
                  showCalendar={false}
                  disabledDays={rangeDisabled}
                  disablePastDays={true}
                />
              </div>
            </OTile>
          </Row>
        }
        {/*ODatePicker*/}
        {
          document.getElementsByTagName('BODY').item(0).className === 'CSR' &&
          <Row>
            <OTile xs={12} md={12} minHeight='150px'>
              <OTileHeader title='datePicker' >
                {this.showAPI(Api.DatePicker)}
                {this.compatible(true, false)}
              </OTileHeader>
              <Panel collapsible expanded={this.state.openedAPI === Api.DatePicker}>
                <div className='contentPadding'>
                  <h2 className='exampleHeader'>code example</h2>
                  <div className='codeExample'>
                    <Image src={datepicker_csr} responsive />
                  </div>
                  <h2 className='exampleHeader'>ODatePicker uses DayPicker from 'react-day-picker</h2>
                </div>
              </Panel>
              <div id='ODatePickerDivIdCSR' className='contentPadding'>
                <ODatePicker
                  id='datePickerId'
                  label='Date'
                  value={this.state.datePickerValue2}
                  disablePastDays={true}
                  onChange={this.handleDateChange2}
                  dateFormat='D MMM YYYY'
                  enableOutsideDays={true}
                  showCalendar={false}
                />
              </div>
            </OTile>
          </Row>
        }
        {/*ODateRangePicker*/}
        {
          document.getElementsByTagName('BODY').item(0).className === 'CSR' &&
          <Row>
            <OTile xs={12} md={12} minHeight='150px'>
              <OTileHeader title='dateRangePicker' >
                {this.showAPI(Api.DateRangePicker)}
                {this.compatible(true, false)}
              </OTileHeader>
              <Panel collapsible expanded={this.state.openedAPI === Api.DateRangePicker}>
                <div className='contentPadding'>
                  <h2 className='exampleHeader'>code example</h2>
                  <div className='codeExample'>
                    <Image src={daterangepicker} responsive />
                  </div>
                  <h2 className='exampleHeader'>ODateRangePicker uses DayPicker from 'react-day-picker</h2>
                </div>
              </Panel>
              <div className='contentPadding' id='ODateRangePickerDivId'>
                <ODateRangePicker
                  dateFormat='DD/MMM/YYYY'
                  p_from={this.state.dateRangePickerValueFrom}
                  p_to={this.state.dateRangePickerValueTo}
                  handleDayClickExtended={this.handleDayClickExtended}
                  disablePastDays={true}
                />
              </div>
            </OTile>
          </Row>
        }
        {
          document.getElementsByTagName('BODY').item(0).className === 'SelfCare' &&
          <Row>
            <OTile xs={12} md={12} minHeight='480px'>
              <OTileHeader title='datePicker' >
                {this.showAPI(Api.DatePickerVisibleSC)}
                {this.compatible(true, true)}
              </OTileHeader>
              <Panel collapsible expanded={this.state.openedAPI === Api.DatePickerVisibleSC}>
                <div className='contentPadding'>
                  <h2 className='exampleHeader'>code example</h2>
                  <div className='codeExample'>
                    <Image src={datepicker_sc} responsive />
                  </div>
                  <h2 className='exampleHeader'>ODatePickerProps</h2>
                  <Table responsive>
                    <thead>
                      <tr>
                        <th>prop</th>
                        <th>type</th>
                        <th>default</th>
                        <th>description</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>label</td>
                        <td>string</td>
                        <td></td>
                        <td>Label above date</td>
                      </tr>
                      <tr>
                        <td>value</td>
                        <td>string</td>
                        <td></td>
                        <td>Value of date</td>
                      </tr>
                      <tr>
                        <td>disabled</td>
                        <td>boolean</td>
                        <td></td>
                        <td>Widget is disabled</td>
                      </tr>
                      <tr>
                        <td>onChange</td>
                        <td>any</td>
                        <td></td>
                        <td>fire onChange events bind with date click or change. Typically you will set the value on state</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>placeHolder</td>
                        <td>string</td>
                        <td></td>
                        <td>placeHolder</td>
                      </tr>
                      <tr>
                        <td>dateFormat</td>
                        <td>string</td>
                        <td></td>
                        <td>dateFormat in which date is displayed. Example 'DD/MMM/YYYY'</td>
                      </tr>
                      <tr>
                        <td>id</td>
                        <td>string</td>
                        <td></td>
                        <td>Identifier of the widget. Obligatory field.</td>
                      </tr>
                      <tr>
                        <td>className</td>
                        <td>string</td>
                        <td></td>
                        <td>Will add specfied custom css class to classes</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>enableOutsideDays</td>
                        <td>string</td>
                        <td></td>
                        <td>Display dates outside selected month</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>showCalendar</td>
                        <td>boolean</td>
                        <td></td>
                        <td>True: Calendar is always displayed. False: Calendar is displayed on icon click.</td>
                        <td></td>
                      </tr>
                    </tbody>
                  </Table>
                </div>
              </Panel>
              <div id='ODatePickerDivIdSC' className='contentPadding sampleClassODatePickerSC'>
                <ODatePicker
                  id='datePickerSCId'
                  label='Set Expiration Date'
                  value={this.state.datePickerValue ? new Date(this.state.datePickerValue) : null}
                  disabled={false}
                  onChange={this.handleDateChange}
                  dateFormat='DD/MMM/YYYY'
                  enableOutsideDays={true}
                  showCalendar={true}
                  disablePastDays={true}
                // disabledDays={rangeDisabled}
                />
              </div>
            </OTile>
          </Row>
        }
        {
          document.getElementsByTagName('BODY').item(0).className === 'SelfCare' &&
          <Row>
            <OTile xs={12} md={12} minHeight='480px'>
              <OTileHeader title='Date Picker Period' >
                {this.showAPI(Api.DatePickerPeriod)}
                {this.compatible(true, true)}
              </OTileHeader>
              <Panel collapsible expanded={this.state.openedAPI === Api.DatePickerPeriod}>
                <div className='contentPadding'>
                  <h2 className='exampleHeader'>code example</h2>
                  <div className='codeExample'>
                    <Image src={datepickerperiod_sc} responsive />
                  </div>
                  <h2 className='exampleHeader'>ODatePickerPeriodProps</h2>
                  <Table responsive>
                    <thead>
                      <tr>
                        <th>prop</th>
                        <th>type</th>
                        <th>default</th>
                        <th>description</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>labelFrom</td>
                        <td>string</td>
                        <td></td>
                        <td>Label above from date</td>
                      </tr>
                      <tr>
                        <td>labelTo</td>
                        <td>string</td>
                        <td></td>
                        <td>Label above to date</td>
                      </tr>
                      <tr>
                        <td>valueFrom</td>
                        <td>string</td>
                        <td></td>
                        <td>Value of from date</td>
                      </tr>
                      <tr>
                        <td>valueTo</td>
                        <td>string</td>
                        <td></td>
                        <td>Value of to date</td>
                      </tr>
                      <tr>
                        <td>disabled</td>
                        <td>boolean</td>
                        <td></td>
                        <td>Widget is disabled</td>
                      </tr>
                      <tr>
                        <td>onChange</td>
                        <td>any</td>
                        <td></td>
                        <td>fire onChange events bind with date click or change. Typically you will set the value on state</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>placeHolder</td>
                        <td>string</td>
                        <td></td>
                        <td>placeHolder</td>
                      </tr>
                      <tr>
                        <td>dateFormat</td>
                        <td>string</td>
                        <td></td>
                        <td>dateFormat in which date is displayed. Example 'DD/MMM/YYYY'</td>
                      </tr>
                      <tr>
                        <td>id</td>
                        <td>string</td>
                        <td></td>
                        <td>Identifier of the widget. Obligatory field.</td>
                      </tr>
                      <tr>
                        <td>className</td>
                        <td>string</td>
                        <td></td>
                        <td>Will add specfied custom css class to classes</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>enableOutsideDays</td>
                        <td>string</td>
                        <td></td>
                        <td>Display dates outside selected month</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>onDisplayFocus</td>
                        <td>boolean</td>
                        <td></td>
                        <td>Set focus on from date immediately after component is mounted.</td>
                        <td></td>
                      </tr>
                    </tbody>
                  </Table>
                </div>
              </Panel>
              <div id='ODatePickerPeriodDivIdSC' className='contentPadding sampleClassODatePickerSC'>
                <ODatePickerPeriod
                  id='datePickerPeriodId'
                  labelFrom='Set From Date'
                  labelTo='Set To Date'
                  valueFrom={new Date(this.state.datePickerValueFrom)}
                  valueTo={new Date(this.state.datePickerValueTo)}
                  disabled={false}
                  onChange={this.handleDateChangePeriod}
                  dateFormat='DD/MMM/YYYY'
                  enableOutsideDays={true}
                  disablePastDays={true}
                />
              </div>
            </OTile>
          </Row>
        }
        {/*OTooltip*/}
        <Row>
          <OTile autoFocus xs={12} md={12} >
            <OTileHeader title='tooltip' subtitle='tooltip'>
              {this.showAPI(Api.Tooltip)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.Tooltip}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={tooltipCode} responsive />

                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr className='tableRow'>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>remark</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>placement</td>
                      <td>string</td>
                      <td>right</td>
                      <td>the position where the tooltip will show</td>
                      <td>values -> top | bottom | left | right</td>
                    </tr>
                    <tr>
                      <td>trigger</td>
                      <td>any</td>
                      <td></td>
                      <td>the action that shows/hides the tooltip</td>
                      <td>examples -> click | ['hover', 'focus'] | 'focus']</td>
                    </tr>
                    <tr>
                      <td>triggerContent</td>
                      <td>JSX.Element | string</td>
                      <td></td>
                      <td>the content that owns the action/trigger for showing/hiding the tooltip</td>
                      <td>text or component</td>
                    </tr>
                    <tr>
                      <td>overlay</td>
                      <td>JSX.Element | string</td>
                      <td></td>
                      <td>the tooltip content </td>
                      <td>text or component</td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='contentPadding'>
              <OTooltip placement='top' trigger='click' overlay={this.overlayContent(0)}
                triggerContent={this.triggerContent(0)} />
              <OTooltip placement='bottom' trigger={['click']} overlay={this.overlayContent(1)}
                triggerContent={this.triggerContent(1)} />
              <OTooltip placement='right' trigger={['hover', 'focus']} overlay={this.overlayContent(2)}
                triggerContent={this.triggerContent(2)} />
              <OTooltip placement='left' trigger='focus' overlay={this.overlayContent(3)}
                triggerContent={this.triggerContent(3)} />
            </div>
          </OTile>
        </Row>
        {/*table*/}
        {/*accordion*/}
        {/* <OAccordion>
          {this.accordionList.map((item) => {
            return (
              <OAccordionPanel key={item.key}>
                <OAccordionHeader>
                  {item.header}
                </OAccordionHeader>
                <OAccordionBody>
                  {item.content}<OButton label={'shalom ' + item.key} />
                </OAccordionBody>
              </OAccordionPanel>
            )
          })}
        </OAccordion> */}
        <Row>
          {
            document.getElementsByTagName('BODY').item(0).className === 'CSR' &&
            <OTile xs={12} md={12}>
              <OTileHeader title='table'>
                {this.showAPI(Api.Table)}
                {this.compatible(true, false)}
              </OTileHeader>
              <Panel collapsible expanded={this.state.openedAPI === Api.Table}>
                <div className='contentPadding'>
                  <h2 className='exampleHeader'>code example</h2>
                  <div className='codeExample'>
                    <Image src={table} responsive />
                  </div>
                  <h2 className='exampleHeader'>Props</h2>
                  <Table responsive>
                    <thead>
                      <tr>
                        <th>prop</th>
                        <th>type</th>
                        <th>default</th>
                        <th>description</th>
                        <th>options</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>className</td>
                        <td>string</td>
                        <td></td>
                        <td>set custom class to the component wrapper ('.oTable myCustomClass')</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>data (mandatory)</td>
                        <td>IOTableData</td>
                        <td></td>
                        <td>Actual table configuration. Mandatory fields inside this structure are the headers array and rows array.</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>onSort</td>
                        <td>function(sortBy: string, sortDirection: SortDirections): any</td>
                        <td></td>
                        <td>add sort icon to the header cell and fire event on sort</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>onRowSelect</td>
                        <td>function(selectedRows): void</td>
                        <td></td>
                        <td>add checkbox to each row and fire event on row select</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>onRowExpand</td>
                        <td>function(expandedRowKey: string): void</td>
                        <td></td>
                        <td>fire event on row expand (in order to enable retrieving data on expand)</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>onContextmenuSelect</td>
                        <td>function(row: string | number, value: any): void</td>
                        <td></td>
                        <td>fire event on context menu item select</td>
                        <td></td>
                      </tr>
                    </tbody>
                  </Table>
                </div>
              </Panel>
              <div className='table'>
                <OTable
                  data={this.data}
                  onSort={this.handleTableSort.bind(this)}
                  onRowSelect={this.handleTableRowSelect.bind(this)}
                  onContextmenuSelect={this.handleContextMenuSelect.bind(this)}
                  onRowExpand={(key) => { console.info('row ' + key + ' expanded') }} />
              </div>
            </OTile>
          }
        </Row>
        <Row>
          {
            document.getElementsByTagName('BODY').item(0).className === 'SelfCare' &&
            <OTile>
              <OTileHeader title='table with sticky header'>
                {this.showAPI(Api.TableSticky)}
                {this.compatible(false, true)}
              </OTileHeader>
              <Panel collapsible expanded={this.state.openedAPI === Api.TableSticky}>
                <div className='contentPadding'>
                  <h2 className='exampleHeader'>code example</h2>
                  <div className='codeExample'>
                    <Image src={tableSticky} responsive />
                  </div>
                </div>
              </Panel>
              <div className='table'>
                <OTable stickyHeader={<span>Sticky Header Element</span>}
                  stickyHeaderCheckBox={true}
                  tableHeight={450}
                  data={this.stickyData}
                  onSort={this.handleTableSort.bind(this)}
                  onRowSelect={this.handleTableRowSelect.bind(this)}
                  onContextmenuSelect={this.handleContextMenuSelect.bind(this)}
                  onRowExpand={(key) => { console.info('row ' + key + ' expanded') }} />
              </div>
            </OTile>
          }

        </Row>
        {/* OMASTERDETAIL */}
        {
          document.getElementsByTagName('BODY').item(0).className === 'CSR' &&
          <Row>
            <OTile xs={12} md={12}>
              <OTileHeader title='MASTER DETAIL'>
                {this.showAPI(Api.MasterDetail)}
                {this.compatible(true, false)}
              </OTileHeader>
              <Panel collapsible expanded={this.state.openedAPI === Api.MasterDetail}>
                <div className='contentPadding'>
                  <h2 className='exampleHeader'>code example</h2>
                  <div className='codeExample'>
                    <Image src={masterdetail} responsive />
                  </div>
                  <h2 className='exampleHeader'>Props</h2>
                  <Table responsive>
                    <thead>
                      <tr>
                        <th>prop</th>
                        <th>type</th>
                        <th>default</th>
                        <th>description</th>
                        <th>options</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>eventKey</td>
                        <td>string</td>
                        <td></td>
                        <td>The event key of an item that will be pre selected upon load.</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>onChange</td>
                        <td>(eventKey: string) => void</td>
                        <td></td>
                        <td>Event fired when selected item changes</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>showNavigationButtons</td>
                        <td>boolean</td>
                        <td>true</td>
                        <td>Shows/Hides navigation buttons</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>showInDropdown</td>
                        <td>boolean</td>
                        <td>false</td>
                        <td>When true, renders the component inside a dropdown</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>premountContent</td>
                        <td>boolean</td>
                        <td>false</td>
                        <td>When true, items will be rendered on component load</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>title</td>
                        <td>JSX.Element | string</td>
                        <td></td>
                        <td>The title that is rendered in the navigation and in the dropdown</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>footer</td>
                        <td>JSX.Element | string</td>
                        <td></td>
                        <td>The footer of the component that is rendered at the bottom</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>navHeader</td>
                        <td>JSX.Element | string</td>
                        <td></td>
                        <td>The header of the nav that is rendered above the navigation list</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>navFooter</td>
                        <td>JSX.Element | string</td>
                        <td></td>
                        <td>The footer of the nav that is rendered below the navigation list</td>
                        <td></td>
                      </tr>
                    </tbody>
                  </Table>
                </div>
              </Panel>
              <div className='contentPadding'>
                <OMasterDetail
                  title='Select'
                  showInDropdown
                  onChange={eventKey => this.setState({ eventKey })}
                  footer='Footer'>
                  <OMasterDetailItem title='Item 3' eventKey='item1'>
                    <div>Content 3</div>
                  </OMasterDetailItem>
                  <OMasterDetailGroup title='Group 1' groupKey='group1'>
                    <OMasterDetailItem title='Item 1' disabled>
                      <div>Content 1</div>
                    </OMasterDetailItem>
                    <OMasterDetailItem title='Item 2'>
                      <div>Content 2</div>
                    </OMasterDetailItem>
                  </OMasterDetailGroup>
                  <OMasterDetailItem title='Item 4'>
                    <div>Content 4</div>
                  </OMasterDetailItem>
                </OMasterDetail>
              </div>
            </OTile>
          </Row>
        }

        {/*usage bar*/}
        < Row >
          <OTile xs={12} md={12}>
            <OTileHeader title='Usage Bar'>
              {this.showAPI(Api.usageBar)}
              {this.compatible(false, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.usageBar}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={usageBar} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>value</td>
                      <td>number</td>
                      <td></td>
                      <td>Specifies the current usage</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>max</td>
                      <td>number</td>
                      <td>100</td>
                      <td>Specifies the max usage</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>min</td>
                      <td>number</td>
                      <td>0</td>
                      <td>Specifies the min usage</td>
                      <td></td>
                    </tr>
                    <tr>

                      <td>label</td>
                      <td>string</td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>showDescription</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>condition to show remaining data</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>showTitle</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>condition to show title </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>title</td>
                      <td>string</td>
                      <td></td>
                      <td> title for usage Bar </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>key</td>
                      <td>any</td>
                      <td></td>
                      <td> key </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>id</td>
                      <td>any</td>
                      <td></td>
                      <td> id </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>subtitle</td>
                      <td>string</td>
                      <td></td>
                      <td>text as per requirement </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>description</td>
                      <td>string</td>
                      <td></td>
                      <td> text as per requirement</td>
                      <td></td>
                    </tr>

                  </tbody>
                </Table>
              </div>
            </Panel>

            {/*add component*/}
            <div className='usageBar contentPadding'>
              <OUsageBar max={100} min={0} value={70} title={'shared storage'} description={<label>70 GB free from 100 GB</label>}
                id={'444'} />
              <OUsageBar max={70} min={0} value={60} title={'shared storage'} />
            </div>
          </OTile>
        </Row >

        {/*Counter*/}

        < Row >
          <OTile xs={12} md={12}>
            <OTileHeader title='Counter'>
              {this.showAPI(Api.counter)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.counter}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={counter} responsive />
                  <Image src={counter1} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>

                    <tr>
                      <td>onCountChange</td>
                      <td>call back function</td>
                      <td></td>
                      <td>Handles click on + and - button</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>defaultValue</td>
                      <td>number</td>
                      <td>0</td>
                      <td>set default value</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>defaultValue</td>
                      <td>number</td>
                      <td>0</td>
                      <td>set default value</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>key</td>
                      <td>any</td>
                      <td></td>
                      <td> key </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>id</td>
                      <td>any</td>
                      <td></td>
                      <td> id </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>min</td>
                      <td>number</td>
                      <td>0</td>
                      <td> minimum value </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>max</td>
                      <td>number</td>
                      <td></td>
                      <td> maximum value </td>
                      <td></td>
                    </tr>

                  </tbody>
                </Table>
              </div>
            </Panel>

            {/*add component*/}
            <div className='counter contentPadding'>
              <OCounter onChange={(value) => this.onChange(value)} defaultValue={122} id={'id'} min={0} max={200} />
            </div>
          </OTile>
        </Row >
        {/*OVerticalTab*/}

        < Row >
          <OTile xs={12} md={12}>
            <OTileHeader title='OVerticalTab'>
              {this.showAPI(Api.VerticalTabs)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.VerticalTabs}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={VerticalTabs} responsive />
                  <Image src={VerticalTabs1} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>

                    <tr>
                      <td>onSelect</td>
                      <td>call back function</td>
                      <td></td>
                      <td>Handles click on each tab</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>data</td>
                      <td> sample shown above in Code Example</td>
                      <td></td>
                      <td>Data which needs to be rendered</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>

            {/*add component*/}
            <div className='contentPadding'>
              <OVerticalTabs data={this.verticalTabsData} onSelect={(eventKey) => { console.info(`selected tab: ${eventKey}`) }} />
            </div>
          </OTile>
        </Row >
        {/*OApplicationHeader*/}
        {/* < Row >
          <OTile xs={12} md={12}>
            <OTileHeader title='OApplicationHeader'>
              {this.showAPI(Api.OApplicationHeader)}
              {this.compatible(true, false)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.OApplicationHeader}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={OApplicationHeaderImage1} responsive />
                  <Image src={OApplicationHeaderImage2} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>

                    <tr>
                      <td>LOGO</td>
                      <td>Any JSX element</td>
                      <td></td>
                      <td>Displays logo</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>Sub menu</td>
                      <td> Refer to the examples showns above for ApplicationHeader sub Menu </td>
                      <td></td>
                      <td>The SubMenu to be rendered on selection of each tab item</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>ShortCut Tabs</td>
                      <td> Refer to the examples showns above for applicationShortCutTabData </td>
                      <td></td>
                      <td>The ShortCutItem to be rendered on left side of navbar after logo</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>Header Tabs</td>
                      <td> Refer to the examples showns above for applicationHeaderTabData </td>
                      <td></td>
                      <td>The Tabs to be rendered on Navbar</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>Actions</td>
                      <td> Refer to the examples showns above for applicationHeaderActions </td>
                      <td></td>
                      <td>The Action Tabs to be rendered on right most side of navbar</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onSelectTabs</td>
                      <td> Call Back function</td>
                      <td></td>
                      <td>Handles click on each Tab</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onSelectShortCut</td>
                      <td> Call Back function</td>
                      <td></td>
                      <td>Handles click on each Short Cut</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onSelectActions</td>
                      <td> Call Back function</td>
                      <td></td>
                      <td>Handles click on each Action Tabs</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onSelectLogo</td>
                      <td> Call Back function</td>
                      <td></td>
                      <td>Handles click on Logo</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>

            <div id='theme-wrapper'>
              {document.getElementsByTagName('BODY').item(0).className === 'SelfCare' &&
                <OApplicationHeader logo={<span className='logo'></span>}
                  subMenu={this.applicationHeaderSubMenu}
                  onSelectShortCut={(eventKey) => { console.info(`selected shortCut: ${eventKey}`) }}
                  shortCutTabs={this.applicationShortCutTabData}
                  headerTabs={this.applicationHeaderTabData} actions={this.applicationHeaderActions}
                  pageTitle={this.applicationHeaderPageTitle}
                  onSelectTabs={(eventKey) => { console.info(`selected tab: ${eventKey}`) }}
                  onSelectActions={(eventKey) => { console.info(`selected action: ${eventKey}`) }}
                  onMouseOverTab={(eventKey) => { console.info(`selected action: ${eventKey}`) }}
                  onSelectLogo={() => { console.info(`selected action: LOGO`) }}
                  profileStatus={<span>User Profile</span>}
                  onClickProfileStatus={() => { console.info('User Profile selected') }}
                  profileOptions={this.dropDownList}
                  dropDownTemplate={(item) => this.dropDownTemplate(item)}
                  onDropDownSelect={(value) => { console.info(`selected Value is: ${value}`) }}
                />}
              {document.getElementsByTagName('BODY').item(0).className === 'CSR' &&
                <OApplicationHeader logo={<span className='logo'></span>}
                  subMenu={this.applicationHeaderSubMenu}
                  pageTitle={this.applicationHeaderPageTitle}
                  shortCutTabs={this.applicationShortCutTabData}
                  onSelectShortCut={(eventKey) => { console.info(`selected shortCut: ${eventKey}`) }}
                  headerTabs={this.applicationHeaderTabData} actions={this.applicationHeaderActions}
                  onSelectTabs={(eventKey) => { console.info(`selected tab: ${eventKey}`) }}
                  onSelectActions={(eventKey) => { console.info(`selected action: ${eventKey}`) }}
                  onMouseOverTab={(eventKey) => { console.info(`selected action: ${eventKey}`) }}
                  onSelectLogo={() => { console.info(`selected action: LOGO`) }}
                  profileStatus={<span className='userProfile'></span>}
                  onClickProfileStatus={() => { console.info('User Profile selected') }}
                  profileOptions={this.dropDownList}
                  dropDownTemplate={(item) => this.dropDownTemplate(item)}
                  onDropDownSelect={(value) => { console.info(`selected Value is: ${value}`) }} />}
            </div>
          </OTile>
        </Row > */}
        {/*Toggle switch*/}
        <Row>
          <OTile xs={12} md={12}>
            <OTileHeader title='TOGGLE SWITCH'>
              {this.showAPI(Api.ToggleSwitch)}
              {this.compatible(false, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.ToggleSwitch}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={oSwitchImg} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>name</td>
                      <td>string</td>
                      <td></td>
                      <td>Specifies the name of the element</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>disabled</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>Element is disabled</td>
                      <td>true | false</td>
                    </tr>
                    <tr>
                      <td>checked</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>Element is checked</td>
                      <td>true | false</td>
                    </tr>
                    <tr>
                      <td>onChange</td>
                      <td>any</td>
                      <td></td>
                      <td>fire onChange events bind with group value. typically you will set the value on state</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>label</td>
                      <td>any</td>
                      <td></td>
                      <td>label for the checkbox</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>className</td>
                      <td>string</td>
                      <td></td>
                      <td>will add specfied custom css class to classes</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='contentPadding'>
              <OSwitch label={(this.state.oSwitch['chk1'] ? 'ON' : 'OFF')} checked={this.state.oSwitch['chk1']} name='chk1'
                onChange={this.handleOSwitch.bind(this)} />
              <OSwitch label='DISABLED' checked={this.state.oSwitch['chk2']} name='chk2'
                onChange={this.handleOSwitch.bind(this)} disabled={true} />
            </div>
          </OTile>
        </Row>
        {
          document.getElementsByTagName('BODY').item(0).className === 'CSR' &&
          <Row>
            <OTile autoFocus xs={12} md={12} >
              <OTileHeader title='wizard'>
                {this.showAPI(Api.Wizard)}
                {this.compatible(true, false)}
              </OTileHeader>
              <Panel collapsible expanded={this.state.openedAPI === Api.Wizard}>
                <div className='contentPadding'>
                  <h2 className='exampleHeader'>code example</h2>
                  <div className='codeExample'>
                    <Image src={owizardDetail} responsive />
                  </div>
                  <div className='contentPadding'>
                    <h2 className='exampleHeader'>Props</h2>
                    <Table responsive>
                      <thead>
                        <tr>
                          <th>prop</th>
                          <th>type</th>
                          <th>default</th>
                          <th>description</th>
                          <th>options</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>data</td>
                          <td>IOWizardData</td>
                          <td>array</td>
                          <td></td>
                          <td>will shows the steps inside the wizard</td>
                        </tr>
                      </tbody>
                    </Table>
                  </div>
                  <Image src={oWizardStepDetails} responsive />
                  <Table responsive>
                    <thead>
                      <tr>
                        <th>prop</th>
                        <th>type</th>
                        <th>description</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>header</td>
                        <td>JSX.Element |string</td>
                        <td>set the wizard step header</td>
                      </tr>
                      <tr>
                        <td>content</td>
                        <td>JSX.Element |string</td>
                        <td>set the wizard step content</td>
                      </tr>
                      <tr>
                        <td>completed</td>
                        <td>boolean</td>
                        <td>set the wizard step completed</td>
                      </tr>
                      <tr>
                        <td>current</td>
                        <td>boolean</td>
                        <td>set the wizard step current</td>
                      </tr>
                    </tbody>
                  </Table>
                </div>
              </Panel>
              <div className='oWizardWrapper'>
                <OWizard className='wizardDemo' data={this.state.wizardData} onSelect={(eventKey) => {
                  this.updateWizardContent(eventKey)
                }} />
              </div>
            </OTile>
          </Row>
        }
        {/*Document Thumbnail*/}
        <Row>
          <OTile xs={12} md={12}>
            <OTileHeader title='document thumbnail'>
              {this.showAPI(Api.DocumentThumbnail)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.DocumentThumbnail}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={documentThumbnail} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>key</td>
                      <td>string | number</td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>fileName</td>
                      <td>string</td>
                      <td></td>
                      <td>file name</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>fileSize</td>
                      <td>string</td>
                      <td></td>
                      <td>file size</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>className</td>
                      <td>string</td>
                      <td></td>
                      <td>custom className</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>loading</td>
                      <td>boolean</td>
                      <td></td>
                      <td>show animation to indicate file loading to server</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>progress</td>
                      <td>string</td>
                      <td></td>
                      <td>file upload progress</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>completed</td>
                      <td>boolean</td>
                      <td></td>
                      <td>show indication for upload completion</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='contentPadding'>
              <div>
                {document.getElementsByTagName('BODY').item(0).className === 'SelfCare' ?
                  <OAccordion accordion data={accordionData1} isCollapsible={false} />
                  : ''
                }
              </div>
              <div className='hiddenSC'>
                {document.getElementsByTagName('BODY').item(0).className === 'CSR' ?
                  <OMasterDetail eventKey='x'
                    onChange={eventKey => this.setState({ eventKey })} >
                    <OMasterDetailItem title={<ODocumentThumbnail fileName='someFileName.pdf' fileSize='(0.93KB)' completed />} eventKey='x'>
                      <div>Content </div>
                    </OMasterDetailItem>
                    <OMasterDetailItem disabled title={<ODocumentThumbnail fileName='someFileName.pdf' fileSize='(1.92KB)' progress='65%' loading />}>
                      <div>Content </div>
                    </OMasterDetailItem>
                    <OMasterDetailItem disabled title={<ODocumentThumbnail fileName='someFileName.pdf' fileSize='(3.85KB)' progress='10%' loading />}>
                      <div>Content </div>
                    </OMasterDetailItem>
                  </OMasterDetail> : ''}</div>
            </div>
          </OTile>
        </Row>
        {/*OAccordion*/}
        <Row>
          <OTile xs={12} md={12}>
            <OTileHeader title='Accordion'>
              {this.showAPI(Api.Accordion)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.Accordion}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <Image src={accordion1} responsive />
                <Image src={accordion2} responsive />
              </div>
            </Panel>
            <div>
              <OAccordion accordion data={accordionData} isCollapsible={true} />
            </div>
          </OTile>
        </Row>
        {/*Document upload*/}
        <Row>
          <OTile xs={12} md={12}>
            <OTileHeader title='document upload'>
              {this.showAPI(Api.DocumentUpload)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.DocumentUpload}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={documentUpload} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>disabled</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>Disable the button</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>key</td>
                      <td>string | number</td>
                      <td></td>
                      <td>element key</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>id</td>
                      <td>string</td>
                      <td></td>
                      <td>input id</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>name</td>
                      <td>string</td>
                      <td></td>
                      <td>input name</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>className</td>
                      <td>string</td>
                      <td></td>
                      <td>custom className</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>multiple</td>
                      <td>boolean</td>
                      <td></td>
                      <td>enable multiple file selection</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>accept</td>
                      <td>string</td>
                      <td></td>
                      <td>file_extension|audio|video|image|media_type' comma separated to use more than one: '.png, .jpg, .pdf'</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>maxSize</td>
                      <td>number</td>
                      <td></td>
                      <td>maximum file size in MB</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>buttonStyle</td>
                      <td>'primary' | 'secondary' | 'link'</td>
                      <td>'secondary'</td>
                      <td>set button style</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>buttonTitle</td>
                      <td>string</td>
                      <td></td>
                      <td>set buttom title</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onSelect</td>
                      <td>function</td>
                      <td></td>
                      <td>enable multiple file selection</td>
                      <td>return object with target, file list and errors</td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='contentPadding'>
              <ODocumentUpload
                buttonStyle='secondary'
                buttonTitle='upload file'
                maxSize={0.5}
                accept='.png, .jpg, .pdf'
                multiple
                id='upload1'
                name='upload'
                onSelect={(info) => {
                  console.info(info)
                }} />
            </div>
          </OTile>
        </Row>
        {/*Document Download*/}
        <Row>
          <OTile xs={12} md={12}>
            <OTileHeader title='document download'>
              {this.showAPI(Api.DocumentDownload)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.DocumentDownload}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={documentDownload} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>base64</td>
                      <td>String</td>
                      <td></td>
                      <td>the converted file to download in base64 encoding. once filled the file will be downloaded.</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>filename</td>
                      <td>string</td>
                      <td></td>
                      <td>the file's name including extention.</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onClick</td>
                      <td>function with single argument - key.</td>
                      <td></td>
                      <td>will call an action to get the file's base64 and insert it to the 'base64' prop.' </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>documentKey</td>
                      <td>string | number</td>
                      <td></td>
                      <td>file identifier will be added as argument to each action</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>className</td>
                      <td>string</td>
                      <td></td>
                      <td>class names to be addded to the component</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>disabled</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>indicated whether the link can be clicked or not.</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='contentPadding'>
              {this.state.currentTheme === 'care' ?
                <ODocumentDownload base64={this.state.base64}
                  fileName={fileDetails.displayValue}
                  onChildrenClick={this.GetBase64File.bind(this)}
                  id={'ODocumentDownload' + fileDetails.id}
                  documentKey={fileDetails.id}>

                  <span className={'pdfImage'} ></span>
                  <a>{fileDetails.displayValue}</a>

                </ODocumentDownload>
                :
                <ODocumentDownload base64={this.state.base64}
                  fileName={fileDetails.displayValue}
                  onChildrenClick={this.GetBase64File.bind(this)}
                  id={'ODocumentDownload' + fileDetails.id}
                  documentKey={fileDetails.id}>

                  <span className={'pdfImage'} ></span>
                  <a>{fileDetails.displayValue}</a>

                </ODocumentDownload>
              }
            </div>
          </OTile>
        </Row>
        {/*Document Actions*/}
        <Row>
          <OTile xs={12} md={12}>
            <OTileHeader title='document actions'>
              {this.showAPI(Api.DocumentActions)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.DocumentActions}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={documentActions} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>disabled</td>
                      <td>{`Array<'view' | 'edit' | 'remove'>`}</td>
                      <td>false</td>
                      <td>will disable the items in the array</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>documentKey</td>
                      <td>string | number</td>
                      <td></td>
                      <td>file identifier will be added as argument to each action</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>view</td>
                      <td>string | JSX.Element</td>
                      <td></td>
                      <td>text or element to be under 'view' item </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>edit</td>
                      <td>string | JSX.Element</td>
                      <td></td>
                      <td>text or element to be under 'edit' item </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>remove</td>
                      <td>string | JSX.Element</td>
                      <td></td>
                      <td>text or element to be under 'remove' item </td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onView?(key: string | number): void</td>
                      <td>function</td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onEdit?(key: string | number): void</td>
                      <td>function</td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onRemove?(key: string | number): void</td>
                      <td>function</td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='contentPadding'>
              {this.state.currentTheme === 'care' ?
                <ODocumentActions disable={['edit']} view='' edit='' remove='' onView={(key) => { console.info('view ' + key) }} onEdit={(key) => { console.info('edit ' + key) }} onRemove={(key) => { console.info('remove ' + key) }} documentKey='aaa' />
                :
                <ODocumentActions disable={['edit']} view='View' edit='Edit' remove='Remove' onView={(key) => { console.info('view ' + key) }} onEdit={(key) => { console.info('edit ' + key) }} onRemove={(key) => { console.info('remove ' + key) }} documentKey='aaa' />}
            </div>
          </OTile>
        </Row>

        {/*Collapsible tabs*/}
        <Row>
          <OTile xs={12} md={12}>
            <OTileHeader title='Collapsible tabs'>
              {this.showAPI(Api.CollapsibleTabs)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.CollapsibleTabs}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={collapsibleTabs} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>data</td>
                      <td>IOCollapsibleTabsData</td>
                      <td></td>
                      <td>see IOCollapsibleTabsData props</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>className</td>
                      <td>string</td>
                      <td></td>
                      <td>custom className</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>justified</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>will spread the tabs on parent full width</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onSelect?(key: string | number): void</td>
                      <td>function</td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
                <h2 className='exampleHeader'>IOCollapsibleTabsData props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>defaultActiveKey</td>
                      <td>string | number</td>
                      <td></td>
                      <td>default selected tab</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>activeKey</td>
                      <td>string | number</td>
                      <td></td>
                      <td>in case you chose to use as controlled component-this should be mapped to state</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>tabs</td>
                      <td>{'Array<IOCollapsibleTabsItem>'}</td>
                      <td></td>
                      <td>see IOCollapsibleTabsItem props</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={collapsibleList} responsive />
                </div>
                <h2 className='exampleHeader'>IOCollapsibleTabsItem props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>key</td>
                      <td>string | number</td>
                      <td></td>
                      <td>default selected tab</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>disabled</td>
                      <td>boolean</td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>label</td>
                      <td>tab label or panel header</td>
                      <td></td>
                      <td>string | JSX.Element</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>content</td>
                      <td>tab or panel content</td>
                      <td></td>
                      <td>string | JSX.Element</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='contentPadding'>
              <OCollapsibleTabs data={this.collapsibleTabsData} onSelect={(eventKey) => { console.info(`selected tab: ${eventKey}`) }} />
            </div>
          </OTile>
        </Row>
        <Row>
          <OTile autoFocus xs={12} md={12} id='dataExport'>
            <OTileHeader title='data export'>
              {this.showAPI(Api.DataExport)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.DataExport}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={dataExport} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                      <th>options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>dataSource</td>
                      <td>any</td>
                      <td></td>
                      <td>Data source for excel export</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>columnsDefinitionFromProps</td>
                      <td>ODataExportColumnDefinition[]</td>
                      <td></td>
                      <td>Definition for each column (name, width, format etc)</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>name</td>
                      <td>string</td>
                      <td></td>
                      <td>Widget's page name</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>message</td>
                      <td>string</td>
                      <td></td>
                      <td>The text for the button</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>config</td>
                      <td>ODataExportConfiguration</td>
                      <td></td>
                      <td>Configuration props (enable, filename etc)</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onSave</td>
                      <td>function</td>
                      <td></td>
                      <td>Fired when file is finished with a boolean argument indicating success</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>onClick</td>
                      <td>function</td>
                      <td></td>
                      <td>Fired when button is clicked</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>loadAsync</td>
                      <td>boolean</td>
                      <td></td>
                      <td>Set to true if data is to be loaded at a later stage and onClick should not trigger download immediately</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>loading</td>
                      <td>boolean</td>
                      <td></td>
                      <td>Set to control loading state. Should be set to true while waiting for async operations and false once new data is passed as props</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>header</td>
                      <td>any[][]</td>
                      <td></td>
                      <td>Data to be added as header to the exported file</td>
                      <td></td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <ODataExport
              dataSource={
                [
                  {
                    fullName: 'John Doe',
                    dateOfBirth: new Date(),
                    amount: 100
                  },
                  {
                    fullName: 'Jack Smith',
                    dateOfBirth: new Date(),
                    amount: 200.22
                  }
                ]}
              columnsDefinitionFromProps={
                [
                  {
                    name: 'fullName',
                    label: 'Full Name',
                    width: 15,
                    transFn: (fullName: string) => fullName.toUpperCase()
                  },
                  {
                    name: 'dateOfBirth',
                    label: 'Date of Birth',
                    width: 20,
                    kind: 'd',
                  },
                  {
                    name: 'amount',
                    label: 'Amount',
                    width: 20,
                    kind: 'n',
                    format: '\$\#0.00'
                  }
                ]
              }
              config={{
                enabled: true,
                widgets: [
                  {
                    name: 'Core',
                    filename: '{name}'
                  }
                ]
              }}
              name='Core'
              message='Download' />
          </OTile>
        </Row>
        {/*help*/}
        <Row>
          <OTile xs={12} md={12} minHeight='130px' id='help'>
            <OTileHeader title='help'>
              {this.showAPI(Api.Help)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.Help}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={help} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>helpStorageProvider</td>
                      <td>HelpStorageProviderContract</td>
                      <td></td>
                      <td>Dictionary structure for fast lookups</td>
                    </tr>
                    <tr>
                      <td>helpPresentationProvider</td>
                      <td>HelpPresentationProviderContract</td>
                      <td></td>
                      <td>Responsible for presenting the requested URL</td>
                    </tr>
                    <tr>
                      <td>helpKey</td>
                      <td>string</td>
                      <td></td>
                      <td>The key value of the collection mapping</td>
                    </tr>
                    <tr>
                      <td>icon</td>
                      <td>string</td>
                      <td></td>
                      <td>URL path of the icon</td>
                    </tr>
                    <tr>
                      <td>disabled</td>
                      <td>boolean</td>
                      <td></td>
                      <td>Help icon/button will be visually and functionally disabled</td>
                    </tr>
                    <tr>
                      <td>small</td>
                      <td>boolean</td>
                      <td></td>
                      <td>Help icon/button will be in small and bigger/default size</td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <OHelp

              helpPresentationProvider={this.hpp}
              helpStorageProvider={this.hsp}
              helpKey='test'
            />
          </OTile>
        </Row>
        {/*Responsive*/}
        <Row>
          <OTile xs={12} md={12} minHeight='130px' id='help'>
            <OTileHeader title='Responsive utility'>
              {this.showAPI(Api.Responsive)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.Responsive}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={responsive} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <strong>Currently props not supported. Tablet, mobile and desktop are fixed to bootstrap media queries</strong>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>minWidth</td>
                      <td>string | number</td>
                      <td></td>
                      <td>min width for media query</td>
                    </tr>
                    <tr>
                      <td>maxWidth</td>
                      <td>string | number</td>
                      <td></td>
                      <td>max width for media query</td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='contentPadding'>

              <ODesktop><h1>Desktop</h1><h2>min-width: 992px</h2></ODesktop>
              <OTablet><h1>Tablet</h1><h2>min-width: 768px max-width: 991px</h2></OTablet>
              <OMobile><h1>Mobile</h1><h2>max-width: 767px</h2></OMobile>

            </div>
          </OTile>
        </Row>
        {/*Scroll*/}
        <Row>
          <OTile xs={12} md={12} minHeight='130px' id='help'>
            <OTileHeader title='Scroll to element'>
              {this.showAPI(Api.ScrollTo)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.ScrollTo}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={scrollTo} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <strong>check out <a href='https://www.npmjs.com/package/react-scrollchor'>react-scrollchor</a> for documentation</strong>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>to</td>
                      <td>string</td>
                      <td></td>
                      <td>id of element to scroll to</td>
                    </tr>
                    <tr>
                      <td>beforeAnimate</td>
                      <td></td>
                      <td></td>
                      <td>callback function triggered before scroll</td>
                    </tr>
                    <tr>
                      <td>afterAnimate</td>
                      <td></td>
                      <td></td>
                      <td>callback function triggered after scroll</td>
                    </tr>
                    <tr>
                      <td>disableHistory</td>
                      <td>boolean</td>
                      <td>false</td>
                      <td>enable/disable update browser history with scroll behaviours</td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='contentPadding'>

              {/* scroll to element by ID (similar to html anchor) */}
              <OScroll to='#colors' className='nav-link'><OButton primary label='Scroll to colors'></OButton></OScroll>
              {/* scroll to element programmatically */}
              <OScroll ref={ref => (this.scrollToDataExport = ref)} to='typo' />
              <OButton primary label='programmatically scroll'
                onClick={() => { this.scrollToDataExport.simulateClick() }} />
            </div>
          </OTile>
        </Row>
        {/*Extended Data*/}
        <Row>
          <OTile xs={12} md={12} minHeight='130px' id='help'>
            <OTileHeader title='Extended Data'>
              {this.showAPI(Api.ExtendedData)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible expanded={this.state.openedAPI === Api.ExtendedData}>
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={exdata} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>id</td>
                      <td>string</td>
                      <td></td>
                      <td>id of element, required</td>
                    </tr>
                    <tr>
                      <td>attributes</td>
                      <td>ExtendedAttribute</td>
                      <td></td>
                      <td>Array of extended attributes, required</td>
                    </tr>
                    <tr>
                      <td>values</td>
                      <td>ExtendedData</td>
                      <td></td>
                      <td>Array of existing extended data values, optional</td>
                    </tr>
                    <tr>
                      <td>onChange</td>
                      <td>function</td>
                      <td></td>
                      <td>Function to be called when data is changed, passed an array of ExtendedData</td>
                    </tr>
                    <tr>
                      <td>isValid</td>
                      <td>function</td>
                      <td></td>
                      <td>Function to be called to validate the entered extended data values</td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='contentPadding'>
              <OExtendedData id='OExtendedData' ref={ref => this.extendedDataRef = ref} values={this.state.extendedDataValues} attributes={this.extendedData} onChange={this.handleExtendedDataChange} />
              <OButton id='exdata_submit' label='Submit' submit type='submit' onClick={this.handleExtendedDataValidate} />
            </div>
          </OTile>
        </Row>
        <Row>
          <OTile xs={12} md={12} minHeight='130px' id='help'>
            <OTileHeader title='Label'>
              {this.showAPI(Api.Label)}
              {this.compatible(true, true)}
            </OTileHeader>
            <Panel collapsible
              expanded={this.state.openedAPI === Api.Label}
            >
              <div className='contentPadding'>
                <h2 className='exampleHeader'>code example</h2>
                <div className='codeExample'>
                  <Image src={label} responsive />
                </div>
                <h2 className='exampleHeader'>Props</h2>
                <Table responsive>
                  <thead>
                    <tr>
                      <th>prop</th>
                      <th>type</th>
                      <th>default</th>
                      <th>description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>content</td>
                      <td>React.Node</td>
                      <td>none</td>
                      <td>Label content</td>
                    </tr>
                    <tr>
                      <td>type</td>
                      <td>Type enum</td>
                      <td>Type.Default: no background color</td>
                      <td>Background Color: Type.Success: $c3, Type.Warning: $c5, Type.Danger: $c12, Type.Info: $c6, Type.Primary: $c13</td>
                    </tr>
                    <tr>
                      <td>className</td>
                      <td>string </td>
                      <td>none</td>
                      <td>It can be used to provide new, CSS styles for the component</td>
                    </tr>
                    <tr>
                      <td>id</td>
                      <td>string </td>
                      <td>none</td>
                      <td>unique id</td>
                    </tr>
                  </tbody>
                </Table>
              </div>
            </Panel>
            <div className='contentPadding'>
              <OLabel
                id='OLabelSuccess'
                content='Success'
                type={Type.Success}
              />
              <OLabel
                id='OLabelDanger'
                content='Danger'
                type={Type.Danger}
                className={styles.labelMargin}
              />
              <OLabel
                id='OLabelWarning'
                content='Warning'
                type={Type.Warning}
                className={styles.labelMargin}
              />
              <OLabel
                id='OLabelInfo'
                content='Info'
                type={Type.Info}
                className={styles.labelMargin}
              />
              <OLabel
                id='OLabelPrimary'
                content='Primary'
                type={Type.Primary}
                className={styles.labelMargin}
              />
              <OLabel
                id='OLabelDefault'
                content='Default'
                type={Type.Default}
                className={styles.labelMargin}
              />
            </div>
          </OTile>
        </Row>
        <Row>
          <OTile xs={12} md={12}>
            <OAlerts headerMessage='Validation Errors' data={[{ visible: true, status: 'danger', closable: true, alertMessage: 'error message 1' }, { visible: true, status: 'info', closable: true, alertMessage: 'info message 1' }]}></OAlerts>
          </OTile></Row>
      </OPageContainer >
    )
  }
}
export default hot(module)(UIComponents)
