
import { EnterHook, LeaveHook } from 'react-router'
import { getWidgetsAdmin } from '@optima/core-ui-libs/widgetFramework'

function getUIComponent(nextState, cb) {
    require.ensure([], (require) => {
        cb(null, require('./pages/UIComponents').default)
    }, 'ui-components')
}
function getValidation(nextState, cb) {
    require.ensure([], (require) => {
        cb(null, require('./pages/Validation').default)
    }, 'form-validation')
}
function getConfigurableUI(nextState, cb) {
    require.ensure([], (require) => {
        cb(null, require('./pages/ConfigurableUI').default)
    }, 'configurable-ui')
}

export const UI_COMPONENTS_ENTER: EnterHook = (nextState, replace, cb) => {
    console.info('Welcome to ui-components page!')
    cb && cb()
}
export const FORM_VALIDATION_ENTER: EnterHook = (nextState, replace, cb) => {
    console.info('Welcome to validation page!')
    cb && cb()
}
export const CONFIGURABLE_UI_ENTER: EnterHook = (nextState, replace, cb) => {
    console.info('Welcome to configurable-ui page!')
    cb && cb()
}

export const UI_COMPONENTS_LEAVE: LeaveHook = (prevState) => {
    console.info('Leave ui-components page!')
}
export const FORM_VALIDATION_LEAVE: LeaveHook = (prevState) => {
    console.info('Leave validation page!')
}
export const CONFIGURABLE_UI_LEAVE: LeaveHook = (prevState) => {
    console.info('Leave configurable-ui page!')
}

export const getExampleRoutesComponents = {
    getUIComponent: getUIComponent,
    getValidation: getValidation,
    getConfigurableUI: getConfigurableUI,
    getWidgetsAdmin: getWidgetsAdmin
}



