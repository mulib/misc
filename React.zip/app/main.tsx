/// <reference path='../typings/all.d.ts' />

const needsPolyfills = (): boolean => {
    let isInteger: boolean = 'isInteger' in Number
    let isNan: boolean = 'isNaN' in Number
    let find: boolean = 'find' in Array.prototype
    let assign: boolean = 'assign' in Object
    let needsPolyfills: boolean = !isInteger || !isNan || !find || !assign
    if (needsPolyfills) {
        console.warn(`You are using an outdated browser. Loading polyfills because the following is not supported: [Number.isInteger: ${isInteger},Number.isNan: ${isNan},Array.prototype.find: ${find},Object.assign ${assign}]`)
    }
    return needsPolyfills
}

if (window.Promise === undefined) {
    require('core-js/es6/promise')
}

if (needsPolyfills()) {
    require.ensure([], (require) => {
        require('core-js/es6/number')
        require('core-js/es6/array')
        require('core-js/es6/object')
    }, 'polyfills')
}

import * as React from 'react'
import * as ReactDOM from 'react-dom'

const injectTapEventPlugin = require('react-tap-event-plugin')
import axios from 'axios'
import * as _ from 'lodash'

import {
    rootChangeHooks,
    rootEnterHooks,
    rootGetComponents
} from './layout/rootRouter'
import { viewTypes, viewTypesSchemas, commonSchemas } from './viewTypes'
import AppContainer from '@optima/core-ui-libs/common/layout/AppContainer'
import { ApiActionMap } from '@optima/core-ui-esb-sdk'
import { FunctionMap, CoreBaseWidgetConfiguration } from '@optima/core-ui-libs/widgetFramework'
import { ApiActionsMap } from '@optima/core-ui-esb-sdk/apiCalls/generated/ApiActionsMap'
import { CoreDataSourceFunctionMap } from '@optima/core-ui-libs/common/dataSourceFunctions/CoreDataSourceFunctionMap'
import { exampleApi } from './layout/reducers/exampleApiActions'
import { setConfigurationAction } from '@optima/core-ui-libs'
import { AppBaseWidgetConfiguration } from './configuration'
import { CoreApiActionsMap } from '@optima/core-ui-libs/widgetFramework'

//  Inject store variable into each component context
//
import { Provider as ReduxProvider, Store } from 'react-redux'
import { AppState } from 'store/AppStore'

// add have its type definition available to all HTML elements...
declare module 'react' {
    interface HTMLProps<T> {
        onTouchTap?: React.EventHandler<React.TouchEvent<T>>
    }
}

axios.get(window.location.protocol + '//' + window.location.host + '/config')
    .then((response) => {
        const config = _.merge({}, commonConfiguration, response.data)
        window.appConfig = config
        require('!style-loader!css-loader!resolve-url-loader!sass-loader?sourceMap!./../styles/site.scss')
        const appStore = require('./store/AppStore')

        // Put the Core theme first.
        require('@optima/theme-self-care/styles/icons.scss')
        require('@optima/theme-care/styles/fonts/fonts.scss')
        require('@optima/theme-self-care/styles/theme.scss')
        require('@optima/theme-self-care/styles/fonts/fonts.scss')

        injectTapEventPlugin()

        // setup global axios defaults
        axios.defaults.timeout = config.client.axios.timeout
        const store: Store<AppState> = appStore.appStore(config)
        ReactDOM.render(
            <ReduxProvider store={store}>
                <AppContainer
                    apiActionMap={apiActions}
                    changeHooksBuilder={rootChangeHooks}
                    className='CSR'
                    commonSchemas={commonSchemas}
                    dataSourceFunctionMap={dataSourceFunctions}
                    enterHooksBuilder={rootEnterHooks}
                    getComponentsLookup={rootGetComponents}
                    viewTypeLookup={viewTypes}
                    viewTypesSchemaLookup={viewTypesSchemas} />
            </ReduxProvider>,
            document.getElementById('app-container')
        )
    })

const apiActions: ApiActionMap = {
    ...ApiActionsMap,
    ...CoreApiActionsMap,
    exampleApi: exampleApi,
    setConfigurationAction: setConfigurationAction

}

const dataSourceFunctions: FunctionMap = {
    ...CoreDataSourceFunctionMap
}

export const commonConfiguration = _.merge({},
    CoreBaseWidgetConfiguration,
    AppBaseWidgetConfiguration
)
