# Default Framework Configuration

## Configuration Files

Common configurations can be defined for use in the configuration editor. To do this, create a JSON file in the widgetFramework/configuration directory. For example, for a default configuration for the "OPager" widget would be in the "OPager.json" file:

```json
{
    "widgetConfiguration": {
        "OPager": {
            "name": "OPager",
            "description": "Default OPager widget configuration",
            "defaultView": "WithDropdown",
            "views": {
                "WithDropdown": {
                    "type": "OPager",
                    "description": "Pager with page size drop down selection",
                    "viewConfiguration": {
                        "pageSizesList": [5, 10, 15]
                    }
                },
                "WithoutDropdown": {
                    "type": "OPager",
                    "description": "Pager without page size drop down selection",
                    "viewConfiguration": {
                        "pageSizesList": [5]
                    }
                }
            }
        }
    },
    "defaultViewConfiguration": {
        "OPager": {
            "previousLabel": {
                "type": "message",
                "messageId": "Pager.Labels.Previous"
            },
            "nextLabel": {
                "type": "message",
                "messageId": "Pager.Labels.Next"
            },
            "itemsPerPageLabel": {
                "type": "message",
                "messageId": "Pager.Labels.PerPage"
            },
            "pageSizesList": [6, 12, 24]
        }
    }
}
```

The configuration contains whatever is necessary for the widget, "widgetConfiguration", "defaultViewConfiguration", "dataSourceDefinitions", and/or "apiActionConfiguration" values.

The configurations must be imported in the widgetFramework/configuration/index.ts file, and added to the "CoreWidgetConfiguration" structure.

## Test

Each configuration file should have a corresponding test .spec.tsx file to validate that the configuration can be loaded and performs as expected.
