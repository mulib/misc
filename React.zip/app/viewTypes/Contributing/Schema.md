# Schema

JSON schemas are used to describe the configuration of the widget framework. There is a JSON schema for the top level of the widget framework configuration, and you need to create JSON schemas to describe your view and data source configurations

## Basics

See [Understanding JSON Schema](https://spacetelescope.github.io/understanding-json-schema/index.html) for an overview of JSON schema

## Specifics

You need to create a JSON schema that describes the structure, allowed values, and required properties of your configuration. Schemas that are reused across other schemas are stored in the `widgetFramework/viewTypes/CommonSchemas` directory. Schemas specific to a view are in each view type's directory. The schemas are used to validate the configuration when a view of the view type is loaded by the widget framework, and for the configuration editor, to build forms to create and edit configurations. There should be a schema per view type, and it should follow the naming convention:

- ViewTypeName.schema.json

You can use the [JSON Schema Editor](https://json-editor.github.io/json-editor/) to help show what the data entered and accepted for your schemas will look like

Schemas are imported in the `widgetFramework/viewTypes/index.ts` file and added to the CoreViewTypesSchemas structure, or the `widgetFramework/CommonSchemas/index.ts` file and added to the `"commonSchemas"` array.

## Notes

- Do not include a `“title”` value for fields. It causes the interface generator to create a data type for each `“title”` value, and it’s really useless information. Now, for object definitions, they are useful, and will be used when there is an editor, for selecting the type for things like “anyOf”.
- Do not have an “`object”` within an `“object”`. Always use a `“$ref”`, otherwise, you do not get an interface generated, and reference handling may not be correct. For instance, the definition:

```json
        "ViewTypeIterator": {
            "title": "ViewTypeIterator",
            "type": "object",
            "properties": {
                "key": {
                    "type": "string"
                },
                "args": {
                    "type": "string"
                },
                "dataAttribute": {
                    "type": "string"
                },
                "template": {
                    "type": "object",
                    "title": "template",
                    "properties": {
                        "header": {
                            "$ref": "/common#/definitions/ContentDescriptor"
                        },
                        "body": {
                            "$ref": "/common#/definitions/ContentDescriptor"
                        }
                    },
                    "required": [
                        "header",
                        "body"
                    ]
                }
            }
```

Should be:

```json
        "ViewTypeIterator": {
             "title": "ViewTypeIterator",
            "type": "object",
            "properties": {
                "key": {
                    "type": "string"
                },
                "args": {
                    "type": "string"
                },
                "dataAttribute": {
                    "type": "string"
                },
                "template": {
                    "$ref": "#/definitions/ViewTypeIteratorTemplate"
                }
            },
            "required": [
                "template",
                "dataAttribute"
            ]
        },
        "ViewTypeIteratorTemplate": {
              "type": "ViewTypeIteratorTemplate",
              "type": "object",
              "properties": {
                  "header": {
                     "$ref": "/common#/definitions/ContentDescriptor"
                  },
                  "body": {
                      "$ref": "/common#/definitions/ContentDescriptor"
                  }
              },
              "required": [
                  "header",
                  "body"
              ]
          }
```

- The same goes for `“definitions”`, they should all be at the top level. Yes, both of these would be valid schemas, but they do not play well with others.
- Make sure your “$ref” paths are correct. No extra “/”, no spaces.
- You do not need to include anything other than the `“$ref”` when it is a reference. No `“type”` or `“title”`, the schema gets that from the reference.
- Include test cases for invalid configurations. You can use the "OWidgetFramework" component with the schema and configurations since it validates the configuration against the schema. Make sure required options are caught if they aren't specified.
- You probably want to use `"oneOf"` instead of `"anyOf"` in most cases. Things should probably match one and only one type.
- If objects have a "type" property, enumerate the valid values, even if it's only one value.
- You don't have to use `"oneOf"` or `"anyOf"` for base data types. You can just use `{ "type": [ "string", "number" ] }` etc. Unless of course you want to provide other things, such as restrictions on the values.
- Say something once, why say it again? If you're repeating something, make it a definition in your schema. Repeat something used in another schema? Make it a common schema.
- Watch out naming a definition the same as in another file. Definition names should be unique.
- Anything that is of type `"object"` with `"properties"` and no match-all `"patternProperties"` should have `"additionalProperties": false` so that no additional properties are allowed, and to catch misspelled properties.
