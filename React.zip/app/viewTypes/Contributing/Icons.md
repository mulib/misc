### 4. IconParams

IconParams describe an image/icon by providing the icon name
**Note:** image width, hight or any style-related attributes should be defined as part of .scss

using OContent with IconParams will add the icon to the page, you will need to define width/hight and other css properties in order to display the image with the correct size and fit.

#### 4.1. interface

| Attribute | Type   | Description      | Required |
| --------- | ------ | ---------------- | -------- |
| type      | 'icon' |                  | true     |
| icon      | string | name of the icon | false    |

#### 4.2. example

```json
{
    "viewConfiguration": {
        "content": {
            "type": "icon",
            "icon": "edit"
        }
    }
}
```

`tsx:`

```jsx
<OContent contentParams={props.viewConfiguration.content}></OContent>
```

`output:`

HTML:

```html
<span class="icon edit"></span>
```

CSS:

```css
.icon.edit {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0i...);
}

```