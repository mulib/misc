# CONTRIBUTING

when developing a new view type it is important to well document it, so other people can easily understand functionality of your viewType as well as how to configure it.

 in order to have standard way for documenting viewType, you should use the `DemoSection` widget. this widget will enable you to showcase live example of widgetInstances that uses your viewType and document the widget configuration

## 1. `DemoSection` ViewType

The `DemoSection` viewType is built using three sections:

1. Textual description contains the name, short description and long description of a viewType
2. Live examples: list of widget instances to describe different variations of your viewType
3. README: .md file that contains the API and configuration examples

### 1.1. Interface

| Attribute                | Type                   | Description                                                   |
| ------------------------ | ---------------------- | ------------------------------------------------------------- |
| viewTypeName             | MessageFormatterParams | viewType name. this name will render as main header           |
| longDescription          | MessageFormatterParams | long description                                              |
| liveExamples             | LiveExample[]          | see interface below                                           |
| liveExamples.title       | MessageFormatterParams | instance title                                                |
| liveExamples.description | MessageFormatterParams | instance description                                          |
| liveExamples.content     | WidgetInstanceParams   | widget instance that shows specific variation of the viewType |
| readme                   | string                 | Name of the readme entry in ReadmeLookUp                      | this name is a reference to your exported README.md file (see chapter 1.3 ) |

```ts
interface LiveExample {
    title: MessageFormatterParams,
    subTitle: MessageFormatterParams,
    description: MessageFormatterParams,
    content: WidgetInstanceParams
}
```

### 1.2. example

the example below demonstrates the configuration of the `DemoSection` widget for the `OButton` viewType.
the live example section contains two examples: primary button and secondary button

first, configure few widget instances that demonstrate variations of your viewType

```json
{
"ConfigurableUI.Button.Secondary": {
        "baseWidget": "DemoButton",
        "view": "Secondary"
    },
"ConfigurableUI.Button.Primary": {
        "baseWidget": "DemoButton",
    }
}

```

then, configure a new view with the type `DemoSection` under the `DemoSection` widgetConfiguration:
notice that the `liveExamples` section contains the textual description and content of both primary and secondary widget instances

```json
{
"DemoSection": {
    "name": "DemoSection",
    "description": "DemoSection shows live examples and API documentation of a view type",
    "defaultView": "WelcomeDemoSection",
    "views": {
        "OButtonDemoSection": {
            "type": "DemoSection",
            "viewConfiguration": {
                "viewTypeName": { "type": "message", "messageId": "ConfigurableUI.DemoPage.OButtonDemoSection.name" },
                "longDescription": { "type": "message", "messageId": "ConfigurableUI.DemoPage.OButtonDemoSection.longDescription" },
                "liveExamples": [
                    {
                    "title": { "type": "message", "messageId": "ConfigurableUI.DemoPage.OButtonDemoSection.liveExamples.primary.title" },
                    "description": { "type": "message", "messageId": "ConfigurableUI.DemoPage.OButtonDemoSection.liveExamples.primary.description" },
                    "content": { "type": "widgetInstance", "widgetInstanceId": "ConfigurableUI.Button.Primary" }
                    },
                    {
                    "title": { "type": "message", "messageId": "ConfigurableUI.DemoPage.OButtonDemoSection.liveExamples.secondary.title" },
                    "description": { "type": "message", "messageId": "ConfigurableUI.DemoPage.OButtonDemoSection.liveExamples.secondary.description" },
                    "content": { "type": "widgetInstance", "widgetInstanceId": "ConfigurableUI.Button.Secondary" }
                    }
                ],
                "readme": "OButton"
            }
        },
    }
}
```

## 1.3. `readme` section

notice to the entry `"readme": "OButton"`
the `OButton` value refers to the exported name in `CoreReadme` dictionary exported from `viewTypes/index.ts`

Continuing with OButton example:

By convention, the folder structure under viewType should look like this:

|- viewTypes

|-- OButton

|--- OButton.tsx

|--- OButton.spec.tsx

|--- OButton.messages.json <-in case you have default static messages to render in your viewType

|--- OButton.schema.json

|--- README.md

template for the README file can be found under `core-ui-libs/widgetFramework/viewTypes/README_TEMPLATE.md

after editing `README.md` you should export it from `core-ui-libs/widgetFramework/viewTypes/index.ts` like this:

```ts
const OButtonRM = require('./OButton/README.md')

export const CoreReadme = {
    OButton: OButtonRM
}
```

above set up will cause the Demo section to render the README.md file
