# API Calls

API actions can be configured in event handlers (currently only in the "onLoad" action).

## 1. interface

| Attribute | Type   | Description                         | Required |
| --------- | ------ | ----------------------------------- | -------- |
| policy    | string | "apiCall"                           | true     |
| apiAction | string | The name of the action to be called | true     |

## 2. example

```json
    {
        "policy": "apiCall",
        "apiAction": "actionName"
    }
```

## 3. API Action Map

The "actionName" is a reference into the "apiActionConfiguration" section of the application's configuration default.json file.

### 3.1. interface

| Attribute      | Type        | Description                                                          | Required |
| -------------- | ----------- | -------------------------------------------------------------------- | -------- |
| apiAction      | string      | Name of the API action to be called, reference into the apiActionMap | true     |
| condition      | data source | Controls the execution of the action                                 | false    |
| arguments      | array       | Arguments to be passed to the action function, if any                | true     |
| callStatus     | data source | Path to the call status structure for the API action                 | false    |
| resetOnUnmount | boolean     | Should the API reset action be called when the widget is unmounted   | false    |

### 3.2. example

```json

{
    "apiActionConfiguration": {
        "actionName": {
            "apiAction": "apiName",
            "condition": {
                "type": "store",
                "storeField": "apiName.callStatus"
            },
            "arguments": [
                {
                    "AccountInternalId": {
                        "type": "store",
                        "storeField": "accountNo"
                    }
                },
                {
                    "limit": {
                        "type": "static",
                        "entity": 100
                    }
                }
            ],
            "callStatus": {
                "type": "store",
                "storeField": "apiName.callStatus"
            },
            "resetOnUnmount": true
        }
    }
}

```



### 3.3. description



This makes the action reusable across views as needed, or they can be specific to the view, it's up to the developer to choose which "apiAction" value is to be used and configured. The "apiAction" value is a reference into the "apiActionMap" that is passed by the application to the AppContainer. It maps the "apiAction" value to a function to be called. The first argument to the function is the Redux "dispatch" function, the rest of the arguments are defined in the action configuration.



The arguments are specified as an array of values, the values will be passed in order to the action function after the "dispatch" argument. The example above matches an API action defined in the @optima/core-ui-esb-sdk package, where the second argument is the path parameter values, the third argument is the query parameter values, and so on. At the "leaf" level of an argument, the structure is the same as a data source value, so "store", "static", etc. values can be used. An argument structure can be as deeply nested as necessary, the application looks for the "leaf" values containing a "type" field that matches a data source type and processes the "leaf" into the value.



The "condition" value is something that returns "undefined" if the action should be executed, and anything else if the action should not be executed. This way actions that only need to be executed once (say, "enumerations") can be configured for multiple views but only executed if the specified value does not already exist. If no condition is specified, the action is always executed.



The "resetOnUnmount" value can be used to flag the API so that its store information is removed when the widget that used the API action is unmounted. Use this for transient data that other widgets will not need.



The "callStatus" value references the call status structure for the API action call. If the view only uses or cares about the status of one action, then the status could be referenced directly in the data source, and this configuration skipped. If there are multiple statuses that need to be aggregated into a single value, then a data source type of "computed" can be used:



```json

{

    "callStatus": {

        "type": "computed",

        "functionCall": {

            "functionName": "aggregateCallStatus",

            "arguments": [{

                "type": "static",

                "entity": "actionName"

            }]

        }

    }

}

```



The "functionCall" structure specifies the function name, which is a reference into a map of names to functions that is passed to the AppContainer and used by the widget framework. So the functions can come from libraries or the application. In this case, the "aggregateCallStatus" function is from the @optima/core-ui-libs package. The arguments are passed as an array to the function, again, in a structured data source format. In the case of the "aggregateCallStatus", it expects and array of action names, and will use the "callStatus" values configured for those actions to generate an aggregate status.

