# Content

Widget content is a result of view attributes, data, and sometime also other parameters like locale, timezone and theme

for example:

- Textual content, depends on locale, formattedMessage and data
- Number content depends on locale, data, and other format options (decimal point, separators, currency...)
- Date content depends on locale, data, and other format options (dateFormat, timezone...)
- Image content depends on the image path, as well as other image attributes (height, width, alt...)

ViewConfiguration describes how to render the runtime dataSource to the UI.

In order to describe how data will be rendered, you should use the `OContent` ui-component.

`OContent` gets parameters that describe the view parameters of a content, as well as mapping it to specific dataAttribute in the runtime dataSource

**the example below shows a simple widget that renders a greeting for the user:**

`default.json`

```json
{
    "viewConfiguration": {
        "content": {
            "type": "message",
            "messageId": "Example.Greeting",
            "dataAttribute": "user"
        }
    }
}
```

```json
{
    "dataSourceConfiguration": {
        "user": {
            "type": "static",
            "entity": { "firstName": "John", "lastName": "Snow" }
        }
    }
}
```

`ExampleViewType.messages.json`

```json
{
    "Example.Hello":"Hello {firstName} {lastName}"
}
```

`ExampleViewType.tsx`

```jsx
import * as React from 'react'

import { ViewTypeProps, BaseDataSource } from '@optima/core-ui-libs/widgetFramework'
import { OContent, MessageFormatterParams } from '@optima/core-ui-libs/ui-components'

export interface ExampleViewConfiguration {
    content?: MessageFormatterParams
}

interface User { firstName: string, lastName: string }

export interface ExampleDataSource extends BaseDataSource {
    user?: User,
}

export function ExampleViewType(props: ViewTypeProps<ExampleViewConfiguration, ExampleDataSource, {}>) {
    const { id, dataSource, viewConfiguration } = props
    return (
    <OContent contentParams={viewConfiguration.content} dataSource={dataSource} id={`${id}.content`} />
    )
}

```

`output:`

```html
<span>Hello John Snow</span>


```

**Conclusions:**

- whenever we need to render content within our viewType, we should use `OContent`
- `ContentParams` describes the necessary attributes needed in order to render the content
- in case the content include runtime data, contentParams should include the `dataAttribute` attribute (in above example, '**user**')
- `dataAttribute` should be mapped to specific attribute in the widget `dataSource`

## OContent interface

| Attribute     | Type              | Description                                                              | Required |
| ------------- | ----------------- | ------------------------------------------------------------------------ | -------- |
| contentParams | ContentParams     | view params and mapping to specific dataAttribute (see interface bellow) | true     |
| dataSource    | ContentDataSource | the viewType dataSource                                                  | false    |
| id            | string            |                                                                          | true     |
| className     | string            |                                                                          | false    |

## ContentParams type

```ts
export type ContentParams = MessageFormatterParams | NumberFormatterParams |DateFormatterParams | WidgetInstanceParams |  IconParams
```

## ContentDataSource interface

```ts
export interface ContentDataSource {
    [attributeName: string]: any
}
```

### 1. MessageFormatterParams

#### 1.1. interface

| Attribute     | Type      | Description                     | Required |
| ------------- | --------- | ------------------------------- | -------- |
| type          | 'message' |                                 | true     |
| dataAttribute | string    | mapping to dataSource attribute | false    |
| messageId     | string    | formattedMessage id             | true     |

#### 1.2. example

```json
{
    "viewConfiguration": {
        "content": {
            "type": "message",
            "messageId": "Example.Greeting",
            "dataAttribute": "user"
        }
    }
}
```

```json
{
    "dataSourceConfiguration": {
        "user": {
            "type": "static",
            "entity": { "firstName": "John", "lastName": "Snow" }
        }
    }
}
```

### 2. NumberFormatterParams

#### 2.1. interface

| Attribute     | Type                | Description                                                                                             | Required |
| ------------- | ------------------- | ------------------------------------------------------------------------------------------------------- | -------- |
| type          | 'number'            |                                                                                                         | true     |
| dataAttribute | string              | mapping to dataSource attribute                                                                         | false    |
| formatOptions | NumberFormatOptions | see [react-intl's FormattedNumber](https://github.com/yahoo/react-intl/wiki/Components#formattednumber) | false    |

#### 2.2. example

```json
{
    "viewConfiguration": {
        "content": {
            "type": "number",
            "dataAttribute": "amount",
            "formatOptions": {
                "minimumIntegerDigits": 1,
                "minimumSignificantDigits": 1
            }
        }
    }
}
```

```json
{
    "dataSourceConfiguration": {
        "amount": {
            "type": "static",
            "entity": 10300
        }
    }
}
```

`output:`

```html
<span>10,300</span>

```

### 3. DateFormatterParams

#### 3.1. interface

| Attribute      | Type          | Description                                                                                                   | Required |
| -------------- | ------------- | ------------------------------------------------------------------------------------------------------------- | -------- |
| type           | 'date'        |                                                                                                               | true     |
| dataAttribute  | string        | mapping to dataSource attribute                                                                               | false    |
| displayFormat  | DateFormatKey | the {DateFormatKey} to use for the display format. Defaults to the 'date' format                              | false    |
| originalFormat | DateFormatKey | when the date prop is a string, the {DateFormatKey} to use for parsing the date. Defaults to the 'api' format | false    |
| timezone       | string        | a TZ timezone value that can be used to override the default timezone from the config                         | false    |
| date           | string        | string or moment to format                                                                                    | false    |

```ts
type DateFormatKey = "api" | "date" | "dateTime" | "year" | "yearMonth"
```

#### 3.2. example

```json
{
    "viewConfiguration": {
        "content": {
        "type": "date",
        "dataAttribute": "date",
        "displayFormat": "dateTime"
        }
    }
}
```

```json
{
    "dataSourceConfiguration": {
        "date": {
            "type": "static",
            "entity": "2018-06-04T08:25:40.602Z"
        }
    }
}
```

`output:`

```html
<span>4 Jun 18 08:25</span>
```

### 4. IconParams

IconParams describe an image/icon by providing the icon name
**Note:** image width, hight or any style-related attributes should be defined as part of .scss

using OContent with IconParams will add the icon to the page, you will need to define width/hight and other css properties in order to display the image with the correct size and fit.

#### 4.1. interface

| Attribute | Type   | Description      | Required |
| --------- | ------ | ---------------- | -------- |
| type      | 'icon' |                  | true     |
| icon      | string | name of the icon | false    |

#### 4.2. example

```json
{
    "viewConfiguration": {
        "content": {
            "type": "icon",
            "icon": "edit"
        }
    }
}
```

`output:`

HTML:

```html
<span class="icon edit"></span>
```

CSS:

```css
.icon.edit {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0i...);
}

```

### 5. WidgetInstanceParams

OContent knows to render WidgetInstance... just pass the widgetInstanceId

#### 5.1. interface

| Attribute        | Type             | Description                                   | Required |
| ---------------- | ---------------- | --------------------------------------------- | -------- |
| type             | 'widgetInstance' |                                               | true     |
| widgetInstanceId | string           | widgetInstanceId as it appear in default.json | false    |

#### 5.2. example

```json
{
    "viewConfiguration": {
        "content": {
            "type": "widgetInstance",
            "widgetInstanceId": "Example.Widget.Instance"
        }
    }
}
```
