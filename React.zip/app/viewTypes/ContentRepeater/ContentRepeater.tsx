import * as React from 'react'

import { ViewTypeProps, BaseDataSource } from '@optima/core-ui-libs/widgetFramework'
import { OContent, ContentParams } from '@optima/core-ui-libs/ui-components'
import { OTile } from '@optima/core-ui-libs/ui-components'

export interface ContentRepeaterViewConfiguration {
    content: ContentParams
    className?: string
    list: string
}

export interface ContentRepeaterDataSource {
    [key: string]: any[]
}

export function ContentRepeater(props: ViewTypeProps<ContentRepeaterViewConfiguration, ContentRepeaterDataSource, {}>) {
    const { id, dataSource, viewConfiguration } = props
    let arr: JSX.Element[] = []
    dataSource && dataSource[viewConfiguration!.list] && dataSource[viewConfiguration!.list].forEach((entry, index) => {
        let _dataSource
        let _contentParams = Object.assign({}, viewConfiguration!.content)
        if (_contentParams.type === 'icon') {
            _contentParams['icon'] = entry
            _contentParams['title'] = entry
        } else {
            _dataSource = entry
        }
        arr.push(<OContent key={`${id}.content.${index}`} contentParams={_contentParams} dataSource={_dataSource} id={`${id}.content.${index}`} />)
    })
    return (
        <span id={id} className={viewConfiguration!.className}>
            {arr}
        </span>

    )
}