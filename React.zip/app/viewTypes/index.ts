import { CoreViewTypes, ViewTypeLookup, CoreReadme, CoreViewTypesSchemas, ViewTypeSchemaLookup, CoreCommonSchemas } from '@optima/core-ui-libs/widgetFramework'
import { ContentRepeater } from './ContentRepeater/ContentRepeater'
import { RefreshAppState } from './RefreshAppState/RefreshAppState'
import { DemoColumnViewType } from './DemoMisc/DemoColumnViewType'
import { DemoInputViewType } from './DemoMisc/DemoInputViewType'
import { DemoPage } from './DemoPage/DemoPage'
import { DemoSideBar } from './DemoSideBar/DemoSideBar'
import { DemoSection } from './DemoSection/DemoSection'
import { ExampleViewType } from './DemoMisc/ExampleViewType'
import { SwitchTheme } from './SwitchTheme/SwitchTheme'
import { LabelValueListViewType } from './DemoMisc/LabelValueListViewType'
import * as _ from 'lodash'

const DemoSideBarRM = require('./DemoSideBar/README.md')
const WelcomeRM = require('./Welcome/README.md')
const ContributingRM = require('./Contributing/README.md')
const ContentRM = require('./Contributing/Content.md')
const IconsRM = require('./Contributing/Icons.md')
const ApiCallsRM = require('./Contributing/APICalls.md')
const SchemaRM = require('./Contributing/Schema.md')
const ConfigurationRM = require('./Contributing/Configuration.md')

const RefreshAppStateSchema = require('./RefreshAppState/RefreshAppState.schema.json')
const DemoColumnViewTypeSchema = require('./DemoMisc/DemoColumnViewType.schema.json')
const DemoInputViewTypeSchema = require('./DemoMisc/DemoInputViewType.schema.json')
const DemoPageSchema = require('./DemoPage/DemoPage.schema.json')
const DemoSideBarSchema = require('./DemoSideBar/DemoSideBar.schema.json')
const DemoSectionSchema = require('./DemoSection/DemoSection.schema.json')
const ExampleViewTypeSchema = require('./DemoMisc/ExampleViewType.schema.json')
const DemoLabelValueListViewTypeSchema = require('./DemoMisc/LabelValueListViewType.schema.json')
const ContentRepeaterSchema = require('./ContentRepeater/ContentRepeater.schema.json')
const SwitchThemeSchema = require('./SwitchTheme/SwitchTheme.schema.json')

export const viewTypes: ViewTypeLookup = {
    ...CoreViewTypes,
    RefreshAppState: RefreshAppState,
    DemoColumn: DemoColumnViewType,
    DemoInput: DemoInputViewType,
    DemoPage: DemoPage,
    DemoSideBar: DemoSideBar,
    DemoSection: DemoSection,
    ExampleViewType: ExampleViewType,
    DemoLabelValueList: LabelValueListViewType,
    ContentRepeater: ContentRepeater,
    SwitchTheme: SwitchTheme
}

export const ReadmeLookup = {
    ...CoreReadme,
    DemoSideBar: DemoSideBarRM,
    Welcome: WelcomeRM,
    Contributing: ContributingRM,
    Content: ContentRM,
    Icons: IconsRM,
    ApiCalls: ApiCallsRM,
    Configuration: ConfigurationRM,
    Schema: SchemaRM
}

export const viewTypesSchemas: ViewTypeSchemaLookup = {
    ...CoreViewTypesSchemas,
    RefreshAppState: RefreshAppStateSchema,
    DemoColumn: DemoColumnViewTypeSchema,
    ContentRepeater: ContentRepeaterSchema,
    DemoInput: DemoInputViewTypeSchema,
    DemoPage: DemoPageSchema,
    DemoSideBar: DemoSideBarSchema,
    DemoSection: DemoSectionSchema,
    ExampleViewType: ExampleViewTypeSchema,
    DemoLabelValueList: DemoLabelValueListViewTypeSchema,
    SwitchTheme: SwitchThemeSchema
}

let localCommonSchemas: Array<any> = [
    // local common Schemas
]

export const commonSchemas: Array<any> = _.concat(localCommonSchemas, CoreCommonSchemas)
