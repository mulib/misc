import * as React from 'react'
import axios from 'axios'
import { ViewTypeProps, BaseDataSource, } from '@optima/core-ui-libs/widgetFramework'
import { BaseApplicationConfiguration } from '@optima/core-ui-libs'
export interface RefreshAppStateViewConfiguration {

}
export interface RefreshAppStateDataSource extends BaseDataSource {
}

export interface RefreshAppStateEventHandlers {
    onClick?: (config: Config) => void
}

interface Config extends BaseApplicationConfiguration {
}
const handleClick = (onClick: any) => {
    let _config
    axios.get(window.location.protocol + '//' + window.location.host + '/config')
        .then((config) => {
            _config = config.data
            onClick(_config)
        }).catch((reason) => { console.info(reason) })
}
export function RefreshAppState(props: ViewTypeProps<RefreshAppStateViewConfiguration, RefreshAppStateDataSource, RefreshAppStateEventHandlers>) {
    const { id, dataSource, viewConfiguration, onClick } = props
    let _config

    return (
        <div className='contentPadding'>
            {onClick && <button onClick={() => { handleClick(onClick) }}>Refresh config</button>}
        </div>

    )
}