import * as React from 'react'
import { expect } from 'chai'
import { LabelValueListViewConfiguration, LabelValueListViewType, ILabelValueListDataSource } from './LabelValueListViewType'
import { ShallowWrapper, shallow } from 'enzyme'
import { ViewTypeProps } from '@optima/core-ui-libs/widgetFramework'

describe('viewTypes', () => {
    let _wrapper: ShallowWrapper<ViewTypeProps<LabelValueListViewConfiguration, {}, {}>, any>

    const viewConfigurationDynamic: LabelValueListViewConfiguration = {
        template: {
            iterator: 'labelValues',
            data: 'accounts',
            keyName: 'name'
        }
    }
    context('LabelValueListStatic', () => {
        const viewConfigurationStatic: LabelValueListViewConfiguration = {
            list: [
                {
                    label: {
                        type: 'message',
                        messageId: 'ConfigurableUI.DemoPage.Example.Hello'
                    },
                    value: 'Widget Instance'
                },
                {
                    label: 'View Type',
                    value: 'LabelValueList'
                }
            ]
        }

        before(() => {
            _wrapper = shallow(<LabelValueListViewType id='labelValueList.view.type' viewConfiguration={viewConfigurationStatic} />)
        })

        it('should contain a class labelValueList', () => {
            expect(_wrapper.find('.labelValueList').length).to.equal(1, '_wrapper.find(.labelValueList)')
        })

    }),
        context('LabelValueListDynamicSimpleObject', () => {
            const dataSourceConfiguration: ILabelValueListDataSource = {
                accounts:
                {
                    name: 'Amdocs',
                    type: 'Corporate',
                    number: '11111',
                    city: 'Raanana'
                },
                labelValues: [
                    'name',
                    {
                        name: 'type',
                        label: {
                            type: 'message',
                            messageId: 'ConfigurableUI.MasterDetails.MasterDetails.LabelValue.accountType'
                        }
                    },
                    'number',
                    'city'
                ]
            }

            before(() => {
                _wrapper = shallow(<LabelValueListViewType id='labelValueList.view.type' viewConfiguration={viewConfigurationDynamic} dataSource={dataSourceConfiguration} />)
            })

            it('should contain an accounts as an object', () => {
                expect(_wrapper.instance().props.dataSource).has.property('accounts')
            })
        }),
        context('LabelValueListDynamicListSimple', () => {
            const dataSourceConfiguration: ILabelValueListDataSource = {
                accounts:
                {
                    name: 'Amdocs',
                    type: 'Corporate',
                    number: '11111',
                    city: 'Raanana'
                },
                labelValues: [
                    'name',
                    {
                        name: 'type',
                        label: {
                            type: 'message',
                            messageId: 'ConfigurableUI.MasterDetails.MasterDetails.LabelValue.accountType'
                        }
                    },
                    'number',
                    'city'
                ],
                selectedKey: 'Amdocs'
            }

            before(() => {
                _wrapper = shallow(<LabelValueListViewType id='labelValueList.view.type' viewConfiguration={viewConfigurationDynamic} dataSource={dataSourceConfiguration} />)
            })

            it('should contain a selectedKey property', () => {
                expect(_wrapper.instance().props.dataSource).has.property('selectedKey')
            })
        }),
        context('LabelValueListDynamicListRecursive', () => {
            const dataSourceConfiguration: ILabelValueListDataSource = {
                accounts: [
                    {
                        name: 'Google',
                        subAccounts: [
                            {
                                name: 'YouTube',
                                type: 'Secondary Account',
                                number: '333.111',
                                city: 'Chicago',
                                inactive: true
                            }
                        ]
                    }
                ],
                labelValues: [
                    'name',
                    'type',
                    'number',
                    'city'
                ],
                selectedKey: 'YouTube'
            }

            before(() => {
                _wrapper = shallow(<LabelValueListViewType id='labelValueList.view.type' viewConfiguration={viewConfigurationDynamic} dataSource={dataSourceConfiguration} />)
            })

            it('should contain an iterator in viewConfiguration', () => {
                expect(_wrapper.instance().props.viewConfiguration!.template!.iterator).to.exist
            })
        }),


        context('LabelValueListEmpty ', () => {
            const viewConfigurationEmpty: LabelValueListViewConfiguration = {
            }

            before(() => {
                _wrapper = shallow(<LabelValueListViewType id='labelValueList.view.type' viewConfiguration={viewConfigurationEmpty} />)
            })

            it('should not render anything', () => {
                expect(_wrapper.find('.labelValueList').children.length).to.equal(1, '_wrapper.find(.labelValueList)')
            })
        })

})
