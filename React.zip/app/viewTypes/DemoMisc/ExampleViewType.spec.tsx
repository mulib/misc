import * as React from 'react'
import { expect } from 'chai'
import { ExampleDataSource, ExampleEventHandlers, ExampleViewConfiguration, ExampleViewType } from './ExampleViewType'
import { ShallowWrapper, shallow } from 'enzyme'
import { ViewTypeProps } from '@optima/core-ui-libs/widgetFramework'
import { OTile } from '@optima/core-ui-libs/ui-components'

describe('viewTypes', () => {
    describe('ExampleViewType', () => {
        let _wrapper: ShallowWrapper<ViewTypeProps<ExampleViewConfiguration, ExampleDataSource, ExampleEventHandlers>, any>
        const viewConfiguration: ExampleViewConfiguration = {
            content: { type: 'message', messageId: 'ConfigurableUI.DemoPage.Example.Hello' }
        }

        before(() => {
            _wrapper = shallow(<ExampleViewType id='example.view.type' viewConfiguration={viewConfiguration} />)
        })
        it('render correctly', () => {
            expect(_wrapper.find('.contentPadding').length).to.equal(1, '_wrapper.find(.contentPadding)')
        })
    })
})
