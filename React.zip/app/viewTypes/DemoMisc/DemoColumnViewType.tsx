import * as React from 'react'

import { ViewTypeProps } from '@optima/core-ui-libs/widgetFramework'
import { Safe } from '@optima/core-ui-libs/utilities/safe'
import { OInlineTile, OTileHeader, OAlert } from '@optima/core-ui-libs/ui-components'

export interface DemoColumnViewConfiguration {
    content: string
    disabled?: boolean
    headerText?: string
    showLoading?: boolean
    height?: string
}

export function DemoColumnViewType(props: ViewTypeProps<DemoColumnViewConfiguration, {}, {}>) {
    const showLoading = Safe.getBoolean(props, props => props!.viewConfiguration!.showLoading as boolean, false, false)
    const viewConfiguration = props!.viewConfiguration as DemoColumnViewConfiguration
    return (<OInlineTile height={props!.viewConfiguration!.height} id={props.id} showLoading={showLoading} disabled={props.disabled}>
        {viewConfiguration.headerText && <OTileHeader title={viewConfiguration.headerText} />}
        <div className='contentPadding'>{viewConfiguration.content}</div>
    </OInlineTile>)
}