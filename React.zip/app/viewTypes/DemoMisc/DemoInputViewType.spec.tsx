import * as React from 'react'
import { expect } from 'chai'
import { DemoInputViewConfiguration, DemoInputViewType } from './DemoInputViewType'
import { ShallowWrapper, shallow } from 'enzyme'
import { ViewTypeProps } from '@optima/core-ui-libs/widgetFramework'
import { OTile } from '@optima/core-ui-libs/ui-components'

describe('viewTypes', () => {
    describe('DemoInput', () => {
        let _wrapper: ShallowWrapper<ViewTypeProps<DemoInputViewConfiguration, {}, {}>, any>
        const viewConfiguration: DemoInputViewConfiguration = {
            label: 'Lorem Ipsum'
        }

        before(() => {
            _wrapper = shallow(<DemoInputViewType id='demo.Input.view.type' viewConfiguration={viewConfiguration} />)
        })
        it('should contain an OTile', () => {
            expect(_wrapper.find(OTile).length).to.equal(1, '_wrapper.find(OTile)')
        })
    })
    describe('DemoInput with header', () => {
        let _wrapper: ShallowWrapper<ViewTypeProps<DemoInputViewConfiguration, {}, {}>, any>
        const viewConfiguration: DemoInputViewConfiguration = {
            label: 'Lorem Ipsum',
            headerText: 'Dolor Sic Amet'
        }

        before(() => {
            _wrapper = shallow(<DemoInputViewType id='demo.Input.view.type' viewConfiguration={viewConfiguration} />)
        })
        it('should contain an OTile', () => {
            expect(_wrapper.find(OTile).length).to.equal(1, '_wrapper.find(OTile)')
        })
    })
})
