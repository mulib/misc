import * as React from 'react'

import { ViewTypeProps } from '@optima/core-ui-libs/widgetFramework'
import { Safe } from '@optima/core-ui-libs/utilities/safe'
import { OTile, OTileHeader, OAlert, OInput } from '@optima/core-ui-libs/ui-components'

export interface DemoInputViewConfiguration {
    disabled?: boolean
    headerText?: string
    label: string
    showLoading?: boolean
    size?: 'large' | 'medium' | 'small'
    type?: 'number' | 'text' | 'email' | 'password'
}

export function DemoInputViewType(props: ViewTypeProps<DemoInputViewConfiguration, {}, {}>) {
    const { id, disabled } = props
    const showLoading = Safe.getBoolean(props, props => props!.viewConfiguration!.showLoading as boolean, false, false)
    const viewConfiguration = props!.viewConfiguration as DemoInputViewConfiguration

    return (
        <OTile id={id} showLoading={showLoading} disabled={props.disabled}>
            {viewConfiguration.headerText && <OTileHeader title={viewConfiguration.headerText} />}
            <div className='contentPadding'>
                <OInput label={viewConfiguration.label} id={`${id}.input`} type={viewConfiguration.type} size={viewConfiguration.size} disabled={disabled} />
            </div>
        </OTile>
    )
}