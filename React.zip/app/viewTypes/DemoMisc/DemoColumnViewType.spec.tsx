import * as React from 'react'
import { expect } from 'chai'
import { DemoColumnViewConfiguration, DemoColumnViewType } from './DemoColumnViewType'
import { ShallowWrapper, shallow } from 'enzyme'
import { ViewTypeProps } from '@optima/core-ui-libs/widgetFramework'
import { OInlineTile } from '@optima/core-ui-libs/ui-components'

describe('viewTypes', () => {

    describe('DemoColumn', () => {
        let _wrapper: ShallowWrapper<ViewTypeProps<DemoColumnViewConfiguration, {}, {}>, any>
        const viewConfiguration: DemoColumnViewConfiguration = {
            content: 'Dolor Sic Amet',
            headerText: 'Lorem Ipsum'
        }

        before(() => {
            _wrapper = shallow(<DemoColumnViewType id='demo.column.view.type' viewConfiguration={viewConfiguration} />)
        })
        it('should contain an OInlineTile', () => {
            expect(_wrapper.find(OInlineTile).length).to.equal(1, '_wrapper.find(OInlineTile)')
        })
    })
})
