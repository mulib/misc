import * as React from 'react'
import * as _ from 'lodash'
const classNames = require('classnames')

import { ViewTypeProps, BaseDataSource } from '@optima/core-ui-libs/widgetFramework'
import { OContent, ContentParams, MessageFormatterParams } from '@optima/core-ui-libs/ui-components'

interface LabelObj {
    name: string,
    label: MessageFormatterParams
}

interface LabelValue {
    label: ContentParams | string,
    value: string
}

interface Template {
    iterator?: string,
    data?: string,
    keyName?: string
}

export interface LabelValueListViewConfiguration {
    list?: Array<LabelValue>
    template?: Template
}

export interface Iterable {
    [iterable: string]: any
}

export interface DataAttribute {
    [dataAttribute: string]: any
}

export type ILabelValueListDataSource = (DataAttribute | Iterable) & BaseDataSource

export function LabelValueListViewType(props: ViewTypeProps<LabelValueListViewConfiguration, ILabelValueListDataSource, {}>) {
    const { id, dataSource, viewConfiguration } = props
    let currentObj: any

    const getCurrentObjectRecursive = (arr: Array<any>): any => {
        for (let index = 0; index < arr.length; index++) {
            const element = arr[index]
            // if (!element)
            //     return

            if (element[viewConfiguration!.template!.keyName!] === dataSource!.selectedKey)
                return element

            for (let idx = 0; idx < Object.keys(element).length; idx++) {
                let key = Object.keys(element)[idx]
                if (_.isArray(element[key])) {
                    let obj = getCurrentObjectRecursive(element[key])
                    if (obj) return obj
                }
            }
        }
    }

    if (viewConfiguration!.template && viewConfiguration!.template!.iterator && _.isArray(dataSource![viewConfiguration!.template!.iterator!])) {
        if (_.isArray(dataSource![viewConfiguration!.template!.data!])) {
            currentObj = getCurrentObjectRecursive(dataSource![viewConfiguration!.template!.data!])
        }
        else
            currentObj = dataSource![viewConfiguration!.template!.data!]
    }
    return (
        <div className={classNames('contentPadding', 'labelValueList')}>
            {_.isArray(viewConfiguration!.list) ?
                viewConfiguration!.list!.map((item: LabelValue, index: number) => {
                    let label = typeof (item.label) === 'string' ? item.label :
                        <OContent key={`labelValue.content.${index}`} contentParams={item.label as ContentParams} dataSource={dataSource} id={`${id}.label`} />
                    return <div key={`labelValue.div.${index}`} className='margin-bottom-20'>
                        <span key={`labelValue.span.${index}`} className='font-b1'>{label}</span>: {item.value}
                    </div>
                }) : viewConfiguration!.template && viewConfiguration!.template!.iterator && _.isArray(dataSource![viewConfiguration!.template!.iterator!]) ?
                    dataSource![viewConfiguration!.template!.iterator!].map((property: string & LabelObj, index: number) => {
                        let label = typeof (property) === 'string' ? _.startCase(property) :
                            <OContent key={`labelValue.content.${index}`} contentParams={property.label} dataSource={dataSource} id={`${id}.label`} />
                        let propertyName = typeof (property) === 'string' ? property : property.name
                        return <div key={`labelValue.div.${index}`} className='margin-bottom-20'>
                            <span key={`labelValue.span.${index}`} className='font-b1'>{label}</span>: {currentObj[propertyName]}
                        </div>
                    }) : []
            }
        </div>

    )
}