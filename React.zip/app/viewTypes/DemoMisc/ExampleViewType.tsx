import * as React from 'react'

import { ViewTypeProps, BaseDataSource } from '@optima/core-ui-libs/widgetFramework'
import { OContent, ContentParams } from '@optima/core-ui-libs/ui-components'
import { OTile } from '@optima/core-ui-libs/ui-components'

export interface ExampleViewConfiguration {
    content?: ContentParams
    args?: any
}
export interface ExampleEventHandlers {
    onEvent?: (identifier: string) => void
}
interface User { identifier?: string, firstName?: string, lastName?: string }
export interface ExampleDataSource extends BaseDataSource {
    user?: User,
    balance?: number,
    birthDate?: string
}
const handleClick = (args: any, onEvent: any) => (event: any) => {
    onEvent(args)
}
export function ExampleViewType(props: ViewTypeProps<ExampleViewConfiguration, ExampleDataSource, ExampleEventHandlers>) {
    const { id, dataSource, viewConfiguration, onEvent } = props
    return (
        <div className='contentPadding'>
            {viewConfiguration && viewConfiguration.content && <OContent contentParams={viewConfiguration.content} dataSource={dataSource} id={`${id}.content`} />}
            {onEvent && <button onClick={() => { handleClick(viewConfiguration && viewConfiguration.args, onEvent) }} />}
        </div>

    )
}