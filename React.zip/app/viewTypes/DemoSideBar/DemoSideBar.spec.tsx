import * as React from 'react'
import { DemoSideBarViewConfiguration, DemoSideBarDataSource, DemoSideBarEventHandlers, DemoSideBar } from './DemoSideBar'
import { ShallowWrapper, shallow } from 'enzyme'
import { Nav, NavItem } from 'react-bootstrap'
import { ViewTypeProps } from '@optima/core-ui-libs/widgetFramework'
import { OContent } from '@optima/core-ui-libs/ui-components'
import * as sinon from 'sinon'

describe('viewTypes', () => {
    describe('DemoSideBar', () => {
        let _wrapper: ShallowWrapper<ViewTypeProps<DemoSideBarViewConfiguration, {}, {}>, any>
        const viewConfiguration: DemoSideBarViewConfiguration = {
            'defaultDemoSection': { 'type': 'widgetInstance', 'widgetInstanceId': 'ConfigurableUI_DemoPage_WelcomeDemoSection' },
            'navItems': [{
                'title': { 'type': 'message', 'messageId': 'ConfigurableUI.DemoPage.SideBar.Welcome' },
                'demoSection': 'ConfigurableUI_DemoPage_WelcomeDemoSection'
            },
            {
                'title': { 'type': 'message', 'messageId': 'ConfigurableUI.DemoPage.SideBar.OButton' },
                'demoSection': 'ConfigurableUI_DemoPage_OButtonDemoSection'
            }
            ]
        }
        const viewConfigurationNoDefault: DemoSideBarViewConfiguration = {
            'navItems': [{
                'title': { 'type': 'message', 'messageId': 'ConfigurableUI.DemoPage.SideBar.B' },
                'demoSection': 'ConfigurableUI_DemoPage_B'
            },
            {
                'title': { 'type': 'message', 'messageId': 'ConfigurableUI.DemoPage.SideBar.A' },
                'demoSection': 'ConfigurableUI_DemoPage_A'
            }
            ]
        }
        const dataSource: DemoSideBarDataSource = {
        }
        before(() => {
            _wrapper = shallow(<DemoSideBar id='test.demo.sidebar' viewConfiguration={viewConfiguration} dataSource={dataSource} />)
        })
        it('render Nav', () => {
            expect(_wrapper.find(Nav).length).to.equal(1)
        })
        it('render 2 NavItems', () => {
            let _nav = _wrapper.find(Nav)
            let _navItems = _nav.find(NavItem)
        })
        it('render with no default navItem', () => {
            let __wrapper = shallow(<DemoSideBar id='test.demo.sidebar' viewConfiguration={viewConfigurationNoDefault} dataSource={dataSource} />)
            let __nav = __wrapper.find(Nav)
            // expect(__nav.childAt(0).prop('eventKey')).to.equal('ConfigurableUI_DemoPage_SideBar_A')
            // expect(__nav.childAt(1).prop('eventKey')).to.equal('ConfigurableUI_DemoPage_SideBar_B')
        })
    })
})
