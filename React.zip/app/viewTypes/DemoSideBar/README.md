# view type example
```jsx
<hello>world</hello>
```