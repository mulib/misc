import * as React from 'react'

import { ViewTypeProps, BaseDataSource } from '@optima/core-ui-libs/widgetFramework'
import { OContent, MessageFormatterParams, WidgetInstanceParams } from '@optima/core-ui-libs/ui-components'
import { Nav, NavItem } from 'react-bootstrap'
require('./DemoSideBar.scss')
import * as _ from 'lodash'

export interface ViewTypNavItem {
    title: MessageFormatterParams,
    demoSection: string
}
export interface DemoSideBarViewConfiguration {
    defaultDemoSection?: WidgetInstanceParams,
    navItems: ViewTypNavItem[]
}
export interface DemoSideBarDataSource extends BaseDataSource {

}
export interface DemoSideBarEventHandlers {
    onSelect: () => void
}
export interface DemoSideBarProps extends ViewTypeProps<DemoSideBarViewConfiguration, DemoSideBarDataSource, any> {

}
export interface DemoSideBarState {

}
export class DemoSideBar extends React.Component<DemoSideBarProps, DemoSideBarState> {
    constructor(props: DemoSideBarProps) {
        super(props)
    }
    private _navItems: ViewTypNavItem[]
    private _defaultNavItem: ViewTypNavItem
    componentWillMount() {
        let { viewConfiguration } = this.props
        let { navItems } = viewConfiguration
        this._navItems = _.sortBy(navItems, [(navItem: ViewTypNavItem) => { return navItem.title.messageId }])
    }
    renderNavItem = (navItem: ViewTypNavItem, index: number) => {
        let { demoSection, title } = navItem
        return (

            <NavItem key={index} eventKey={demoSection} href={`#${title.messageId}`}>
                <OContent id={`${this.props.id}.NavItem.${index}`} contentParams={title} />
            </NavItem>
        )
    }
    render() {
        let { viewConfiguration, id, onSelect } = this.props
        let { defaultDemoSection, navItems } = viewConfiguration
        let _defaultNavItem: ViewTypNavItem | undefined
        if (defaultDemoSection) {
            _defaultNavItem = _.find(this._navItems, (navItem: ViewTypNavItem) => { return navItem.demoSection === defaultDemoSection.widgetInstanceId })
            if (_defaultNavItem) {
                this._defaultNavItem = _defaultNavItem
                _.remove(this._navItems, (navItem: ViewTypNavItem) => {
                    return navItem.demoSection === defaultDemoSection.widgetInstanceId
                })
            }
        }

        return (
            <Nav stacked className='demoSideBar' id={id} activeKey={defaultDemoSection ? defaultDemoSection.widgetInstanceId : this._navItems[0].demoSection} onSelect={onSelect}>
                {this._defaultNavItem && <NavItem eventKey={this._defaultNavItem.demoSection} href={`#`}>
                    <OContent id={`${this.props.id}.NavItem.${`default`}`} contentParams={this._defaultNavItem.title} />
                </NavItem>}
                {this._navItems.map(this.renderNavItem)}
            </Nav>
        )
    }
}
export default DemoSideBar