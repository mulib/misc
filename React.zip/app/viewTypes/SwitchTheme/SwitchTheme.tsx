import * as React from 'react'

import { ViewTypeProps } from '@optima/core-ui-libs/widgetFramework'
import { OButton } from '@optima/core-ui-libs/ui-components'

export interface SwitchThemeViewConfiguration {
    theme: string
    label: string
}

const handleClick = (theme: string) => (event: any) => {
    let _body = document.getElementsByTagName('BODY')[0]
    _body.removeAttribute('class')
    _body.classList.add(theme)
}
export function SwitchTheme(props: ViewTypeProps<SwitchThemeViewConfiguration, {}, {}>) {
    const { id, viewConfiguration } = props

    return (
        <div className='contentPadding'>
            <OButton secondary id={id} onClick={handleClick(viewConfiguration!.theme)} label={viewConfiguration!.label} />
        </div>
    )
}
export default SwitchTheme