import * as React from 'react'
import { expect } from 'chai'
import { SwitchThemeViewConfiguration, SwitchTheme } from './SwitchTheme'
import { ShallowWrapper, shallow } from 'enzyme'
import { ViewTypeProps } from '@optima/core-ui-libs/widgetFramework'

describe('viewTypes', () => {
    describe('SwitchTheme', () => {
        let _wrapper: ShallowWrapper<ViewTypeProps<SwitchThemeViewConfiguration, {}, {}>, any>
        const viewConfiguration: SwitchThemeViewConfiguration = { label: 'CSR', theme: 'CSR' }

        before(() => {
            _wrapper = shallow(<SwitchTheme id='example.view.type' viewConfiguration={viewConfiguration} />)
        })
        it('render correctly', () => {
            expect(_wrapper.find('.contentPadding').length).to.equal(1, '_wrapper.find(.contentPadding)')
        })
    })
})
