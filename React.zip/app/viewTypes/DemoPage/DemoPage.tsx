import * as React from 'react'
import * as _ from 'lodash'

import { ViewTypeProps, OLayout, BaseDataSource, OWidgetInstance } from '@optima/core-ui-libs/widgetFramework'
import { OLayoutViewConfiguration } from '@optima/core-ui-libs/interfaces'

export interface DynamicContent { row: number, col: number }

export interface DemoPageViewConfiguration {
    layoutConfiguration: OLayoutViewConfiguration,
    dynamicContent: DynamicContent
}

export interface DemoPageDataSource extends BaseDataSource {
    activeDemoSection?: string
}

export interface DemoPageEventHandlers {
}

export interface DemoPageProps extends ViewTypeProps<DemoPageViewConfiguration, DemoPageDataSource, any> {
}

export interface DemoPageState {
}

export class DemoPage extends React.Component<DemoPageProps, DemoPageState> {
    constructor(props: DemoPageProps) {
        super(props)
    }
    setActiveDemoSection = (activeDemoSection: string, layoutConfiguration: OLayoutViewConfiguration, dynamicContent: DynamicContent): OLayoutViewConfiguration => {
        let _viewConfiguration: OLayoutViewConfiguration
        _viewConfiguration = Object.assign({}, layoutConfiguration)
        _.set(_viewConfiguration, `rows.${dynamicContent.row}.cols.${dynamicContent.col}.content.widgetInstanceId`, activeDemoSection)
        return _viewConfiguration

    }

    render() {
        let { viewConfiguration, dataSource, id } = this.props
        let { activeDemoSection } = dataSource
        let { layoutConfiguration, dynamicContent } = viewConfiguration
        let _viewConfiguration: OLayoutViewConfiguration = activeDemoSection ? this.setActiveDemoSection(activeDemoSection, layoutConfiguration, dynamicContent) : layoutConfiguration

        return (
            <div className='DemoPage'>
                <div className='switchThemeWrapper'>
                    <OWidgetInstance instanceId='ConfigurableUI_DemoPage_SwitchTheme_CSR' />
                    <OWidgetInstance instanceId='ConfigurableUI_DemoPage_SwitchTheme_SelfCare' />
                </div>
                <OLayout viewConfiguration={_viewConfiguration} id={id} />
            </div>
        )
    }
}

export default DemoPage
