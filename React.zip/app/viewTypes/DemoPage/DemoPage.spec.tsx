import * as React from 'react'
import { DemoPageViewConfiguration, DemoPageDataSource, DemoPage, DemoPageProps } from './DemoPage'
import { mountWithMockStore } from '../../common/testUtils.spec'
import { ShallowWrapper, shallow } from 'enzyme'
import { ViewTypeProps } from '@optima/core-ui-libs/widgetFramework'

describe('viewTypes', () => {
    describe('DemoPage', () => {
        const appState = {
            widget: {
                DemoPage: { activeDemoSection: 'xxx' }
            }
        }
        let _wrapper: ShallowWrapper<DemoPageProps, {}>
        const viewConfiguration: DemoPageViewConfiguration = {
            'layoutConfiguration': {
                'rows': [{
                    'cols': [{
                        'md': 2,
                        'content': {
                            'type': 'widgetInstance',
                            'widgetInstanceId': 'ConfigurableUI_DemoPage_DemoSideBar'
                        }
                    },
                    {
                        'md': 10,
                        'content': {
                            'type': 'widgetInstance',
                            'widgetInstanceId': 'ConfigurableUI_DemoPage_OButtonDemoSection'
                        }
                    }
                    ]
                }]
            },
            'dynamicContent': { 'row': 0, 'col': 1 }
        }
        const dataSource: DemoPageDataSource = {
            'activeDemoSection': 'ConfigurableUI_DemoPage_DemoSideBar'
        }

        before(() => {
            _wrapper = shallow(<DemoPage id='test.demo.page' viewConfiguration={viewConfiguration} dataSource={dataSource} />)
        })
        it('render correctly:', () => {
            let _mainDiv = _wrapper.find('.DemoPage')
        })
    })
})
