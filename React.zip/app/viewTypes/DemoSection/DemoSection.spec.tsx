import * as React from 'react'
import { DemoSectionViewConfiguration, DemoSection } from './DemoSection'
import { ShallowWrapper, shallow, mount, ReactWrapper } from 'enzyme'
import { ViewTypeProps } from '@optima/core-ui-libs/widgetFramework'
import { OMarkDown } from '@optima/core-ui-libs/ui-components'
describe('viewTypes', () => {
    describe('DemoSection', () => {
        let _wrapper: ShallowWrapper<ViewTypeProps<DemoSectionViewConfiguration, {}, {}>, any>
        let __wrapper: ReactWrapper<ViewTypeProps<DemoSectionViewConfiguration, any, any>, any>
        const viewConfiguration: DemoSectionViewConfiguration = {
            'viewTypeName': { 'type': 'message', 'messageId': 'ConfigurableUI.DemoPage.OButtonDemoSection.name' },
            'longDescription': { 'type': 'message', 'messageId': 'ConfigurableUI.DemoPage.OButtonDemoSection.longDescription' },
            'liveExamples': [{
                'title': { 'type': 'message', 'messageId': 'ConfigurableUI.DemoPage.OButtonDemoSection.liveExamples.title' },
                'description': { 'type': 'message', 'messageId': 'ConfigurableUI.DemoPage.OButtonDemoSection.liveExamples.description' },
                'content': { 'type': 'widgetInstance', 'widgetInstanceId': 'ConfigurableUI_Button_Primary' }
            }],
            'readme': 'OButton'
        }


        before(() => {
            _wrapper = shallow(<DemoSection id='test.demo.section' viewConfiguration={viewConfiguration} />)
        })
        it('render correctly', () => {
            let _mainDiv = _wrapper.find('div.demoSection')
            expect(_mainDiv.length).to.equal(1)
            let _description = _mainDiv.find('section.descriptionSection')
            expect(_description.length).to.equal(1)
            let _liveExample = _mainDiv.find('section.liveExampleSection')
            expect(_liveExample.length).to.equal(1)
            let _readme = _mainDiv.find('section.README')
            expect(_readme.length).to.equal(1)
        })
        it('render markdown', () => {
            let _mainDiv = _wrapper.find('div.demoSection')
            let _markDown = _mainDiv.find(OMarkDown)
            expect(_markDown.length).to.equal(1)
            let _content = _markDown.prop('content')
            expect(_content).to.contain('Interface')
        })
    })
})
