import * as React from 'react'
import { injectIntl } from 'react-intl'
import { ViewTypeProps } from '@optima/core-ui-libs/widgetFramework'
import { OMarkDown, OContent, MessageFormatterParams, WidgetInstanceParams } from '@optima/core-ui-libs/ui-components'
require('./DemoSection.scss')

export type DemoSectionProps = ViewTypeProps<DemoSectionViewConfiguration, any, any>

export interface DemoSectionState {
    readme: string
}

interface LiveExample {
    title: MessageFormatterParams,
    description: MessageFormatterParams,
    content: WidgetInstanceParams
}

export interface DemoSectionViewConfiguration {
    viewTypeName?: MessageFormatterParams,
    longDescription?: MessageFormatterParams,
    liveExamples?: LiveExample[],
    readme: string
}
export class DemoSection extends React.Component<DemoSectionProps, DemoSectionState> {
    constructor(props: DemoSectionProps) {
        super(props)
        let _name = props.viewConfiguration.readme
        let _readme = this.getReadme(_name)
        this.state = { readme: _readme }
    }
    renderLiveExample = (liveExample: LiveExample, index: number) => {
        let { id } = this.props
        let { title, description, content } = liveExample
        return (
            <section className='liveExampleSection' key={index}>
                {title && <h2 className='liveExampleTitle'>
                    <OContent id={`${id}.liveExampleTitle.${index}`} contentParams={title} />
                </h2>}
                {description && <p className='liveExampleDescription'>
                    <OContent id={`${id}.longDescription.${index}`} contentParams={description} />
                </p>}
                {content && <div className='liveExampleContent'>
                    <OContent id={`${id}.longDescription.${index}`} contentParams={content} />
                </div>}
            </section>
        )
    }
    // componentDidMount() {
    //     let _readme: string = this.props.viewConfiguration.readme || ''
    //     let _name = this.props.viewConfiguration.readme
    //     const _readMeLookup = require('../').ReadmeLookup
    //     try {
    //         _readme = _readMeLookup[_name]
    //     } catch (error) {
    //         console.info(`cannot display README file for ${_name}. please make sure README.md file is part of ReadMeLookup`)
    //     }
    //     this.setState({ readme: _readme })
    // }
    getReadme(name: string) {
        const _readMeLookup = require('../').ReadmeLookup
        let _readme: string = ''
        try {
            _readme = _readMeLookup[name]
        } catch (error) {
            console.info(`cannot display README file for ${name}. please make sure README.md file is part of ReadMeLookup`)
        }
        return _readme
    }
    componentWillReceiveProps(nextProps: DemoSectionProps) {

        let _readme: string
        if (this.props.viewConfiguration.readme !== nextProps.viewConfiguration.readme) {
            let _name = nextProps.viewConfiguration.readme
            _readme = this.getReadme(_name)
            this.setState({ readme: _readme })
        }
    }
    render() {
        let { viewConfiguration, id } = this.props
        let { viewTypeName, longDescription, readme, liveExamples } = viewConfiguration
        const markDown = this.state && this.state.readme

        return (
            <div id={id} className='demoSection'>
                <section className='descriptionSection'>
                    {viewTypeName && <h1 className='viewTypeName'>
                        <OContent id={`${id}.viewTypeName`} contentParams={viewTypeName} />
                    </h1>}
                    {longDescription && <p className='longDescription'>
                        <OContent id={`${id}.longDescription`} contentParams={longDescription} />
                    </p>}
                </section>
                {liveExamples && liveExamples.map(this.renderLiveExample)}
                {readme && <section className='README'>
                    {markDown && <section className='READMEMarkDown'>
                        <OMarkDown content={markDown} />
                    </section>}
                </section>}
            </div>
        )
    }
}
export default injectIntl(DemoSection)