import groovy.json.JsonSlurperClassic
import groovy.util.XmlSlurper

def build(def buildType="DEV")
{
    // *** change here BEGIN *** //TODO: check if these should be passed from jenkins job rather than be hardcoded
    def nexusURL = 'http://nexus-optima:8081'
    def nexusRepository = 'snapshots'
    def nexusGroupID = 'com.amd.optima.csr.dist.ui-core' //should actually be com.amd.optima.ui
    def projectName = 'frontend-core'


  // *** change here END ***

    //define variables
    def versionOnly=env."ResolvedIn".split('_')[1]
    def printPre =versionOnly[0..8]
    uiVersion = printPre + currentBuild."number"

    //def buildVersion = version()
    def buildVersion = uiVersion
    def buildTimestamp = timestamp()
    def nexusGroupIDPath = nexusGroupID.replaceAll('\\.','/')
    def artifactName = projectName + '-' + buildVersion + '-' + buildTimestamp
    def archiveName = artifactName + '.zip'

    def nexusUploadPath = nexusURL + '/nexus/content/repositories/' + nexusRepository + '/' + nexusGroupIDPath
    def nexusArtifactURL = nexusURL + '/nexus/service/local/repositories/' + nexusRepository + '/content/' + nexusGroupIDPath + '/' + archiveName
    def errorMSG = ""
    def stageMap = [:]
    def stageStartTime = null

    def stageMaps = []

    try
    {


	if (buildType in ["NIGHTLY"])
 {
        // *** CheckMarx  ***
        //fetch all the dependencies
        stageMap = [name:"CheckMarx",status:0,duration:0]
        stageMaps.add(stageMap)
        stage (stageMap.name)
        {
            stageStartTime = System.currentTimeMillis()
            echo "In stage " + stageMap.name
            stageMap.status = 1

           // step([$class: 'CxScanBuilder', comment: '', excludeFolders: '', excludeOpenSourceFolders: '', filterPattern: '', fullScanCycle: 10, groupId: '0b85d13f-5bb7-4894-92a0-514f6ccc82c3', includeOpenSourceFolders: '', password: '{AQAAABAAAAAQJRCaaIkCQ4dQXY8YdqA69Nvn+y/pZG22kpQCMIvyBhc=}', preset: '36', projectName: 'UI-Core', serverUrl: 'http://cxmanager', sourceEncoding: '1', username: 'NTNET\\nbubuilder3', vulnerabilityThresholdResult: 'FAILURE'])

            stageMap.status = 2
            stageMap.duration = (System.currentTimeMillis()-stageStartTime) //duration in milliseconds
	}
 }


        // *** INSTALL ***
        //fetch all the dependencies
        stageMap = [name:"Install",status:0,duration:0]
        stageMaps.add(stageMap)
        stage (stageMap.name)
        {
            stageStartTime = System.currentTimeMillis()
            echo "In stage " + stageMap.name
            stageMap.status = 1

            npm 'install --unsafe-perm'

            stageMap.status = 2
            stageMap.duration = (System.currentTimeMillis()-stageStartTime) //duration in milliseconds
        }

        // *** INSPECTION ***
        //run ts lint and publish the results
        stageMap = [name:"Code Inspection",status:0,duration:0]
        stageMaps.add(stageMap)
        stage (stageMap.name)
        {
            stageStartTime = System.currentTimeMillis()
            echo "In stage " + stageMap.name
            stageMap.status = 1

            gulp 'lint'
            step([$class: "CheckStylePublisher",
                  canComputeNew: false,
                  defaultEncoding: "",
                  healthy: "",
                  pattern: "build_reports/checkstyle.xml",
                  unHealthy: ""])

            stageMap.status = 2
            stageMap.duration = (System.currentTimeMillis()-stageStartTime) //duration in milliseconds
        }

        // *** TESTS ***
        //run tests with karma and publish the results
        stageMap = [name:"Tests",status:0,duration:0]
        stageMaps.add(stageMap)
        stage (stageMap.name)
        {
            stageStartTime = System.currentTimeMillis()
            echo "In stage " + stageMap.name
            stageMap.status = 1

            gulp 'test'
            step([$class: 'JUnitResultArchiver',
                 testResults: 'build_reports/test-results/**/test-results.xml'])
            publishHTML([allowMissing: false,
                 alwaysLinkToLastBuild: true,
                 keepAll: true,
                 reportDir: 'build_reports',
                 reportFiles: 'coverage/PhantomJS 2.1.1 (Linux 0.0.0)/html/index.html',
                 reportName: 'Coverage'])

            stageMap.status = 2
            stageMap.duration = (System.currentTimeMillis()-stageStartTime) //duration in milliseconds
        }

        // *** DIST ***
        //compile the TypeScript files and copy to dist
        stageMap = [name:"Dist",status:0,duration:0]
        stageMaps.add(stageMap)
        stage(stageMap.name)
        {
            stageStartTime = System.currentTimeMillis()
            echo "In stage " + stageMap.name
            stageMap.status = 1

            def buildWorkspaceDist = '/home' + env."WORKSPACE" + '/dist/'
            gulp 'dist'
            zip archive: true, dir: 'dist', glob: '', zipFile: archiveName

            stageMap.status = 2
            stageMap.duration = (System.currentTimeMillis()-stageStartTime) //duration in milliseconds
        }

        if (buildType in ["NIGHTLY"])
        {
            // *** SONARQUBE ***
            stageMap = [name:"SonarQube Analysis",status:0,duration:0]
            stageMaps.add(stageMap)
            stage(stageMap.name)
            {
                stageStartTime = System.currentTimeMillis()
                echo "In stage " + stageMap.name
                stageMap.status = 1

                // Manual execution of our advanced tslint
                sh './node_modules/.bin/tslint --force -c tslint.sonar.json --project app --format json --out build_reports/tslint-sonar-issues.json'

                // requires SonarQube Scanner 2.8+
                def scannerHome = tool 'SonarQube Scanner 2.8';
                withSonarQubeEnv('SonarQube-Optima')
                {
                    def sonarCmd = "${scannerHome}/bin/sonar-scanner -X -D sonar.projectVersion=" + buildVersion
                    sh sonarCmd
                }

                stageMap.status = 2
                stageMap.duration = (System.currentTimeMillis()-stageStartTime) //duration in milliseconds
            }

            // *** NEXUS ***
            //upload the artifacts to nexus
            stageMap = [name:"Upload to Nexus",status:0,duration:0]
            stageMaps.add(stageMap)
            stage(stageMap.name)
            {
                stageStartTime = System.currentTimeMillis()
                echo "In stage " + stageMap.name
                stageMap.status = 1

                // gulp 'publish'

                stageMap.status = 2
                stageMap.duration = (System.currentTimeMillis()-stageStartTime) //duration in milliseconds
            }




            // *** UPDATE TFS ***
            //update TFS
            stageMap = [name:"Update TFS",status:0,duration:0]
            stageMaps.add(stageMap)
            stage(stageMap.name)
            {
                stageStartTime = System.currentTimeMillis()
                echo "In stage " + stageMap.name
                stageMap.status = 1
		def xmlText = readFile('invokerbuildlog.xml')
                def buildXml = new XmlSlurper().parseText(xmlText)
                xmlText = null

                //get WIs
                def wiList = parseChangelogXML(buildXml.changeSet, 5)
                buildXml = null // to avoid java.io.NotSerializableException: groovy.util.slurpersupport.NodeChild

                if (wiList != [])
                {
                    def tfsScript = load('jenkins/TFS.groovy')
                    // Upate Fields 1 by 1

                    tfsScript.tfsUpdateWIResolvedIn(wiList,env."tfsResolvedIn")
                    tfsScript.tfsUpdateHistory(wiList,env."tfsResolvedIn")
                }

                stageMap.status = 2
                stageMap.duration = (System.currentTimeMillis()-stageStartTime) //duration in milliseconds
            }


			// *** Label in Perforce ***
			// Label the code in perforce if build is successful
			stageMap = [name:"LabelP4Files",status:0,duration:0]
			stageMaps.add(stageMap)
			stage (stageMap.name)
			{

				stageStartTime = System.currentTimeMillis()
				echo "In stage " + stageMap.name
				stageMap.status = 1

				def buildStatus = currentBuild.getResult()
				if (buildStatus == "SUCCESS" || buildStatus==null)
				{
					p4tag rawLabelDesc: 'Jenkins post-build label.', rawLabelName: "TAG-${BUILD_TAG}"
				}

				stageMap.status = 2
				stageMap.duration = (System.currentTimeMillis()-stageStartTime) //duration in milliseconds

			}

        }
    }
    catch (Exception e)
    {
        echo "In Catch"
        errorMSG = e.toString()
        currentBuild.result="FAILURE"
        //throw e
    }
    finally
    {
        echo "In Finally"
        //sends the appripriate email notification
        notify(buildType,
               stageMaps,
               nexusArtifactURL,
               archiveName,
               errorMSG)
    }
}

def notify(def buildType,
           def vresultmap,
           def artifacturl,
           def artifactname,
           def errmsg)
{
    echo "In notify"

    def strtmp = ""
    def list = []
    def recipientList = ""
    def tmpStageMap =[:]

    //*** TITLE ***
    def titleStyle = 'style="font-size:150%;'
    def buildStatus = currentBuild.getResult()
    if (buildStatus == "SUCCESS" || buildStatus==null)
    {
        buildStatus = "SUCCESS"
        titleStyle += 'color:white; background-color:green;"'
    }
    else if (buildStatus=="UNSTABLE") //usually when tests fail
        titleStyle += 'color:black; background-color:yellow;"'
    else
        titleStyle += 'color:white; background-color:red;"'

    def mailTitle = "<b ${titleStyle}>Build '${env.JOB_NAME} ${env.BUILD_NUMBER}': ${buildStatus}</b>"

    // *** BUILD TRIGGER ***
    // load the invokerbuildlog.xml
    def xmlText = readFile('invokerbuildlog.xml')
    def buildXml = new XmlSlurper().parseText(xmlText)

    def mailTrigger = "Build Trigger: " + buildXml.action.cause.shortDescription
    if (buildXml.action.cause.shortDescription == "Started by an SCM change")
    {
        //get changelists
        list = parseChangelogXML(buildXml.changeSet, 2)
        mailTrigger += "<br>" + list.join("<br>")

        //get submitters' emails
        list = parseChangelogXML(buildXml.changeSet, 4)
        if (list != [])
            recipientList = list.join(',')
    }
    buildXml = null // to avoid java.io.NotSerializableException: groovy.util.slurpersupport.NodeChild

    // *** LINK TO JENKINS JOB ***
    def mailJenkins = "Jenkins Job: <a href='${env.BUILD_URL}'>${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"

    def mailArtifact = ""
    def mailWorkItems = ""
    def mailResolvedIn = ""
    if (buildType in ["NIGHTLY"])
    {
        // *** LINK TO ARTIFACT ***
        tmpStageMap = getStageMap(vresultmap,"Upload to Nexus")
        if (tmpStageMap!=null)
        {
            if (tmpStageMap.status == 2)
                mailArtifact = "Artifact Location: <a href='${artifacturl}'>${artifactname}</a>"
            else
                mailArtifact = "Artifact Location: no artifact was uploaded"
        }

		// *** Mail ResolvedIn Version  ***
	mailResolvedIn = "Resolved In Optima Version "  + '<B>' + env."ResolvedIn" + '</B>'


        // *** LIST OF WORK ITEMS ***
        def tfsResolvedIn = env."ResolvedIn"
        def tfsScript = load('jenkins/TFS.groovy')
        //get a list of WI for this build
        def wiql = "Select ID, title from [Issue] where (state  in ('Resolved','Closed') and [Work Item Type] in ('Bug', 'Task', 'Merge') and ([ResolvedIn] = '" + tfsResolvedIn + "') and [Area Path] under 'NBU\\Optima\\Web\\Framework\\')"
        def wis = tfsScript.tfsGetWIsByQuery(wiql)
        if (wis != [])
        {
            //get more information on the found WIs as a json
            def wiDetails = tfsScript.tfsGetWIDetails(wis)
            //now transform this json to an HTMLTable
            mailWorkItems = "<B><U>Work Items</U></B><BR>" + tfsScript.WItoHTML(wiDetails)
        }
        else
            mailWorkItems = "<B>No Work Items found</B><BR>"
    }

    // *** LINKS TO TESTS ***
    def mailTests = ""
    tmpStageMap = getStageMap(vresultmap,"Tests")
    if (tmpStageMap!=null)
    {
        if (tmpStageMap.status == 2)
        {
            def testCount = getTestResultsFromJenkins()
            mailTests += "Unit Test Results: ${testCount.passCount} Passed | ${testCount.failCount} failed | ${testCount.skipCount} skipped<BR>" +
                         "Unit Test Report: <a href='${env.BUILD_URL}/testReport'>Test Report [${env.BUILD_NUMBER}]</a><BR>" +
                         "Coverage Report: <a href='${env.BUILD_URL}/Coverage'>coverage report [${env.BUILD_NUMBER}]</a>"
      //      if (buildType in ["NIGHTLY"])
     //       {
               // def coveragePct = getCoverageFromSonar("com.amd.optima.ui.frontend-Core") //****not work*******//TODO: align with nexusGroupID and not hardcoded
          //      mailTests += "<BR>Code Coverage (by SonarQube): ${coveragePct}%<BR>" +
        //                   "SonarQube Portal: <a href='http://10.230.16.221:9000/dashboard/index?id=com.amd.optima.ui.core-csr'>Optima core CSR</a>"
    //        }
        }
        else
            mailTests += "Test Report: tests did not run or failed<BR>Code Coverage: tests did not run or failed"
    }

    // *** BUILD STAGES ***
    def mailStages = "<B><U>Build Stages</U></B><BR>" + stageMapsToHTMLTable(vresultmap)

    // *** BUILD ERROR ***
    def mailError = ""
    if (errmsg != "")
        mailError += "Failure Exception: <br>" + errmsg


    // *** RECIPIENTS ***
    //success after failure or failure - TO:all developers CC: management
    def recipients = load("jenkins/recipients.groovy")
    if((!hudson.model.Result.SUCCESS.equals(currentBuild.rawBuild.getPreviousBuild()?.getResult()) && buildStatus=="SUCCESS") || buildStatus!="SUCCESS")
    {
        if (recipientList == "")
            recipientList = recipients.allDevelopersList() + ',cc:' + recipients.managementList().replaceAll(',',',cc:')
        else
            recipientList += ',' + recipients.allDevelopersList() + ',cc:' + recipients.managementList().replaceAll(',',',cc:')
    }
    else //success after success - TO:developers who checked in CC: management
    {
        if (recipientList == "")
            recipientList = recipients.managementList()
        else
            recipientList += ',cc:' + recipients.managementList().replaceAll(',',',cc:')
    }


    // *** DURATION ***
    def totalDuration = currentBuild.getDuration()
    if (totalDuration == 0) //there seems to be a bug in which getDuration() always returns zero so need to calculate it ourselves
        totalDuration = ((System.currentTimeMillis()-currentBuild.getStartTimeInMillis()))

    def mailDuration = "Build Duration: " + durationToString(totalDuration)

    def mailBodyHTML = """
   <html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Optima Fixture Build - Success</title>
      <style type="text/css">
         /* Client-specific Styles */
         #outlook a {padding:0;} /* Force Outlook to provide a "view in browser" menu link. */
         body{width:100% !important; -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; margin:0; padding:0;}
         /* Prevent Webkit and Windows Mobile platforms from changing default font sizes, while not breaking desktop design. */
         .ExternalClass {width:100%;} /* Force Hotmail to display emails at full width */
         .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {line-height: 100%;} /* Force Hotmail to display normal line spacing.  More on that: http://www.emailonacid.com/forum/viewthread/43/ */
         #backgroundTable {margin:0; padding:0; width:100% !important; line-height: 100% !important;}
         img {outline:none; text-decoration:none;border:none; -ms-interpolation-mode: bicubic;}
         a img {border:none;}
         .image_fix {display:block;}
         p {margin: 0px 0px !important;}

         table td {border-collapse: collapse;}
         table { border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }
         /*a {color: #e95353;text-decoration: none;text-decoration:none!important;}*/
         /*STYLES*/
         table[class=full] { width: 100%; clear: both; }

         /*################################################*/
         /*IPAD STYLES*/
         /*################################################*/
         @media only screen and (max-width: 640px) {
         a[href^="tel"], a[href^="sms"] {
         text-decoration: none;
         color: #ffffff; /* or whatever your want */
         pointer-events: none;
         cursor: default;
         }
         .mobile_link a[href^="tel"], .mobile_link a[href^="sms"] {
         text-decoration: default;
         color: #ffffff !important;
         pointer-events: auto;
         cursor: default;
         }
         table[class=devicewidth] {width: 440px!important;text-align:center!important;}
         table[class=devicewidthinner] {width: 420px!important;text-align:center!important;}
         table[class="sthide"]{display: none!important;}
         img[class="bigimage"]{width: 420px!important;height:219px!important;}
         img[class="col2img"]{width: 420px!important;height:258px!important;}
         img[class="image-banner"]{width: 440px!important;height:106px!important;}
         td[class="menu"]{text-align:center !important; padding: 0 0 10px 0 !important;}
         td[class="logo"]{padding:10px 0 5px 0!important;margin: 0 auto !important;}
         img[class="logo"]{padding:0!important;margin: 0 auto !important;}

         }
         /*##############################################*/
         /*IPHONE STYLES*/
         /*##############################################*/
         @media only screen and (max-width: 480px) {
         a[href^="tel"], a[href^="sms"] {
         text-decoration: none;
         color: #ffffff; /* or whatever your want */
         pointer-events: none;
         cursor: default;
         }
         .mobile_link a[href^="tel"], .mobile_link a[href^="sms"] {
         text-decoration: default;
         color: #ffffff !important;
         pointer-events: auto;
         cursor: default;
         }
         table[class=devicewidth] {width: 280px!important;text-align:center!important;}
         table[class=devicewidthinner] {width: 260px!important;text-align:center!important;}
         table[class="sthide"]{display: none!important;}
         img[class="bigimage"]{width: 260px!important;height:136px!important;}
         img[class="col2img"]{width: 260px!important;height:160px!important;}
         img[class="image-banner"]{width: 280px!important;height:68px!important;}

         }
      </style>


   </head>
<body>
<div class="block">
   <!-- Start of preheader -->
   <table width="100%" bgcolor="#f6f4f5" cellpadding="0" cellspacing="0" border="0" id="backgroundTable" st-sortable="preheader">
      <tbody>
         <tr>
            <td width="100%">
               <table width="580" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                  <tbody>
                     <!-- Spacing -->
                     <tr>
                        <td width="100%" height="10"></td>
                                         </tr>
                     <!-- Spacing -->
                  </tbody>
               </table>
            </td>
         </tr>
      </tbody>
   </table>
   <!-- End of preheader -->
</div>
<div class="block">
   <!-- start of header -->
   <table width="100%" bgcolor="#f6f4f5" cellpadding="0" cellspacing="0" border="0" id="backgroundTable" st-sortable="header">
      <tbody>
         <tr>
            <td>
               <table width="580" bgcolor="#D0D0D0" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth" hlitebg="edit" shadow="edit">  <!--  = Green for succes  =red for failure -->
                  <tbody>
                     <tr>
                        <td>
                           <!-- logo -->
                           <table width="280" cellpadding="0" cellspacing="0" border="0" align="left" class="devicewidth">
                              <tbody>
                                 <tr>
                                    <td valign="middle" width="270" style="padding: 10px 0 10px 20px;" class="logo">
                                       <div class="imgpop">
                                          <a href="#"><img src="http://www.amdocsoptima.com/wp-content/uploads/2016/08/amdocs-logo.png" alt="logo" border="0" style="display:block; border:none; outline:none; text-decoration:none;" st-image="edit" class="logo"></a>
                                       </div>
                                    </td>
                                 </tr>
                              </tbody>
                           </table>
                           <!-- End of logo -->
                        </td>
                     </tr>
                  </tbody>
               </table>
            </td>
         </tr>
      </tbody>
   </table>
   <!-- end of header -->
</div><div class="block">

<div class="block">
   <!-- start textbox-with-title -->
   <table width="100%" bgcolor="#f6f4f5" cellpadding="0" cellspacing="0" border="0" id="backgroundTable" st-sortable="fulltext">
      <tbody>
         <tr>
            <td>
               <table bgcolor="#ffffff" width="580" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth" modulebg="edit">
                  <tbody>
                     <!-- Spacing -->
                     <tr>
                        <td width="100%" height="30"></td>
                     </tr>
                     <!-- Spacing -->
                     <tr>
                        <td>
                           <table width="540" align="center" cellpadding="0" cellspacing="0" border="0" class="devicewidthinner">
                              <tbody>
                                 <!-- Title -->
                                 <tr>
                                    <td style="font-family: Helvetica, arial, sans-serif; font-size: 18px; color: #333333; text-align:center;line-height: 20px;" st-title="fulltext-title">
                                      Job '${env.JOB_NAME} ${env.BUILD_NUMBER}': ${buildStatus} <!-- place for optima version in {} Title -->
                                    </td>
                                 </tr>
                                 <!-- End of Title -->
                                 <!-- spacing -->

                                 <!-- End of spacing -->
                                 <!-- content -->
                                 <tr>
                                  <td style="font-family: Helvetica, arial, sans-serif; font-size: 14px; color: #95a5a6; text-align:left;line-height: 30px;" st-content="fulltext-paragraph">
                                     ${mailResolvedIn} <!-- place holder from componnent versions -->
                                    </td>
                                 </tr>
                                 <!-- End of content -->
                                                                           <!-- Spacing -->
                                 <tr>
                                    <td width="100%" height="30"></td>
                                 </tr>
                                 <!-- Spacing -->
                              </tbody>
                           </table>
                        </td>
                     </tr>
                  </tbody>
               </table>
            </td>
         </tr>
      </tbody>
   </table>
   <!-- end of textbox-with-title -->
</div>


<div class="block">
   <!-- Full + text -->
   <table width="100%" bgcolor="#f6f4f5" cellpadding="0" cellspacing="0" border="0" id="backgroundTable" st-sortable="fullimage">
      <tbody>
         <tr>
            <td>
               <table bgcolor="#ffffff" width="580" align="center" cellspacing="0" cellpadding="0" border="0" class="devicewidth" modulebg="edit">
                  <tbody>
                                       <tr>
                        <td>
                           <table width="540" align="center" cellspacing="0" cellpadding="0" border="0" class="devicewidthinner">
                              <tbody>
                                 <!-- title -->
                                 <tr>
                                    <td style="font-family: Helvetica, arial, sans-serif; font-size: 18px; color: #333333; text-align:left;line-height: 20px;" st-title="rightimage-title">
                                       Build Information
                                    </td>
                                 </tr>
                                 <!-- end of title -->
                                 <!-- Spacing -->
                                 <tr>
                                    <td width="100%" height="10"></td>
                                 </tr>
                                 <!-- Spacing -->
                                 <!-- content -->
                                 <tr>
                                    <td style="font-family: Helvetica, arial, sans-serif; font-size: 13px; color: #666666; text-align:left;line-height: 24px;" st-content="rightimage-paragraph">
                                       <p>${mailDuration}<br>${mailTrigger}<br></p>
                                    </td>
                                 </tr>
                                 <!-- end of content -->
                                 <!-- Spacing -->
                                 <tr>
                                    <td width="100%" height="10"></td>
                                 </tr>
                                 <!-- button -->
                                 <tr>
                                    <td>
                                       <table height="30" align="left" valign="middle" border="0" cellpadding="0" cellspacing="0" class="tablet-button" st-button="edit">
                                                                  <tbody>
                                                                     <tr>
                                                                        <td width="auto" align="center" valign="middle" height="30" style=" background-color:#0db9ea; border-top-left-radius:4px; border-bottom-left-radius:4px;border-top-right-radius:4px; border-bottom-right-radius:4px; background-clip: padding-box;font-size:13px; font-family:Helvetica, arial, sans-serif; text-align:center;  color:#ffffff; font-weight: 300; padding-left:18px; padding-right:18px;">
                                                                           <span style="color: #ffffff; font-weight: 300;">
                                                                              <a style="color: #ffffff; text-align:center;text-decoration: none;" href="http://10.234.209.9:8080/blue/organizations/jenkins/${env.JOB_NAME}/detail/${env.JOB_NAME}/${env.BUILD_NUMBER}/pipeline">Job Info</a>
                                                                           </span>
                                                                        </td>
									 <td width="auto" align="center" valign="middle" height="30" style="  border-top-left-radius:4px; border-bottom-left-radius:4px;border-top-right-radius:4px; border-bottom-right-radius:4px; background-clip: padding-box;font-size:13px; font-family:Helvetica, arial, sans-serif; text-align:center;  color:#ffffff; font-weight: 300; padding-left:18px; padding-right:18px;">
                                                                           <span style="color: #ffffff; font-weight: 300;">
                                                                              <a style="color: #ffffff; text-align:center;text-decoration: none;" href="">    </a>
                                                                           </span>
                                                                        </td>
                                                                 <td width="auto" align="center" valign="middle" height="30" style=" background-color:#0db9ea; border-top-left-radius:4px; border-bottom-left-radius:4px;border-top-right-radius:4px; border-bottom-right-radius:4px; background-clip: padding-box;font-size:13px; font-family:Helvetica, arial, sans-serif; text-align:center;  color:#ffffff; font-weight: 300; padding-left:18px; padding-right:18px;">
                                                                           <span style="color: #ffffff; font-weight: 300;">
                                                                              <a style="color: #ffffff; text-align:center;text-decoration: none;" href="${env.BUILD_URL}/changes">Job Changes</a>
                                                                           </span>
                                                                        </td>
                                                                   </tr>
                                                                  </tbody>
                                                               </table>
                                    </td>
                                 </tr>
                                 <!-- /button -->
                                                            </tbody>
                           </table>
                        </td>
                     </tr>
                  </tbody>
               </table>
            </td>
         </tr>
      </tbody>
   </table>
</div>
<div class="block">

<div class="block">
   <!-- Full + text -->
   <table width="100%" bgcolor="#f6f4f5" cellpadding="0" cellspacing="0" border="0" id="backgroundTable" st-sortable="fullimage">
      <tbody>
         <tr>
            <td>
               <table bgcolor="#ffffff" width="580" align="center" cellspacing="0" cellpadding="0" border="0" class="devicewidth" modulebg="edit">
                  <tbody>
                     <tr>
                        <td width="100%" height="20"></td>
                     </tr>
                     <tr>
                        <td>
                           <table width="540" align="center" cellspacing="0" cellpadding="0" border="0" class="devicewidthinner">
                              <tbody>
                                 <!-- title -->
                                 <tr>
                                    <td style="font-family: Helvetica, arial, sans-serif; font-size: 18px; color: #333333; text-align:left;line-height: 20px;" st-title="rightimage-title">
                                        Test Results
                                    </td>
                                 </tr>
                                 <!-- end of title -->
                                 <!-- Spacing -->
                                 <tr>
                                    <td width="100%" height="10"></td>
                                 </tr>
                                 <!-- Spacing -->
                                 <!-- content -->
                                 <tr>
                                    <td style="font-family: Helvetica, arial, sans-serif; font-size: 13px; color: #666666; text-align:left;line-height: 24px;" st-content="rightimage-paragraph">
                                                  </td>
                                 </tr>
                                 <!-- end of content -->
                                 <!-- Spacing -->
                                 <tr>
                                    <td width="100%" height="10"></td>
                                 </tr>
                                 <!-- button -->
                                 <tr>
                                    <td>
                                       <table height="30" align="left" valign="middle" border="0" cellpadding="0" cellspacing="0" class="tablet-button" st-button="edit">
                                                                  <tbody>
                                                                     <tr>
                                                                        <td width="auto" align="center" valign="middle" height="30" style=" background-color:#0db9ea; border-top-left-radius:4px; border-bottom-left-radius:4px;border-top-right-radius:4px; border-bottom-right-radius:4px; background-clip: padding-box;font-size:13px; font-family:Helvetica, arial, sans-serif; text-align:center;  color:#ffffff; font-weight: 300; padding-left:18px; padding-right:18px;">
                                                                           <span style="color: #ffffff; font-weight: 300;">
                                                                              <a style="color: #ffffff; text-align:center;text-decoration: none;" href="http://10.234.209.9:8080/blue/organizations/jenkins/${env.JOB_NAME}/detail/${env.JOB_NAME}/${env.BUILD_NUMBER}/tests">Test Report</a>
                                                                           </span>
                                                                        </td>
                                                                     </tr>
                                                                  </tbody>
                                                               </table>
                                    </td>
                                 </tr>
                                 <!-- /button -->
                                 <!-- Spacing -->
                                 <tr>
                                    <td width="100%" height="20"></td>
                                           </tr>
                                 <!-- Spacing -->
				${mailWorkItems}
				 ${mailStages}
                              </tbody>
                           </table>
                        </td>
                     </tr>
                  </tbody>
               </table>
            </td>
         </tr>
      </tbody>
   </table>
</div>
<div class="block">
   <!-- Start of preheader -->
   <table width="100%" bgcolor="#f6f4f5" cellpadding="0" cellspacing="0" border="0" id="backgroundTable" st-sortable="postfooter">
      <tbody>
         <tr>
            <td width="100%">
               <table width="580" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                  <tbody>
                     <!-- Spacing -->
                     <tr>
                        <td width="100%" height="5"></td>
                     </tr>
                     <!-- Spacing -->
                     <tr></tr>
                     <!-- Spacing -->
                     <tr>
                        <td width="100%" height="5"></td>
                     </tr>
                     <!-- Spacing -->
                  </tbody>
               </table>
            </td>
         </tr>
      </tbody>
   </table>
   <!-- End of preheader -->
</div>

</body>
</html>



    """


    //send the actual email
    emailext (
        subject: "Build release notes '${env.JOB_NAME} [${env.BUILD_NUMBER}]': ${buildStatus}",
        body: mailBodyHTML,
        recipientProviders: [],
        mimeType: "text/html",
        contentType: "text/html",
        to: recipientList
    )
}

@NonCPS
def getStageMap(def stageMap, def name)
{
    return stageMap.find{it.get('name')==name}
}


@NonCPS
def stageMapsToHTMLTable(def stageMaps2)
{
    def tableStyle = 'style="border-collapse:collapse; text-align:left;"'
    def tableHeaderTRStyle = 'style="font-family:Calibri; font-weight:bold; background-color:#3D5277; color:#ffffff;"'
    def tableHeaderTDStyle = 'style="font-family:Calibri; font-weight:bold; text-align:center; background-color:#3D5277; color:#ffffff; border-color:#5c87b2; border-style:solid; border-width:thin; padding: 5px;"'
    def tableRowTRStyle = 'style=" font-family:Calibri; border-color:#5c87b2; border-style:solid; border-width:thin; padding: 5px;"'
    def tableRowTDStyle = 'style=" font-family:Calibri; border-color:#5c87b2; border-style:solid; border-width:thin; padding: 5px;"'
    def strStatus=""
    def strDuration=""
    def mailStages =  """<TABLE ${tableStyle}>
    <TR ${tableHeaderTRStyle}>
        <TD ${tableHeaderTDStyle}>Build Stage</TD>
        <TD ${tableHeaderTDStyle}>Status</TD>
        <TD ${tableHeaderTDStyle}>Duration</TD>
    </TR>"""
    stageMaps2.findAll
    {
        strStatus = formatSuccessFlag(it.status)
        if (it.duration>0)
            strDuration = durationToString(it.duration)
        else
            strDuration = ""
        mailStages += """<TR ${tableRowTRStyle}>
        <TD ${tableRowTDStyle}>${it.name}</TD>
        <TD ${tableRowTDStyle}>${strStatus}</TD>
        <TD ${tableRowTDStyle}>${strDuration}</TD>
    </TR>"""
    }

    mailStages += "\n</TABLE>"
    return mailStages
}

@NonCPS
def mapToList(depmap) {
    def dlist = []
    for (entry in depmap) {
        dlist.add([entry.key, entry.value])
    }
    return dlist
}


@NonCPS
def successFlagToBoolean (def flag)
{
    if (flag ==2) return true
    return false
}

@NonCPS
def formatSuccessFlag (def flag)
{
    if (flag == 0) return "Did not start due to previous failures"
    else if (flag == 1) return "Failure"
    return "Success"
}

@NonCPS
def formatBoolResult(def result) {
    if (result) return 'Success'
    return 'Failure'
}

def npm(def cmd) {
    withEnv(["PATH=/usr/local/bin:${env.PATH}","NODE_PATH=/usr/lib/node_modules","HTTP_PROXY=http://10.232.233.70:8080","HTTPS_PROXY=http://10.232.233.70:8080","NO_PROXY=10.234.211.120"]) {
        sh '/usr/local/bin/npm ' + cmd
    }
}

def gulp(def cmd) {
    withEnv(["PATH=/usr/local/bin:${env.PATH}"]) {
        sh '/usr/local/bin/node node_modules/gulp/bin/gulp.js ' + cmd
    }
}

def version()  {
    def json = readFile("package.json")
    return new groovy.json.JsonSlurperClassic().parseText(json)["version"]
}

def timestamp() {
    def now = new Date()
    return now.format("yyyyMMdd-HHmmss", TimeZone.getTimeZone('UTC'))
}

def runOnRemoteServer(def server, def cmd) {
    sh "ssh ${server} '${cmd}'"
}

@NonCPS
def parseChangelogXML(def jenkins_changelog_xml, def mod)
{
    def list = []
    def tmpstr
    //rootNode = new XmlSlurper().parse( new File(filename) )
    switch (mod)
    {
        case 1: //file changes
            jenkins_changelog_xml.item.affectedPath.each
            { it ->
                list << it
            }
            list.unique() //remove duplicate files if they were modified by multiple changelists
            break
        case 2: //changelists
            jenkins_changelog_xml.item.each
            { it ->
                list << "${it.author.fullName} submitted changelist ${it.changeNumber}: ${it.msg}"
            }
            break
        case 3: //submitters
            jenkins_changelog_xml.item.author.fullName.each
            { it ->
                list << it
            }
            list.unique() //in case the same person submitted twice
            break
        case 4: //submitters as email addresses
            jenkins_changelog_xml.item.author.fullName.each
            { it ->
                tmpstr = it.toString().replaceAll(' ','.') + '@amdocs.com'
                list << tmpstr
            }
            list.unique() //in case the same person submitted twice
            break
        case 5: //work items
            jenkins_changelog_xml.item.msg.each
            { it ->
                it.toString().replaceAll(/#wi:(\d+)#/)
                { fullmatch,winumber ->
                    list << winumber
                }
            }
            list.unique() //in case the same WI is submitted twice
            break
        default: null
    }
    return list
}

@NonCPS
def durationToString(def duration, def mode=1)
{
    def timeString = ""
    if (duration < 1000)
        timeString = duration + "ms"
    else
    {
        Integer sec = duration.intValue()/1000
        Integer hours = (int) (sec/3600)
        Integer minutes = (int) ((sec%3600)/60)
        Integer seconds = (int) (sec%60)

        //hours
        if (mode==1)
        {
            if (hours >0)
                timeString += hours + "h "
            if (minutes >0)
                timeString += minutes + "m "
            if (seconds > 0)
                timeString += seconds + "s"
        }
        else
            timeString += sprintf "%02d:%02d:%02d", hours, minutes, seconds
    }

    return timeString
}

def getCoverageFromSonar(def componentKey)
{
    //TODO: get the sonar server from jenkins configuration and not hardcoded
//    def wi_json
 //   withCredentials([usernamePassword(credentialsId: 'sonar_jenkins', passwordVariable: 'CPASS', usernameVariable: 'CUSER')])
 //   {
 //       def cmd = "curl -s -S -u ${CUSER}:${CPASS} 'http://10.230.16.221:9000/api/measures/component?metricKeys=coverage&componentKey=${componentKey}'"
 //       wi_json = sh script:cmd, returnStdout: true
  //  }
  //  def jsn = new JsonSlurperClassic().parseText(wi_json)
  //  return jsn.component.measures[0].value
}

def getTestResultsFromJenkins()
{
    def cmd = 'curl -s "' + BUILD_URL + 'testReport/api/json?tree=passCount,skipCount,failCount"'
    def wi_json = sh script:cmd, returnStdout: true

    def jsn = new JsonSlurperClassic().parseText(wi_json)
    return jsn
}

def getServerLastBuild()
{
    def cmd = 'curl -s "' + JENKINS_URL + '/job/UI-WebServer-CI/lastBuild/api/json"'
    def wi_json = sh script:cmd, returnStdout: true

    def jsn = new JsonSlurperClassic().parseText(wi_json)
    return jsn.result
}


return this;