def allDevelopersList() 
{ 
    return "AmdocsOptimaUIBackendBuild@int.amdocs.com"
}

def managementList() 
{ 
    return "AmdocsOptimaUIManagementBuild@int.amdocs.com;Oren.Cohen2@amdocs.com"
}

return this;