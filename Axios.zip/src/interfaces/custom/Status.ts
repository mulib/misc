
export interface Status {
    isDefault: string
    label: string
    statusId: string
    statusTypeId: string
    value: string
    displayValue: string
}
