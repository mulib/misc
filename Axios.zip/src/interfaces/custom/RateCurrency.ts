import { EnumerationValue } from '../..'

export interface RateCurrency extends EnumerationValue {
    code?: number
    currencyCode?: string
    impliedDecimal?: string
    roundingMethod?: string
    shortDisplay?: string
}
