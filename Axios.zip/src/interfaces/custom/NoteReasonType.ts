import { EnumerationValue } from '../..'

export interface NoteReasonType extends EnumerationValue {
    noteReasonId?: string
    noteTypeId?: string
}
