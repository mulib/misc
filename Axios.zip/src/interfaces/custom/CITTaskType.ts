import { EnumerationDataWrapper } from '../../index'



interface CITTaskType extends EnumerationDataWrapper {
    isDefault: string
    label: string
    value: string
    displayValue: string
}

