export interface ApiActionMap {
    [apiName: string]: Function
}
