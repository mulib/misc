/**
 * ResponseWrapper interface, standard container for all responses
 * @export
 * @interface ResponseWrapper<T>
 */
 import { Link } from '../../index'

export interface ResponseWrapper<T> {
    code?: number
    message?: string
    response?: T
    totalCount?: number
    self?: Link
    links?: Link[]
}
