
export interface EnumerationValue {
    value: string
    label?: string
    displayValue?: string
    isDefault?: string
    isBusiness?: string
    longDisplay?: string
}
