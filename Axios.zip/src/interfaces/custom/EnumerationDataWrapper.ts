/*
 * Interface for flattened enumeration data
 */

export interface EnumerationDataWrapper {
    [f: string]: string | undefined
}

