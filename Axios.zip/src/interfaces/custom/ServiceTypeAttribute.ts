import { EnumerationValue } from '../..'

export interface ServiceTypeAttribute extends EnumerationValue {
    id?: string
    ranking?: string
    serviceType?: string
    url?: string
}
