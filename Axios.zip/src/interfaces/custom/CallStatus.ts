/**
 * CallStatus interface, used to represent the status of a particular asynchronous call.
 * @export
 * @interface CallStatus
 */
export interface CallStatus {
    loading?: boolean // true when the call is in progress
    success?: boolean // true when the call is successful
    message?: string // error message returned by the backend
}
