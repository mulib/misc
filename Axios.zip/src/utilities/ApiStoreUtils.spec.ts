import { getApiState } from './ApiStoreUtils'
import { expect } from 'chai'

import { RestApis, ServiceNames } from '../apiCalls/generated/ApiConstants'
import { apiInitialState, ApiState } from '../apiCalls/generated/ApiState'
describe('getApiState', () => {
    context('given an empty application state', () => {
        it('should return undefined', () => {
            expect(getApiState()('BIM', 'BAM')).to.equal(undefined, 'getApiState(undefined)(anything,anything)')
        })
    })

    context('given an unrecognized service name', () => {
        it('should return undefined', () => {
            const apiState: ApiState = { ...apiInitialState }
            apiState.accountManagement.accountGetById = { callStatus: { loading: true } }
            expect(getApiState(apiState)('BIM', RestApis.accountGetById)).to.equal(undefined, 'getApiState(apiState)(anything,valid)')
        })
    })
    context('given an unrecognized api name', () => {
        it('should return undefined', () => {
            const apiState: ApiState = { ...apiInitialState }
            apiState.accountManagement.accountGetById = { callStatus: { loading: true } }
            expect(getApiState(apiState)(ServiceNames.AccountManagement, 'BAM')).to.equal(undefined, 'getApiState(apiState)(valid,anything)')
        })
    })
    context('given an populated application state, a valid service name and a valid api name', () => {
        it('should return the api state', () => {
            const apiState: ApiState = { ...apiInitialState }
            apiState.accountManagement.accountGetById = { callStatus: { loading: true } }
            expect(getApiState(apiState)(ServiceNames.AccountManagement, RestApis.accountGetById)).to.deep.equal({ callStatus: { loading: true } }, 'getApiState(apiState)(valid,valid)')
        })
    })
})
