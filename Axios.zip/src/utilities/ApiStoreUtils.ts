import * as _ from 'lodash'
import { ApiState } from '../apiCalls/generated/ApiState'
import { RestApis, ServiceNames } from '../apiCalls/generated/ApiConstants'
import { CallStatus } from '..'

/**
 * returns the Api substate related to a particular serviceName and API.
 * If the substate cannot be found, returns undefined.
 * If invoked with an unrecognized microservice name or api name, returns undefined and logs an error in the console.
 */
export const getApiState = <T extends { callStatus?: CallStatus }>(apiState?: ApiState) => (serviceName: string, apiName: string): T | undefined => {
    if (apiState === undefined) {
        return undefined
    }

    if (Object.keys(ServiceNames).find((key) => ServiceNames[key] === serviceName) === undefined) {
        console.error(`[ERROR] unrecognized ${serviceName} service name. There is no substate available for this service`)

        return undefined
    }

    if (Object.keys(RestApis).find((key) => RestApis[key] === apiName) === undefined) {
        console.error(`[ERROR] unrecognized ${apiName} API name. There is no substate available for this api`)

        return undefined
    }

    return _.get(apiState, [serviceName, apiName]) as T
}
