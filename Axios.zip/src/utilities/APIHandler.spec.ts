import * as sinon from 'sinon'
import { expect } from 'chai'
import axios, { AxiosResponse } from 'axios'
import MockAdapter from 'axios-mock-adapter'
import apiHandler, { ApiCall, APIHandler, ApiConfig, ApiDefinition, ApiConfigParam } from './APIHandler'

const OK = 200

const restApiConfiguration: ApiConfig = {
    apis: {
        accountGetByFilter: {
            api: 'customeraccounts',
            method: 'get'
        },
        accountGetById: {
            api: 'customeraccounts',
            method: 'get',
            path: '{AccountInternalId}'
        },
        accountUpdate: {
            api: 'customeraccounts',
            method: 'put',
            path: '{AccountInternalId}',
            server: 'versionServer'
        },
        balanceInfo: {
            api: 'customeraccounts',
            method: 'get',
            path: '{AccountInternalId}/balanceInfo',
            server: 'anotherServer'
        },
        findChargeRedirections: {
            api: 'customeraccounts',
            baseUrl: 'https://myapiman:8443/apiman-gateway/MyOrganization',
            method: 'get',
            path: '{AccountInternalId}/chargeredirections'
        },
        getChargeRedirections: {
            api: 'customeraccounts',
            method: 'get',
            path: '{AccountInternalId}/chargeredirections/{TrackingId}%2C{TrackingIdServ}'
        },
        getSummaryById: {
            api: 'customeraccounts',
            contractVersion: '2.0',
            method: 'get',
            path: '{AccountInternalId}/balancesummary'
        },
        updateUser: {
            api: 'customeraccounts',
            apiVersion: 'v2',
            method: 'put',
            path: '{AccountInternalId}/users/{UserId}',
            server: 'versionServer'
        },
        updateUserInfo: {
            api: 'customeraccounts',
            apiVersion: 'v3',
            contractVersion: '3.0',
            method: 'put',
            path: '{AccountInternalId}/users/{UserId}/update'
        }
    },
    defaultServer: 'apiman',
    servers: {
        anotherServer: {
            baseUrl: 'http://localhost:3007/api'
        },
        apiman: {
            baseUrl: 'https://apiman:8443/apiman-gateway/Optima',
            contractVersion: '1.0'
        },
        versionContract: {
            apiVersion: 'v2',
            baseUrl: 'https://localhost:8443/rest',
            contractVersion: '3.0'
        },
        versionServer: {
            apiVersion: 'v1',
            baseUrl: 'https://localhost:8080/rest'
        }
    },
    timeout: 20000
}

const fullConfig = {
    defaultServer: 'apiman',
    headers: {
        'Content-Type': 'application/json'
    },
    restApiConfig: restApiConfiguration,
    tenantConfiguration: [
        {
            localization: {
                defaultLanguage: 'en-US',
                supportedLanguages: [
                    'en-US',
                    'en-GB',
                    'fr-FR',
                    'bg-BG'
                ]
            },
            restApiConfig: {
                apis: {
                    getChargeRedirections: {
                        server: 'customeraccountsms'
                    }
                },
                defaultServer: 'apiman',
                servers: {
                    customeraccountsms: {
                        baseUrl: 'http://fuse:8010/rest/v1'
                    }
                }
            },
            sso: {
                configuration: {
                    clientId: 'csr-web',
                    idleTimeout: 600000,
                    realm: 'csr-ui_2',
                    url: 'https://optssodev1.corp.amdocs.com:8190/auth'
                },
                enabled: true,
                initOptions: {
                    checkLoginIframe: false,
                    flow: 'implicit'
                }
            },
            tenantId: 2,
            tenantName: 'tenant1',
        }
    ]
}

describe('APIHandler', () => {
    describe('setApiConfig', () => {
        describe('initial configuration', () => {
            it('should set default configuration', () => {
                expect(apiHandler).to.exist
                expect(apiHandler.apiConfig).to.exist
                expect(apiHandler.apiConfig.timeout).to.not.exist
                expect(apiHandler.apiConfig.headers).to.not.exist
                expect(apiHandler.apiConfig.defaultServer).to.not.exist
                expect(apiHandler.apiConfig.servers).to.be.empty
                expect(apiHandler.apiConfig.apis).to.be.empty
                expect(APIHandler.singleton).to.exist
            })

            it('should create the singleton when the instance is gotten', () => {
                const singleton = APIHandler.instance
                expect(singleton).to.exist
                expect(APIHandler.singleton).to.exist
                expect(APIHandler.singleton).to.equal(singleton)
            })
        })

        describe('config merge', () => {
            let restApiConfig: ApiConfig
            let headerConfig: ApiConfig
            let timeoutConfig: ApiConfig

            before(() => {
                restApiConfig = {
                    apis: {},
                    defaultServer: 'apiman',
                    servers: {},
                    timeout: 20000,
                }
                headerConfig = { headers: { Authorization: 'bearer XYZ' }, apis: {}, defaultServer: 'apiman', servers: {} }
                timeoutConfig = { timeout: 1000, apis: {}, defaultServer: 'apiman', servers: {} }
                apiHandler.setApiConfig(restApiConfig)
            })

            it('should set timeout and headers', () => {
                expect(apiHandler.apiConfig.timeout).to.equal(restApiConfig.timeout, 'restApiConfig.timeout')
                expect(apiHandler.apiConfig.headers).to.exist
                expect(apiHandler.apiConfig.headers).to.have.property('TransactionId').that.matches(/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/)
                expect(apiHandler.apiConfig.defaultServer).to.equal(restApiConfig.defaultServer)
                expect(apiHandler.apiConfig.servers).to.be.empty
                expect(apiHandler.apiConfig.apis).to.be.empty
            })

            it('should merge headers', () => {
                const transactionId: string = apiHandler.apiConfig.headers ? apiHandler.apiConfig.headers.TransactionId as string : ''
                apiHandler.setApiConfig(headerConfig)
                expect(apiHandler.apiConfig.timeout).to.equal(restApiConfig.timeout)
                expect(apiHandler.apiConfig.headers).to.exist
                expect(apiHandler.apiConfig.headers).to.have.property('Authorization', 'bearer XYZ')
                expect(apiHandler.apiConfig.defaultServer).to.equal(restApiConfig.defaultServer)
                expect(apiHandler.apiConfig.headers).to.have.property('TransactionId', transactionId, 'transaction id changed')
            })

            it('should override existing values', () => {
                expect(apiHandler.apiConfig.timeout).to.equal(restApiConfig.timeout)
                apiHandler.setApiConfig(timeoutConfig)
                expect(apiHandler.apiConfig.timeout).to.equal(timeoutConfig.timeout)
            })

            it('should set the transaction ID if headers exist but transacion ID does not', () => {
                if (apiHandler.apiConfig.headers && apiHandler.apiConfig.headers.TransactionId) {
                    delete apiHandler.apiConfig.headers.TransactionId
                }
                expect(apiHandler.apiConfig.headers).to.not.have.property('TransactionId')
                apiHandler.setApiConfig(headerConfig)
                expect(apiHandler.apiConfig.headers).to.exist
                expect(apiHandler.apiConfig.headers).to.have.property('TransactionId').that.matches(/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/)
            })
        })
    })

    describe('callRestApi', () => {
        describe('standard get, no path parameters', () => {
            let params: ApiConfigParam
            let apiCall: ApiCall
            let mock: MockAdapter

            before(() => {
                params = {
                    filters: 'AccountInternalId==1234'
                }
                apiCall = {
                    apiName: 'accountGetByFilter',
                    params
                }

                mock = new MockAdapter(axios)
                mock.onAny().reply((config) => {
                    return new Promise((resolve, reject) => {
                        resolve([OK])
                    })
                })
            })

            it('should call customeraccounts API', () => {
                apiHandler.setApiConfig(fullConfig.restApiConfig)
                expect(apiHandler.apiConfig.apis).to.not.be.empty

                return apiHandler.callRestApi(apiCall).then((response) => {
                    expect(response.config.url).to.equal('https://apiman:8443/apiman-gateway/Optima/customeraccounts/1.0')
                    expect(response.config.method).to.equal('get')
                    expect(response.config.params.filters).to.equal(params.filters)
                    delete response.config.headers.Accept
                    expect(response.config.headers).to.deep.equal(apiHandler.apiConfig.headers)
                })
            })
        })

        describe('standard put, path parameters, payload', () => {
            let data: object
            let apiCall: ApiCall
            let mock: MockAdapter

            before(() => {
                data = {
                    statementToEmail: 'test@amdocs.com'
                }
                apiCall = {
                    apiName: 'accountUpdate',
                    data,
                    pathParams: {
                        AccountInternalId: 1234,
                    }
                }
                mock = new MockAdapter(axios)
                mock.onAny().reply((config) => {
                    return new Promise((resolve, reject) => {
                        resolve([OK])
                    })
                })
            })

            it('should call customeraccounts update API', () => {
                apiHandler.setApiConfig(fullConfig.restApiConfig)

                return apiHandler.callRestApi(apiCall).then((response) => {
                    expect(response.config.url).to.equal('https://localhost:8080/rest/v1/customeraccounts/1234')
                    expect(response.config.method).to.equal('put')
                    const _data = JSON.parse(response.config.data)
                    expect(_data).to.deep.equal(data)
                })
            })
        })

        describe('multiple path parameters', () => {
            let apiCall: ApiCall
            let mock: MockAdapter

            before(() => {
                apiCall = {
                    apiName: 'getChargeRedirections',
                    pathParams: {
                        AccountInternalId: 1234,
                        TrackingId: 45,
                        TrackingIdServ: 6
                    }
                }
                mock = new MockAdapter(axios)
                mock.onAny().reply((config) => {
                    return new Promise((resolve, reject) => {
                        resolve([OK])
                    })
                })
            })

            it('should call chargeredirections API with the correct path parameters', () => {
                apiHandler.setApiConfig(fullConfig.restApiConfig)

                return apiHandler.callRestApi(apiCall).then((response) => {
                    expect(response.config.url).to.equal('https://apiman:8443/apiman-gateway/Optima/customeraccounts/1.0/1234/chargeredirections/45%2C6')
                    expect(response.config.method).to.equal('get')
                    expect(response.config.params).to.be.empty
                })
            })
        })

        describe('different contract version', () => {
            let apiCall: ApiCall
            let mock: MockAdapter

            before(() => {
                apiCall = {
                    apiName: 'getSummaryById',
                    pathParams: {
                        AccountInternalId: '1234'
                    }
                }
                mock = new MockAdapter(axios)
                mock.onAny().reply((config) => {
                    return new Promise((resolve, reject) => {
                        resolve([OK])
                    })
                })
            })

            it('should call customeraccounts API with contract version 2.0', () => {
                apiHandler.setApiConfig(fullConfig.restApiConfig)

                return apiHandler.callRestApi(apiCall).then((response) => {
                    expect(response.config.url).to.equal('https://apiman:8443/apiman-gateway/Optima/customeraccounts/2.0/1234/balancesummary')
                    expect(response.config.method).to.equal('get')
                    expect(response.config.params).to.be.empty
                })
            })
        })

        describe('api version', () => {
            let apiCall: ApiCall
            let mock: MockAdapter

            before(() => {
                apiCall = {
                    apiName: 'updateUser',
                    data: { test: 'yes' },
                    pathParams: {
                        AccountInternalId: '1234',
                        UserId: 'AAAA'
                    }
                }
                mock = new MockAdapter(axios)
                mock.onAny().reply((config) => {
                    return new Promise((resolve, reject) => {
                        resolve([OK])
                    })
                })
            })

            it('should call updateUser API with version v2', () => {
                apiHandler.setApiConfig(fullConfig.restApiConfig)

                return apiHandler.callRestApi(apiCall).then((response) => {
                    expect(response.config.url).to.equal('https://localhost:8080/rest/v2/customeraccounts/1234/users/AAAA')
                    expect(response.config.method).to.equal('put')
                    expect(response.config.params).to.be.empty
                })
            })
        })

        describe('api and contract version', () => {
            let apiCall: ApiCall
            let mock: MockAdapter

            before(() => {
                apiCall = {
                    apiName: 'updateUserInfo',
                    data: { test: 'no' },
                    pathParams: {
                        AccountInternalId: '1234',
                        UserId: 'BBBB'
                    }
                }
                mock = new MockAdapter(axios)
                mock.onAny().reply((config) => {
                    return new Promise((resolve, reject) => {
                        resolve([OK])
                    })
                })
            })

            it('should call updateUserInfo v3 API with contract version 3.0', () => {
                apiHandler.setApiConfig(fullConfig.restApiConfig)

                return apiHandler.callRestApi(apiCall).then((response) => {
                    expect(response.config.url).to.equal('https://apiman:8443/apiman-gateway/Optima/v3customeraccounts/3.0/1234/users/BBBB/update')
                    expect(response.config.method).to.equal('put')
                    expect(response.config.params).to.be.empty
                })
            })
        })

        describe('tenant override', () => {
            let apiCall: ApiCall
            let mock: MockAdapter

            before(() => {
                apiCall = {
                    apiName: 'getChargeRedirections',
                    pathParams: {
                        AccountInternalId: 1234,
                        TrackingId: 45,
                        TrackingIdServ: 6
                    }
                }
                mock = new MockAdapter(axios)
                mock.onAny().reply((config) => {
                    return new Promise((resolve, reject) => {
                        resolve([OK])
                    })
                })
            })

            it('should call the service configured for the tenant', () => {
                apiHandler.setApiConfig(fullConfig.restApiConfig)
                apiHandler.setApiConfig(fullConfig.tenantConfiguration[0].restApiConfig)

                return apiHandler.callRestApi(apiCall).then((response) => {
                    expect(response.config.url).to.equal('http://fuse:8010/rest/v1/customeraccounts/1234/chargeredirections/45%2C6')
                    expect(response.config.method).to.equal('get')
                    expect(response.config.params).to.be.empty
                })
            })
        })

        describe('different base URL', () => {
            let apiCall: ApiCall
            let mock: MockAdapter

            before(() => {
                apiCall = {
                    apiName: 'findChargeRedirections',
                    pathParams: {
                        AccountInternalId: '1234'
                    }
                }
                mock = new MockAdapter(axios)
                mock.onAny().reply((config) => {
                    return new Promise((resolve, reject) => {
                        resolve([OK])
                    })
                })
            })

            it('should call find charge redirections on myapiman:8443', () => {
                apiHandler.setApiConfig(fullConfig.restApiConfig)

                return apiHandler.callRestApi(apiCall).then((response) => {
                    expect(response.config.url).to.equal('https://myapiman:8443/apiman-gateway/MyOrganization/customeraccounts/1.0/1234/chargeredirections')
                    expect(response.config.method).to.equal('get')
                    expect(response.config.params).to.be.empty
                })
            })
        })

        describe('multiple calls', () => {
            let mock: MockAdapter
            let params1: ApiConfigParam
            let apiCall1: ApiCall
            let call2Data: object
            let apiCall2: ApiCall

            before(() => {
                params1 = {
                    filters: 'AccountInternalId==1234'
                }
                apiCall1 = {
                    apiName: 'accountGetByFilter',
                    params: params1
                }
                call2Data = {
                    billFname: 'Alex',
                    billLname: 'Hamilton'
                }
                apiCall2 = {
                    apiName: 'accountUpdate',
                    data: call2Data,
                    pathParams: {
                        AccountInternalId: '1234'
                    }
                }
                mock = new MockAdapter(axios)
                mock.onAny().reply((config) => {
                    return new Promise((resolve, reject) => {
                        resolve([OK])
                    })
                })
            })

            it('should make multiple API calls', () => {
                apiHandler.setApiConfig(fullConfig.restApiConfig)
                const calls = [apiCall1, apiCall2]

                return apiHandler.callRestApis(calls).then((response) => {
                    expect(response.length).to.equal(calls.length, 'response.length')
                    expect(response[0].config.url).to.equal('https://apiman:8443/apiman-gateway/Optima/customeraccounts/1.0')
                    expect(response[0].config.method).to.equal('get')
                    expect(response[0].config.params.filters).to.equal(params1.filters)
                    expect(response[0].config.data).to.equal(undefined, 'response[0].config.data')
                    expect(response[1].config.url).to.equal('https://localhost:8080/rest/v1/customeraccounts/1234')
                    expect(response[1].config.method).to.equal('put')
                    expect(response[1].config.params).to.be.empty
                    const data = JSON.parse(response[1].config.data)
                    expect(data).to.deep.equal(call2Data)
                })
            })
        })

        describe('invalid API', () => {
            let mock: MockAdapter
            let apiCall: ApiCall

            before(() => {
                apiCall = {
                    apiName: 'undefinedAPI',
                    data: {
                        nosuchValue: true
                    },
                    params: {
                        filters: 'AccountInternalId==1234'
                    }
                }
                mock = new MockAdapter(axios)
                mock.onAny().reply((config) => {
                    return new Promise((resolve, reject) => {
                        resolve([OK])
                    })
                })
            })

            it('should return an error', () => {
                apiHandler.setApiConfig(fullConfig.restApiConfig)

                return apiHandler.callRestApi(apiCall).then((response) => {
                    expect.fail('failure', 'success', 'API Call succeeded when it should have failed')
                }).catch((error) => {
                    expect(error.toString()).to.equal('Error: API undefinedAPI is not configured for use by the application.  Please add it to the REST API configuration.', 'error')
                })
            })
        })

        describe('API headers', () => {
            let mock: MockAdapter
            let apiCall: ApiCall

            before(() => {
                apiCall = {
                    apiName: 'accountGetById',
                    headers: {
                        MyHeader: 'My Header Value'
                    },
                    pathParams: {
                        AccountInternalId: 1234,
                    }
                }
                mock = new MockAdapter(axios)
                mock.onAny().reply((config) => {
                    return new Promise((resolve, reject) => {
                        resolve([OK])
                    })
                })
            })

            it('should use merged headers', () => {
                apiHandler.setApiConfig(fullConfig.restApiConfig)

                return apiHandler.callRestApi(apiCall).then((response) => {
                    expect(response.config.url).to.equal('https://apiman:8443/apiman-gateway/Optima/customeraccounts/1.0/1234')
                    expect(response.config.method).to.equal('get')
                    delete response.config.headers.Accept
                    expect(response.config.headers).to.deep.equal({ ...apiHandler.apiConfig.headers, ...apiCall.headers })
                })
            })
        })
    })
})
