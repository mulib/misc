'use strict'
import axios, { AxiosRequestConfig, AxiosResponse } from 'axios'
import * as _ from 'lodash'
import uuid = require('uuid/v4')

export interface ApiConfigHeader { [headerName: string]: string | number }
export interface ApiConfigParam { [queryParamName: string]: string | number | boolean | Date | {} }
export interface ApiConfigPathParam { [pathParamName: string]: string | number }

export interface ApiConfig {
    apis?: { [apiName: string]: ApiDefinition }
    defaultServer?: string
    headers?: ApiConfigHeader
    servers?: { [serverName: string]: { apiVersion?: string, baseUrl: string, contractVersion?: string } }
    timeout?: number,
    TransactionId?: string
}

export interface ApiDefinition {
    api?: string
    apiVersion?: string
    baseUrl?: string
    contractVersion?: string
    method?: string
    path?: string
    server?: string
}

export const defaultApiConfig: ApiConfig = {
    apis: {},
    servers: {}
}


export interface ApiCall {
    apiName: string,
    data?: {},
    headers?: ApiConfigHeader,
    onUploadProgress?: (progressEvent: { loaded: number, total: number }) => void
    params?: ApiConfigParam,
    pathParams?: ApiConfigPathParam,
}

/**
 * Returns the server that an Api points to. If a specific server is defined at the api level, it will be used, otherwise we fall back to the global configuration's defaultServer
 * @param apiDef
 * @param apiConfig
 */
export const getServerName = (apiDef: ApiDefinition, apiConfig: ApiConfig): string => {
    if (apiDef.server) {
        return apiDef.server
    } else {
        return _.get(apiConfig, ['defaultServer'], '') as string
    }
}

/**
 * Returns the baseUrl for the API. If a specific baseUrl is defined at the API Level, it is used.
 * Otherwise, we check if there is a baseUrl in the server configuration
 * If nothing found, the baseUrl is the empty string
 * @param apiDef
 * @param apiConfig
 */
export const getBaseUrl = (apiDef: ApiDefinition, apiConfig: ApiConfig): string => {
    if (apiDef.baseUrl) {
        return apiDef.baseUrl
    } else {
        const serverName = getServerName(apiDef, apiConfig)

        return _.get(apiConfig, ['servers', serverName, 'baseUrl'], '')
    }
}

/**
 * Returns the apiVersion for the API. If a specific apiVersion is defined at the API Level, it is used.
 * Otherwise, we check if there is a apiVersion in the server configuration
 * If nothing found, return undefined
 * @param apiDef
 * @param apiConfig
 */
export const getApiVersion = (apiDef: ApiDefinition, apiConfig: ApiConfig): string => {
    if (apiDef.apiVersion) {
        return apiDef.apiVersion
    } else {
        const serverName = getServerName(apiDef, apiConfig)

        return _.get(apiConfig, ['servers', serverName, 'apiVersion'], undefined)
    }
}

/**
 * Returns the contractVersion for the API. If a specific contractVersion is defined at the API Level, it is used.
 * Otherwise, we check if there is one in the server configuration
 * If nothing found, we return undefined
 * @param apiDef
 * @param apiConfig
 */
export const getContractVersion = (apiDef: ApiDefinition, apiConfig: ApiConfig): string | undefined => {
    if (apiDef.contractVersion) {
        return apiDef.contractVersion
    } else {
        const serverName = getServerName(apiDef, apiConfig)

        return _.get(apiConfig, ['servers', serverName, 'contractVersion'], undefined)
    }
}

export class APIHandler {
    apiConfig: ApiConfig
    static singleton: APIHandler

    constructor() {
        this.apiConfig = defaultApiConfig
    }

    static get instance() {
        if (!APIHandler.singleton) {
            APIHandler.singleton = new APIHandler()
        }

        return APIHandler.singleton
    }

    setApiConfig = (apiConfig: ApiConfig) => {
        this.apiConfig = _.merge({}, this.apiConfig, apiConfig)
        if (this.apiConfig.headers) {
            if (!this.apiConfig.headers.TransactionId) {
                this.apiConfig.headers.TransactionId = uuid()
            }
        } else {
            this.apiConfig.headers = { TransactionId: uuid() }
        }
    }

    callRestApis = (apisToCall: ApiCall[]): Promise<AxiosResponse[]> => {
        const promises: Promise<AxiosResponse>[] = apisToCall.map((api) => {
            return this.callRestApi(api)
        })

        return axios.all(promises)
    }

    callRestApi = (apiToCall: ApiCall): Promise<AxiosResponse> => {
        const apiDef: ApiDefinition | undefined = _.get(this.apiConfig, ['apis', apiToCall.apiName])
        const onUploadProgress = apiToCall.onUploadProgress

        if (apiDef) {
            let path = apiDef.path
            if (path && apiToCall.pathParams) {
                const compiled = _.template(path, { interpolate: /{([\s\S]+?)}/g })
                path = compiled(apiToCall.pathParams)
            }

            const server = getServerName(apiDef, this.apiConfig)
            let url = getBaseUrl(apiDef, this.apiConfig)
            const contractVersion = getContractVersion(apiDef, this.apiConfig)
            const apiVersion = getApiVersion(apiDef, this.apiConfig)

            url = `${url}/`

            if (apiVersion) {
                url = `${url}${apiVersion}`
                if (!contractVersion) {
                    url = `${url}/`
                }
            }

            url = `${url}${apiDef.api}`

            if (contractVersion) {
                url = `${url}/${contractVersion}`
            }

            if (path) {
                url = `${url}/${path}`
            }

            const myConfig: AxiosRequestConfig = { onUploadProgress: apiToCall.onUploadProgress, url: url, method: apiDef.method, timeout: this.apiConfig.timeout, headers: { ...this.apiConfig.headers, ...apiToCall.headers }, params: { ...apiToCall.params }, data: apiToCall.data }

            return axios.request(myConfig)
        } else {
            return new Promise<AxiosResponse>((resolve, reject) => {
                reject(Error(`API ${apiToCall.apiName} is not configured for use by the application.  Please add it to the REST API configuration.`))
            })
        }
    }
}

const apiHandler = APIHandler.instance
export default apiHandler
