import { Action } from 'redux'
import { should } from 'chai'
should()
import * as sinon from 'sinon'
import { AxiosResponse } from 'axios'

import * as actions from './enumerationsActions'
import * as types from '../model/enumerationsTypes'
import { Enumeration } from '../../..'

import apiHandler from '../../../utilities/APIHandler'


describe('CommonManagement', () => {
    describe('actions', () => {
        describe('the EnumerationsSuccessAction Action creator', () => {
            let _action: actions.EnumerationsSuccessAction
            let json: types.EnumerationsResponseType

            before(() => {
                json = require('../data/SingleEnumeration.json')
                _action = actions.enumerationsSuccessAction(['AccountCategory'], json.response as Enumeration[], json.totalCount)
            })

            it('should return an action of type SUCCESS_ENUMERATIONS', () => {
                _action.type.should.equal(actions.SUCCESS_ENUMERATIONS)
            })

            it('should contain the totalCount from the parameters', () => {
                _action.should.have.property('totalCount', json.totalCount)
            })

            it('should contain the Enumeration in its payload', () => {
                _action.should.have.property('payload').to.deep.equal(json.response)
            })

            it('should contain the list of enumeration names in its payload', () => {
                _action.should.have.property('enumerationList').to.deep.equal(['AccountCategory'])
            })
        })

        describe('the EnumerationsFailureAction Action creator', () => {
            let _action: actions.EnumerationsFailureAction
            let _message: string

            before(() => {
                _message = 'Sorry, Mario, your resource is in another castle :('
                _action = actions.enumerationsFailureAction(['enumeration'], _message)
            })

            it('should return an action of type FAILURE_ENUMERATIONS', () => {
                _action.type.should.equal(actions.FAILURE_ENUMERATIONS)
            })

            it('should contain the error message in its payload', () => {
                _action.message.should.deep.equal(_message)
            })

            it('should contain the list of enumeration names in its payload', () => {
                _action.should.have.property('enumerationList').to.deep.equal(['enumeration'])
            })
        })

        describe('the Enumerations action helper', () => {
            context('given a successful resolution', () => {
                let _dispatch: sinon.SinonStub
                let _res: AxiosResponse
                let _response: types.EnumerationsResponseType
                let _callRestApi: sinon.SinonStub
                let _queryParams: {}
                let _headers: {}
                const TOTAL_COUNT = 200
                const STATUS = 200
                const SERVER_ID = 2
                const ACCOUNT_INTERNAL_ID = 1

                before(() => {
                    _response = require('../data/MultipleEnumerations.json')
                    _queryParams = { enumerationlist: 'AccountCategory,RateCurrency' }
                    _headers = { serverId: SERVER_ID }
                    _dispatch = sinon.stub()
                    _callRestApi = sinon.stub(apiHandler, 'callRestApi')
                    _res = {
                        config: {},
                        data: _response,
                        headers: undefined,
                        status: STATUS,
                        statusText: ''
                    }
                    _callRestApi.returns(new Promise<AxiosResponse>((resolve, reject) => {
                        resolve(_res)
                    }))
                })

                after(() => {
                    _callRestApi.restore()
                })

                it('should dispatch a begin action, call the enumerations API and dispatch a SUCCESS_ENUMERATIONS action with the response value in its payload', () => {
                    return actions.enumerations(_dispatch, _queryParams, _headers)
                        .then(response => {
                            const ExpectedCallCount = 2
                            _dispatch.callCount.should.equal(ExpectedCallCount)
                            const beginAction = _dispatch.args[0][0] as Action
                            beginAction.type.should.equal(actions.BEGIN_ENUMERATIONS)
                            const action: actions.EnumerationsSuccessAction = _dispatch.args[1][0]
                            action.type.should.equal(actions.SUCCESS_ENUMERATIONS)
                            action.should.have.property('payload').to.deep.equal(_response.response)
                            action.should.have.property('totalCount', _response.totalCount)
                        })
                        .catch(error => {
                            throw new Error(`The Call should have been successful. Error: ${JSON.stringify(error)}`)
                        })
                })
            })

            context('given an unsuccessful resolution', () => {
                let _dispatch: sinon.SinonStub
                let _response: types.EnumerationsResponseType
                let _callRestApi: sinon.SinonStub
                let _queryParams: {}
                let _headers: {}
                const LIMIT = 100
                const SERVER_ID = 2
                const ACCOUNT_INTERNAL_ID = 1

                before(() => {
                    _response = {
                        code: 12345,
                        message: 'ERROR'
                    }
                    _queryParams = { enumerationlist: 'AccountCategory' }
                    _headers = { serverId: SERVER_ID }
                    _dispatch = sinon.stub()
                    _callRestApi = sinon.stub(apiHandler, 'callRestApi')
                    _callRestApi.returns(new Promise<AxiosResponse>((resolve, reject) => {
                        reject({ status: 404, response: { data: _response } })
                    }))
                })

                after(() => {
                    _callRestApi.restore()
                })

                it('should dispatch a begin action, call the enumerations API and dispatch a FAILURE_ENUMERATIONS action with the error message', () => {
                    return actions.enumerations(_dispatch, _queryParams, _headers)
                        .then(response => {
                            throw new Error(`The Call should not have been successful. response: ${JSON.stringify(response)}`)
                        })
                        .catch(error => {
                            const EXPECTED_CALL_COUNT = 2
                            _dispatch.callCount.should.equal(EXPECTED_CALL_COUNT)
                            const action: actions.EnumerationsFailureAction = _dispatch.args[1][0]
                            action.type.should.equal(actions.FAILURE_ENUMERATIONS)
                            action.message.should.equal(_response.message)
                        })
                })
            })

            context('given a network error', () => {
                let _dispatch: sinon.SinonStub
                let _response: string
                let _callRestApi: sinon.SinonStub
                let _queryParams: {}
                let _headers: {}
                const LIMIT = 100
                const SERVER_ID = 2
                const ACCOUNT_INTERNAL_ID = 1

                before(() => {
                    _response = 'Error occured while trying to access API'
                    _queryParams = { enumerationlist: 'AccountCategory' }
                    _headers = { serverId: SERVER_ID }
                    _dispatch = sinon.stub()
                    _callRestApi = sinon.stub(apiHandler, 'callRestApi')
                    _callRestApi.returns(new Promise<AxiosResponse>((resolve, reject) => {
                        reject(_response)
                    }))
                })

                after(() => {
                    _callRestApi.restore()
                })

                it('should dispatch a begin action, call the enumerations API and dispatch a FAILURE_ENUMERATIONS action with the error message', () => {
                    return actions.enumerations(_dispatch, _queryParams, _headers)
                        .then(response => {
                            throw new Error(`The Call should not have been successful. response: ${JSON.stringify(response)}`)
                        })
                        .catch(error => {
                            const EXPECTED_CALL_COUNT = 2
                            _dispatch.callCount.should.equal(EXPECTED_CALL_COUNT)
                            const action: actions.EnumerationsFailureAction = _dispatch.args[1][0]
                            action.type.should.equal(actions.FAILURE_ENUMERATIONS)
                            action.should.have.property('message', _response, 'incorrect error response')
                        })
                })
            })

            context('given a network error with response', () => {
                interface Error {
                    response: string
                }

                let _dispatch: sinon.SinonStub
                let _response: Error
                let _callRestApi: sinon.SinonStub
                let _queryParams: {}
                let _headers: {}
                const SERVER_ID = 2
                const ACCOUNT_INTERNAL_ID = 1

                before(() => {
                    _response = { response: 'Error occured while trying to access API' }
                    _queryParams = { enumerationlist: 'AccountCategory' }
                    _headers = { serverId: SERVER_ID }
                    _dispatch = sinon.stub()
                    _callRestApi = sinon.stub(apiHandler, 'callRestApi')
                    _callRestApi.returns(new Promise<AxiosResponse>((resolve, reject) => {
                        reject(_response)
                    }))
                })

                after(() => {
                    _callRestApi.restore()
                })

                it('should dispatch a begin action, call the enumerations API and dispatch a FAILURE_ENUMERATIONS action with the error message', () => {
                    return actions.enumerations(_dispatch, _queryParams, _headers)
                        .then(response => {
                            throw new Error(`The Call should not have been successful. response: ${JSON.stringify(response)}`)
                        })
                        .catch(error => {
                            const EXPECTED_CALL_COUNT = 2
                            _dispatch.callCount.should.equal(EXPECTED_CALL_COUNT)
                            const action: actions.EnumerationsFailureAction = _dispatch.args[1][0]
                            action.type.should.equal(actions.FAILURE_ENUMERATIONS)
                            action.should.have.property('message', _response.response, 'incorrect error response')
                        })
                })
            })

            context('given no enumeration names passed', () => {
                interface Error {
                    response: string
                }

                let _dispatch: sinon.SinonStub
                let _response: Error
                let _callRestApi: sinon.SinonStub
                let _queryParams: {}
                let _headers: {}
                const SERVER_ID = 2
                const ACCOUNT_INTERNAL_ID = 1

                before(() => {
                    _response = { response: 'Error occured while trying to access API' }
                    _queryParams = {}
                    _headers = { serverId: SERVER_ID }
                    _dispatch = sinon.stub()
                    _callRestApi = sinon.stub(apiHandler, 'callRestApi')
                    _callRestApi.returns(new Promise<AxiosResponse>((resolve, reject) => {
                        reject(_response)
                    }))
                })

                after(() => {
                    _callRestApi.restore()
                })

                it('should dispatch a begin action, call the enumerations API and dispatch a FAILURE_ENUMERATIONS action with the error message', () => {
                    return actions.enumerations(_dispatch, _queryParams, _headers)
                        .then(response => {
                            throw new Error(`The Call should not have been successful. response: ${JSON.stringify(response)}`)
                        })
                        .catch(error => {
                            error.should.equal('One or more enumeration names must be specified')
                        })
                })
            })
        })
    })
})
