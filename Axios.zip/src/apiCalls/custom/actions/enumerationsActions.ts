import { Action, Dispatch } from 'redux'
import { CustomState } from '../state/CustomState'
import { AxiosPromise, AxiosResponse } from 'axios'
import apiHandler, { ApiCall, ApiConfigHeader, ApiConfigParam, ApiConfigPathParam } from '../../../utilities/APIHandler'

import { Enumeration } from '../../..'
import { EnumerationsResponseType } from '../model/enumerationsTypes'

export const BEGIN_ENUMERATIONS = '@@CommonManagement/BEGIN_ENUMERATIONS'
export const SUCCESS_ENUMERATIONS = '@@CommonManagement/SUCCESS_ENUMERATIONS'
export const FAILURE_ENUMERATIONS = '@@CommonManagement/FAILURE_ENUMERATIONS'
export const RESET_STATUS_ENUMERATIONS = '@@CommonManagement/RESET_STATUS_ENUMERATIONS'

/**
* Action dispatched in order to indicate we are starting the enumerations API call
*/
export interface EnumerationsBeginAction extends Action {
    enumerationList: string[]
}

/**
 * Action dispatched to indicate the enumerations API call was successful
 */
export interface EnumerationsSuccessAction extends Action {
    enumerationList: string[],
    payload: Enumeration[]
    totalCount?: number
}

/**
 * Action dispatched to indicate the enumerations API call was unsuccessful
 */
export interface EnumerationsFailureAction extends Action {
    enumerationList: string[],
    message: string
}

/**
* Action dispatched in order to reset the enumerations API call status.
* Mostly useful in case of create, update and delete situations, where we will want a 'clean slate' for every new operation.
*/
export interface EnumerationsResetStatusAction extends Action {
    enumerationList: string[]
}

/**
 * 'Begin' Action creator for the the enumerations API call
 * @param enums list of enumerations to be retrieved
 * @return a @type{EnumerationsBeginAction} with the data in its payload
 */
export const enumerationsBeginAction = (enums: string[]): EnumerationsBeginAction => ({
    enumerationList: enums,
    type: BEGIN_ENUMERATIONS
})

/**
 * 'Success' Action creator for the the enumerationList API call
 * @param enums List of enumerations that were supposed to be retrieved
 * @param data the output of the API call
 * @return a @type{EnumerationsSuccessAction} with the data in its payload
 */
export const enumerationsSuccessAction = (enums: string[], data: Enumeration[], totalCount?: number): EnumerationsSuccessAction => ({
    enumerationList: enums,
    payload: data,
    totalCount: totalCount,
    type: SUCCESS_ENUMERATIONS
})

/**
 * 'Failure' Action creator for the the enumerations API call
 * @param enums List of enumerations that were supposed to be retrieved
 * @param data the output of the API call
 * @return a @type{EnumerationsFailureAction} with the data in its payload
 */
export const enumerationsFailureAction = (enums: string[], message: string): EnumerationsFailureAction => ({
    enumerationList: enums,
    message: message,
    type: FAILURE_ENUMERATIONS
})


/**
 * 'Reset' Action creator for the the enumerations API call
 * @param enums list of enumerations to be reset
 * @return a @type{EnumerationsBeginAction} with the data in its payload
 */
export const enumerationsResetStatusAction = (enums: string[]): EnumerationsResetStatusAction => ({
    enumerationList: enums,
    type: RESET_STATUS_ENUMERATIONS
})

/**
 * Action Helper that executes the API call and dispatches the relevant actions when necessary
 */
export const enumerations = (dispatch: Dispatch<CustomState>, queryParams: ApiConfigParam, headers?: ApiConfigHeader): Promise<AxiosResponse> => {
    if (!queryParams['enumerationlist']) {
        return new Promise<AxiosResponse>((resolve, reject) => { reject('One or more enumeration names must be specified') })
    }

    const call: ApiCall = {
        apiName: 'enumerations',
        headers: headers,
        params: queryParams
    }

    const enums: string = queryParams['enumerationlist'] as string
    const enumArray: string[] = enums.split(',')

    dispatch(enumerationsBeginAction(enumArray))

    return apiHandler.callRestApi(call)
        .then((callResponse: AxiosResponse) => {
            const enumerationsDataResponse = callResponse.data as EnumerationsResponseType
            const response: Enumeration[] = enumerationsDataResponse.response as Enumeration[]
            dispatch(enumerationsSuccessAction(enumArray, response, enumerationsDataResponse.totalCount))

            return callResponse
        })
        .catch(error => {
            dispatch(enumerationsFailureAction(enumArray, error.response ? error.response.data ? error.response.data.message : error.response : error))

            return new Promise<AxiosResponse>((resolve, reject) => { reject(error) })
        } )
}
