import { combineReducers, Reducer } from 'redux'

import { EnumerationsState } from '../model/enumerationsTypes'
import { enumerationsInitialState, enumerationsReducer } from '../reducers/enumerationsMain'

export interface CustomState {
    enumerations: EnumerationsState
}
export const customInitialState: CustomState = {
    enumerations: enumerationsInitialState
}
export const customReducer: Reducer<CustomState> = combineReducers<CustomState>({
    enumerations: enumerationsReducer
})
