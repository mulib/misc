import * as _ from 'lodash'
import { expect, should } from 'chai'
should()

import { Enumeration, EnumerationKeyValue, EnumerationField } from '../../..'
import { EnumerationsState, EnumerationsResponseType } from '../model/enumerationsTypes'
import { enumerationsInitialState } from './enumerationsMain'
import * as actions from '../actions/enumerationsActions'
import * as reducers from './enumerationsReducers'

describe('CommonManagement', () => {
    describe('reducers', () => {
        describe('enumerationsBeginActionReducer', () => {
            let _initState: EnumerationsState
            let _newState: EnumerationsState

            context('given an existing initial state', () => {
                before(() => {
                    _initState = enumerationsInitialState
                    _newState = reducers.enumerationsBeginActionReducer(_initState, actions.enumerationsBeginAction(['enumeration']))
                })
                it('should set the callStatus loading flag to true for the enumerations method in the response', () => {
                    _newState.should.have.property('enumeration').to.have.property('callStatus').that.has.property('loading', true, 'call status not loading')
                })
            })
        })

        describe('enumerationsSuccessActionReducer, single enumeration', () => {
            let _initState: EnumerationsState
            let _newState: EnumerationsState
            let action: actions.EnumerationsSuccessAction
            let _data: EnumerationsResponseType
            const TOTAL_COUNT = 200
            let _response: Enumeration[]

            before(() => {
                _data = require('../data/SingleEnumeration.json')
                action = actions.enumerationsSuccessAction(['AccountCategory'], _data.response as Enumeration[], _data.totalCount)
                const { response = [{}] } = _data
                _response = response
            })

            context('given an existing state with different values in it', () => {
                before(() => {
                    _initState = {
                        ['AccountCategory']: {
                            callStatus: {
                                loading: true,
                                success: false
                            },
                            response: {},
                            totalCount: TOTAL_COUNT
                        }
                    }
                    _newState = reducers.enumerationsSuccessActionReducer(_initState, action)
                })

                it('should set the callStatus loading flag to false for the enumerations method in the response', () => {
                    _newState.should.have.property('AccountCategory').that.has.property('callStatus').that.has.property('loading', false, 'call status loading')
                })

                it('should set the callStatus success flag to true for the enumerations method in the response', () => {
                    _newState.should.have.property('AccountCategory').that.has.property('callStatus').that.has.property('success', true, 'call status not success')
                })

                it('should add the totalCount from the action into the state', () => {
                    const { enumerationData = [] } = _response[0]
                    _newState.should.have.property('AccountCategory').that.has.property('totalCount', enumerationData.length, 'total count not correct')
                })

                it('should add the data from the action into the state', () => {
                    const { response = [{}] } = _data
                    _newState.should.have.property('AccountCategory').that.has.property('response').deep.equal(response[0])
                })
            })
        })

        describe('enumerationsSuccessActionReducer, multiple enumerations', () => {
            let _initState: EnumerationsState
            let _newState: EnumerationsState
            let action: actions.EnumerationsSuccessAction
            let _data: EnumerationsResponseType
            let _response: Enumeration[]

            before(() => {
                _data = require('../data/MultipleEnumerations.json')
                action = actions.enumerationsSuccessAction(['AccountCategory', 'RateCurrency', 'NoData'], _data.response as Enumeration[], _data.totalCount)
                const { response = [{}] } = _data
                _response = response
            })

            context('given an existing state with different values in it', () => {
                before(() => {
                    const TOTAL_COUNT = 200
                    _initState = {
                        ['AccountCategory']: {
                            callStatus: {
                                loading: true,
                                success: false
                            },
                            response: {},
                            totalCount: TOTAL_COUNT
                        }
                    }
                    _newState = reducers.enumerationsSuccessActionReducer(_initState, action)
                })

                it('should set the callStatus loading flag to false for the enumerations method in the response', () => {
                    _newState.should.have.property('AccountCategory').that.has.property('callStatus').that.has.property('loading', false, 'call status loading')
                    _newState.should.have.property('RateCurrency').that.has.property('callStatus').that.has.property('loading', false, 'call status loading')
                    _newState.should.have.property('NoData').that.has.property('callStatus').that.has.property('loading', false, 'call status loading')
                })

                it('should set the callStatus success flag to true for the enumerations method in the response', () => {
                    _newState.should.have.property('AccountCategory').that.has.property('callStatus').that.has.property('success', true, 'call status not success')
                    _newState.should.have.property('RateCurrency').that.has.property('callStatus').that.has.property('success', true, 'call status not success')
                    _newState.should.have.property('NoData').that.has.property('callStatus').that.has.property('success', true, 'call status not success')
                })

                it('should add the totalCount from the action into the state', () => {
                    {
                        const { enumerationData = [] } = _response[0]
                        _newState.should.have.property('AccountCategory').that.has.property('totalCount', enumerationData.length, 'total count not correct')
                    }
                    {
                        const { enumerationData = [] } = _response[1]
                        _newState.should.have.property('RateCurrency').that.has.property('totalCount', enumerationData.length, 'total count not correct')
                    }
                    _newState.should.have.property('NoData').that.has.property('totalCount', 0, 'total count not correct')
                })

                it('should add the data from the action into the state', () => {
                    const { response = [{}] } = _data
                    _newState.should.have.property('AccountCategory').that.has.property('response').deep.equal(response[0])
                    _newState.should.have.property('RateCurrency').that.has.property('response').deep.equal(response[1])
                    _newState.should.have.property('NoData').that.not.has.property('response')
                })
            })
        })

        describe('enumerationsSuccessActionReducer, generic enumeration', () => {
            let _initState: EnumerationsState
            let _newState: EnumerationsState
            let action: actions.EnumerationsSuccessAction
            let _data: EnumerationsResponseType
            const TOTAL_COUNT = 200

            before(() => {
                _data = require('../data/GenericEnumeration.json')
                action = actions.enumerationsSuccessAction(['GenericEnumeration'], _data.response as Enumeration[], _data.totalCount)
            })

            context('given an existing state with different values in it', () => {
                before(() => {
                    _initState = {
                        ['AccountCategory']: {
                            callStatus: {
                                loading: true,
                                success: false
                            },
                            response: {},
                            totalCount: TOTAL_COUNT
                        }
                    }
                    _newState = reducers.enumerationsSuccessActionReducer(_initState, action)
                })

                it('should set the callStatus loading flag to false for the enumerations method in the response', () => {
                    _newState.should.have.property('GenericEnumeration').that.has.property('callStatus').that.has.property('loading', false, 'call status loading')
                    _newState.should.have.property('package_status').that.has.property('callStatus').that.has.property('loading', false, 'call status loading')
                    _newState.should.have.property('tz_timezones').that.has.property('callStatus').that.has.property('loading', false, 'call status loading')
                })

                it('should set the callStatus success flag to true for the enumerations method in the response', () => {
                    _newState.should.have.property('GenericEnumeration').that.has.property('callStatus').that.has.property('success', true, 'call status not success')
                    _newState.should.have.property('package_status').that.has.property('callStatus').that.has.property('success', true, 'call status not success')
                    _newState.should.have.property('tz_timezones').that.has.property('callStatus').that.has.property('success', true, 'call status not success')
                })

                it('should add the totalCount from the action into the state', () => {
                    const GE_COUNT = 13
                    const PACKAGE_STATUS_COUNT = 3
                    const TZ_COUNT = 10
                    _newState.should.have.property('GenericEnumeration').that.has.property('totalCount', GE_COUNT, 'total count not correct')
                    _newState.should.have.property('package_status').that.has.property('totalCount', PACKAGE_STATUS_COUNT, 'total count not correct')
                    _newState.should.have.property('tz_timezones').that.has.property('totalCount', TZ_COUNT, 'total count not correct')
                })

                it('should add the data from the action into the state', () => {
                    const { response = [{}] } = _data
                    _newState.should.have.property('GenericEnumeration').that.should.not.have.property('response')
                    const packageStatus = responseFilter(response[0].enumerationData as EnumerationKeyValue[], [{ fieldName: 'EnumerationKey', fieldValue: 'package_status' }])
                    _newState.should.have.property('package_status').that.has.property('response').that.has.property('enumerationData').deep.equals(packageStatus, 'pacakge_status data not correct')
                    const tzTimezones = responseFilter(response[0].enumerationData as EnumerationKeyValue[], [{ fieldName: 'EnumerationKey', fieldValue: 'tz_timezones' }])
                    _newState.should.have.property('tz_timezones').that.has.property('response').that.has.property('enumerationData').deep.equals(tzTimezones, 'tz_timeezones data not correct')
                })
            })
        })

        describe('enumerationsSuccessActionReducer, GUI indicator', () => {
            let _initState: EnumerationsState
            let _newState: EnumerationsState
            let action: actions.EnumerationsSuccessAction
            let _data: EnumerationsResponseType
            const TOTAL_COUNT = 200

            before(() => {
                _data = require('../data/GuiIndicator.json')
                action = actions.enumerationsSuccessAction(['GenericEnumeration'], _data.response as Enumeration[], _data.totalCount)
            })

            context('given an existing state with different values in it', () => {
                before(() => {
                    _initState = {
                        ['AccountCategory']: {
                            callStatus: {
                                loading: true,
                                success: false
                            },
                            response: {},
                            totalCount: TOTAL_COUNT
                        }
                    }
                    _newState = reducers.enumerationsSuccessActionReducer(_initState, action)
                })

                it('should set the callStatus loading flag to false for the enumerations method in the response', () => {
                    _newState.should.have.property('GuiIndicator').that.has.property('callStatus').that.has.property('loading', false, 'call status loading')
                    _newState.should.have.property('CMF:account_status').that.has.property('callStatus').that.has.property('loading', false, 'call status loading')
                    _newState.should.have.property('CMF:account_type').that.has.property('callStatus').that.has.property('loading', false, 'call status loading')
                    _newState.should.have.property('CMF:pay_method').that.has.property('callStatus').that.has.property('loading', false, 'call status loading')
                    _newState.should.have.property('CMF:network_reason').that.has.property('callStatus').that.has.property('loading', false, 'call status loading')
                    _newState.should.have.property('ACCOUNT_BALANCES:authorization_flag').that.has.property('callStatus').that.has.property('loading', false, 'call status loading')
                })

                it('should set the callStatus success flag to true for the enumerations method in the response', () => {
                    _newState.should.have.property('GuiIndicator').that.has.property('callStatus').that.has.property('success', true, 'call status not success')
                    _newState.should.have.property('CMF:account_status').that.has.property('callStatus').that.has.property('success', true, 'call status not success')
                    _newState.should.have.property('CMF:account_type').that.has.property('callStatus').that.has.property('success', true, 'call status not success')
                    _newState.should.have.property('CMF:pay_method').that.has.property('callStatus').that.has.property('success', true, 'call status not success')
                    _newState.should.have.property('CMF:network_reason').that.has.property('callStatus').that.has.property('success', true, 'call status not success')
                    _newState.should.have.property('ACCOUNT_BALANCES:authorization_flag').that.has.property('callStatus').that.has.property('success', true, 'call status not success')
                })

                it('should add the totalCount from the action into the state', () => {
                    const GUI_INDICATOR_COUNT = 20
                    const ACCOUNT_STATUS_COUNT = 5
                    const ACCOUNT_TYPE_COUNT = 2
                    const PAY_METHOD_COUNT = 4
                    const NETWORK_REASON_COUNT = 6
                    const AUTHORIZATION_FLAG_COUNT = 3
                    _newState.should.have.property('GuiIndicator').that.has.property('totalCount', GUI_INDICATOR_COUNT, 'total count not correct')
                    _newState.should.have.property('CMF:account_status').that.has.property('totalCount', ACCOUNT_STATUS_COUNT, 'total count not correct')
                    _newState.should.have.property('CMF:account_type').that.has.property('totalCount', ACCOUNT_TYPE_COUNT, 'total count not correct')
                    _newState.should.have.property('CMF:pay_method').that.has.property('totalCount', PAY_METHOD_COUNT, 'total count not correct')
                    _newState.should.have.property('CMF:network_reason').that.has.property('totalCount', NETWORK_REASON_COUNT, 'total count not correct')
                    _newState.should.have.property('ACCOUNT_BALANCES:authorization_flag').that.has.property('totalCount', AUTHORIZATION_FLAG_COUNT, 'total count not correct')
                })

                it('should add the data from the action into the state', () => {
                    const { response = [{}] } = _data
                    _newState.should.have.property('GuiIndicator').that.should.not.have.property('response')
                    const accountStatus = responseFilter(response[0].enumerationData as EnumerationKeyValue[], [{ fieldName: 'TableName', fieldValue: 'CMF' }, { fieldName: 'FieldName', fieldValue: 'account_status' }])
                    _newState.should.have.property('CMF:account_status').that.has.property('response').that.has.property('enumerationData').deep.equals(accountStatus, 'account_status data not correct')
                    const accountType = responseFilter(response[0].enumerationData as EnumerationKeyValue[], [{ fieldName: 'TableName', fieldValue: 'CMF' }, { fieldName: 'FieldName', fieldValue: 'account_type' }])
                    _newState.should.have.property('CMF:account_type').that.has.property('response').that.has.property('enumerationData').deep.equals(accountType, 'account_type data not correct')
                    const payMethod = responseFilter(response[0].enumerationData as EnumerationKeyValue[], [{ fieldName: 'TableName', fieldValue: 'CMF' }, { fieldName: 'FieldName', fieldValue: 'pay_method' }])
                    _newState.should.have.property('CMF:pay_method').that.has.property('response').that.has.property('enumerationData').deep.equals(payMethod, 'pay_method data not correct')
                    const networkReason = responseFilter(response[0].enumerationData as EnumerationKeyValue[], [{ fieldName: 'TableName', fieldValue: 'CMF' }, { fieldName: 'FieldName', fieldValue: 'network_reason' }])
                    _newState.should.have.property('CMF:network_reason').that.has.property('response').that.has.property('enumerationData').deep.equals(networkReason, 'network_reason data not correct')
                    const authorizationFlag = responseFilter(response[0].enumerationData as EnumerationKeyValue[], [{ fieldName: 'TableName', fieldValue: 'ACCOUNT_BALANCES' }, { fieldName: 'FieldName', fieldValue: 'authorization_flag' }])
                    _newState.should.have.property('ACCOUNT_BALANCES:authorization_flag').that.has.property('response').that.has.property('enumerationData').deep.equals(authorizationFlag, 'authorization_flag data not correct')
                })
            })
        })

        describe('enumerationsFailureActionReducer', () => {
            let _initState: EnumerationsState
            let _newState: EnumerationsState
            let action: actions.EnumerationsFailureAction
            let message: string

            before(() => {
                message = 'ERROR'
                action = actions.enumerationsFailureAction(['enumeration'], message)
            })

            context('given an existing state with different values in it', () => {
                before(() => {
                    _initState = {
                        enumeration: {
                            callStatus: {
                                loading: true,
                                message: 'SOMETHING_DIFFERENT',
                                success: true
                            }
                        }
                    }
                    _newState = reducers.enumerationsFailureActionReducer(_initState, action)
                })

                it('should set the callStatus loading flag to false for the enumerations method in the response', () => {
                    _newState.should.have.property('enumeration').that.has.property('callStatus').that.has.property('loading', false, 'call status loading')
                })

                it('should set the callStatus success flag to false for the enumerations method in the response', () => {
                    _newState.should.have.property('enumeration').that.has.property('callStatus').that.has.property('success', false, 'call status success')
                })

                it('should add the message from the action into the callStatus for the enumerations method', () => {
                    _newState.should.have.property('enumeration').that.has.property('callStatus').that.has.property('message', message, 'message not correct')
                })
            })
        })

        describe('enumerationsResetStatusActionReducer', () => {
            let _initState: EnumerationsState
            let _newState: EnumerationsState

            context('given an existing initial state', () => {
                before(() => {
                    _initState = enumerationsInitialState
                    _newState = reducers.enumerationsResetStatusActionReducer(_initState, actions.enumerationsResetStatusAction(['enumerations']))
                })
                it('should set the callStatus for the enumerations to undefined', () => {
                    _newState.should.not.have.property('enumeration')
                })
            })
        })
    })
})

const responseFilter = (response: EnumerationKeyValue[], keys: EnumerationField[]) => {
    const responseData = _.cloneDeep(response)
    const data = responseData.filter(keyValue => {
        const { keyData = [] } = keyValue
        let matching: EnumerationField[] = []
        keys.forEach(key => {
            matching = matching.concat(keyData.filter(kv => {
                return kv.fieldName === key.fieldName && kv.fieldValue === key.fieldValue
            }))
        })

        return keys.length === matching.length
    })

    return data.map(keyValue => {
        keys.forEach(key => {
            const { keyData = [] } = keyValue
            keyValue.keyData = keyData.filter(item => item.fieldName !== key.fieldName)
        })

        return keyValue
    })
}
