import { EnumerationsState } from '../model/enumerationsTypes'
import { Action, Reducer } from 'redux'
import * as actions from '../actions/enumerationsActions'
import * as reducers from './enumerationsReducers'

export const enumerationsInitialState: EnumerationsState = {}

/**
 * Action/Reducer mapping object. Each key is an Action Type, each value the reducer that needs to be invoked when matching.
 */
interface ReducerMapping {
    [a: string]: Reducer<EnumerationsState>
}

const actionReducerMapping: ReducerMapping = {
    [actions.BEGIN_ENUMERATIONS]: reducers.enumerationsBeginActionReducer,
    [actions.SUCCESS_ENUMERATIONS]: reducers.enumerationsSuccessActionReducer,
    [actions.FAILURE_ENUMERATIONS]: reducers.enumerationsFailureActionReducer,
    [actions.RESET_STATUS_ENUMERATIONS]: reducers.enumerationsResetStatusActionReducer
}

/**
 * the enumerations reducereducers. It takes from the array of reducers defined above to find the proper reducer to invoke, based on the action type.
 */
export const enumerationsReducer: Reducer<EnumerationsState> = (state: EnumerationsState = enumerationsInitialState, action: Action): EnumerationsState => {
    let newState = state
    if (action.type === 'USER_LOGOUT') {
        newState = enumerationsInitialState
    }
    const reducer: Reducer<EnumerationsState> = actionReducerMapping[action.type]
    if (reducer) {
        return reducer(newState, action)
    }

    return newState
}
