import { Action, Reducer } from 'redux'
import * as _ from 'lodash'

import { Enumeration, EnumerationKeyValue, EnumerationDataWrapper } from '../../..'
import { EnumerationsState } from '../model/enumerationsTypes'
import { enumerationsInitialState } from './enumerationsMain'
import * as actions from '../actions/enumerationsActions'

/**
 * Reducer for the BeginEnumerationsAction action
 * @param state the current state
 * @param action the BeginEnumerationsAction action
 * @return a new EnumerationsState with the loading flag set to true
 */
export const enumerationsBeginActionReducer: Reducer<EnumerationsState> = (state: EnumerationsState, action: Action) => {
    const newState = { ...state }
    const _action = action as actions.EnumerationsBeginAction

    _action.enumerationList.forEach(enumeration => {
        newState[enumeration] = { callStatus: { loading: true } }
    })

    return newState
}

/**
 * Reducer for the EnumerationsSuccessAction action
 * @param state the current state
 * @param action the EnumerationsSuccessAction action
 * @return a new EnumerationsState with the loading flag set to false, success to true, and the Enumeration from the payload in the state
 */
export const enumerationsSuccessActionReducer: Reducer<EnumerationsState> = (state: EnumerationsState, action: Action) => {
    const _action = action as actions.EnumerationsSuccessAction
    let newState: EnumerationsState = {}

    _action.payload.forEach(enumeration => {
        // istanbul ignore next
        const { enumerationName = '', enumerationData = [] } = enumeration
        newState[enumerationName] = { callStatus: { loading: false, success: true }, totalCount: enumerationData.length }
        if (enumerationName === 'GenericEnumeration') {
            newState = mapEnumeration(enumerationData, newState, ['EnumerationKey'])
        } else if (enumerationName === 'GuiIndicator') {
            newState = mapEnumeration(enumerationData, newState, ['TableName', 'FieldName'])
        } else {
            newState[enumerationName] = { ...newState[enumerationName], response: enumeration }
        }
    })

    Object.keys(newState).forEach(enumerationName => {
        const enumeration = newState[enumerationName].response as Enumeration
        if (enumeration) {
            const enumerationData = enumeration.enumerationData as EnumerationKeyValue[]
            newState[enumerationName].values = enumerationData.map((keyValue, index) => convertEnumerationValueSchema(keyValue))
        }
    })

    _action.enumerationList.forEach(name => {
        if (!newState[name]) {
            newState[name] = { callStatus: { loading: false, success: true }, totalCount: 0 }
        }
    })

    return { ...state, ...newState }
}

/**
 * Reducer for the EnumerationsFailureAction action
 * @param state the current state
 * @param action the EnumerationsFailureAction action
 * @return a new EnumerationsState with the loading flag set to false, success to false, and the message from the action in the state
 */
export const enumerationsFailureActionReducer: Reducer<EnumerationsState> = (state: EnumerationsState, action: Action) => {
    const _action = action as actions.EnumerationsFailureAction
    const newState = { ...state }
    _action.enumerationList.forEach(name => {
        newState[name] = { callStatus: { loading: false, success: false, message: _action.message } }
    })

    return newState
}

/**
 * Reducer for the EnumerationsResetStatusAction action
 * @param state the current state
 * @param action the EnumerationsResetStatusAction action
 * @return a new EnumerationsState with the enumeration undefined
 */
export const enumerationsResetStatusActionReducer: Reducer<EnumerationsState> = (state: EnumerationsState, action: Action) => {
    const _action = action as actions.EnumerationsResetStatusAction
    const newState = { ...state }
    _action.enumerationList.forEach(name => {
        delete newState[name]
    })

    return newState
}

/**
 * Takes the enumration and splits it into data indexed by the values of the specified key fields separated by a period,
 * and removes the specified key fields from the key. Used for GenericEnumeration and GuiIndicator to separate the data by key.
 * @param enumerationData the araray of GuiIndicator key/value data to convert
 * @param state the current Enumerations state
 * @param fieldNames the key field names
 * @returns new state with the data split
 */
const mapEnumeration = (enumerationData: EnumerationKeyValue[], state: EnumerationsState, fieldNames: string[]): EnumerationsState => {
    const enumerationState: EnumerationsState = {}
    enumerationData.forEach(keyValue => {
        const data = _.cloneDeep(keyValue)
        // istanbul ignore next
        const { keyData = [] } = data

        let name = ''
        fieldNames.forEach(fieldName => {
            const keyField = keyData.filter(key => key.fieldName === fieldName)

            const keyIndex = keyData.indexOf(keyField[0])
            keyData.splice(keyIndex, 1)

            name = name ? `${name}:${keyField[0].fieldValue}` : `${keyField[0].fieldValue}`
        })

        if (enumerationState[name]) {
            const enumerationKeyValue: EnumerationKeyValue = _.get(enumerationState, [name, 'response', 'enumerationData'], [])
            enumerationKeyValue.push(data)
            _.set(enumerationState, [name, 'totalCount'], enumerationKeyValue.length)
        } else {
            enumerationState[name] = {
                callStatus: { loading: false, success: true },
                response: {
                    enumerationData: [data],
                    enumerationName: name
                },
                totalCount: 1
            }
        }
    })

    return { ...state, ...enumerationState }
}

/**
 * Takes an enumeration value from an enumeration response, and convert it to an enumeration value where all keyData and valueData is transformed into field/value pairs in a simple JSON object
 * @param source the EnumerationValueSchema to convert
 * @returns an EnumerationValue object where the key is mapped to the value field, and all fieldName/fieldValue pairs are mapped to camelCased fieldName:fieldValue fields.
 */
const convertEnumerationValueSchema = (source: EnumerationKeyValue): EnumerationDataWrapper => {
    const result: EnumerationDataWrapper = {}

    // istanbul ignore next
    const { keyData = [], valueData = [] } = source

    keyData.forEach(key => {
        const name = _.camelCase(key.fieldName)
        result[name] = key.fieldValue as string
    })

    valueData.forEach(value => {
        const name = _.camelCase(value.fieldName)
        result[name] = value.fieldValue as string
    })

    // For compatability with CSR
    result['value'] = keyData[0].fieldValue
    result['label'] = result['displayValue']

    return result
}
