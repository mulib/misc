import { expect, should } from 'chai'
should()

import { Action, Reducer } from 'redux'

import { Enumeration } from '../../..'
import { EnumerationsState, EnumerationsResponseType } from '../model/enumerationsTypes'
import * as actions from '../actions/enumerationsActions'
import * as reducers from './enumerationsReducers'
import { enumerationsInitialState, enumerationsReducer } from './enumerationsMain'

describe('CommonManagement', () => {
    describe('reducers', () => {
        describe('enumerationsInitialState', () => {
            it('should have the callStatus for the enumerations api undefined', () => {
                expect(enumerationsInitialState.callStatus).to.equal(undefined, 'callStatus not undefined')
            })
        })

        describe('enumerationsReducer', () => {
            let _action: actions.EnumerationsSuccessAction
            let _data: EnumerationsResponseType

            before(() => {
                _data = require('../data/SingleEnumeration.json')
                _action = actions.enumerationsSuccessAction(['AccountCategory'], _data.response as Enumeration[], _data.totalCount)
            })

            it('should call the EnumerationsSuccessActionReducer when receiving a EnumerationsSuccessAction', () => {
                const _newState = enumerationsReducer(enumerationsInitialState, _action)
                const { response = [{}]} = _data
                _newState.should.have.property('AccountCategory').that.has.property('response').to.deep.equal(response[0])
            })

            it('should return the original state when the action is not recognized', () => {
                const _newState = enumerationsReducer(enumerationsInitialState, { type: 'UNKNOWN_ACTION' })
                _newState.should.deep.equal(enumerationsInitialState, 'not initial state on unknown action')
            })

            it('should return the original state in case of a logout action', () => {
                const _newState = enumerationsReducer(enumerationsInitialState, { type: 'USER_LOGOUT' })
                _newState.should.deep.equal(enumerationsInitialState, 'not initial state on logout')
            })
        })
    })
})
