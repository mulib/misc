import { ResponseWrapper, CallStatus, Enumeration, EnumerationDataWrapper } from '../../..'

/**
 * This is the REST API response type definition
 */
export type EnumerationsResponseType = ResponseWrapper<Enumeration[]>

/**
 * Redux State interface for enumerations
 * @param callStatus indicates the API call status. For each HTTP verb, it holds a loading and a success flag, as well as any remote message sent by the API
 * @param enumerations is the entity stored upon successful API invocation
 */
export interface EnumerationsState {
    [enumerationName: string]: {
        callStatus?: CallStatus
        response?: Enumeration
        values?: EnumerationDataWrapper[]
        totalCount?: number
    }
}
