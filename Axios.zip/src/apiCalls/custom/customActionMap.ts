import { ApiActionMap } from '../../'
import { enumerations } from './actions/enumerationsActions'

export const customActionMap: ApiActionMap = {
    enumerations: enumerations
}
