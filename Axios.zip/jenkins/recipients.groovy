def allDevelopersList() 
{ 
    return "AmdocsOptimaUIBackendBuild@int.amdocs.com"
}

def managementList() 
{ 
    return "AmdocsOptimaUIManagementBuild@int.amdocs.com;AmdocsOptimaDevOpsTeam@int.amdocs.com;AmdocsOptimaTestAutomation@int.amdocs.com"
}

return this;