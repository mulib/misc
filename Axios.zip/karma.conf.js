module.exports = function (config) {
    config.set({
        karmaTypescriptConfig: {
            tsconfig: "./tsconfig.json",
            bundlerOptions: {
                exclude: [
                    "react/addons",
                    "react/lib/ExecutionEnvironment",
                    "react/lib/ReactContext"
                ]
            },
            coverageOptions: {
                instrumentation: true,
                exclude: /\.(d|spec|test|build)\.(ts|tsx)/i,
                threshold: {
                    global: {
                        statements: 100,
                        branches: 100,
                        functions: 100,
                        lines: 100
                    }
                }
            },
            reports: {
                "cobertura": {
                    "directory": "build_reports/coverage",
                    "filename": "coverage.xml",
                    "subdirectory": "cobertura"
                },
                "html": "build_reports/coverage",
                "text-summary": "",
                "text": ""
            }
        },
        frameworks: ['mocha', 'karma-typescript'],
        files: [
            './tests/find-polyfill.js',
            './tests/findIndex-polyfill.js',
            './node_modules/core-js/client/core.js',
            './node_modules/phantomjs-polyfill-object-assign/object-assign-polyfill.js',
            './node_modules/es6-promise/dist/es6-promise.auto.js',
            {
                pattern: '!(dist|node_modules|typings|build)/**/*!(d).+(ts|tsx)'
            }
        ],
        exclude: [
            "**/*.d.ts"
        ],
        preprocessors: {
            '!(dist|node_modules|typings|build)/**/*.+(ts|tsx)': ['karma-typescript'],
        },
        reporters: ['mocha', 'junit', 'karma-typescript'],
        junitReporter: {
            outputDir: 'build_reports/test-results',
            outputFile: 'test-results.xml'
        },
        browsers: ['PhantomJS'],
        singleRun: true,
        colors: true,
        logLevel: config.LOG_INFO,
        browserNoActivityTimeout: 30000,
        client: {
            mocha: {
                timeout: 5000
            }
        }
    });
};