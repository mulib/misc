

interface NodeRequire {
    ensure: (paths: string[], callback: Function, name?: string) => void;
    context(directory: string, useSubDirectories?: boolean, regExp?: RegExp): any;
}

declare module "react-tap-event-plugin" {
    var dummy: any;
    export default dummy;
}

declare interface ObjectConstructor {
    assign(target: any, ...sources): any;
}

declare var expect: Chai.ExpectStatic;

interface ReactCookieStatic {
    save(name: string, val: Object, opt?: Object)
    load(name: string, doNotParse?: boolean): string | Object;
    remove(name: string, opt?: Object);
}

declare module "react-cookie" {
    var reactCookie: ReactCookieStatic;
    export = reactCookie;
}

interface Window {
    validationJson?: any
    appConfig?: any
    Promise?: any
}