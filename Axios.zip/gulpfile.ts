require('ts-node')
require('./build/tasks')
